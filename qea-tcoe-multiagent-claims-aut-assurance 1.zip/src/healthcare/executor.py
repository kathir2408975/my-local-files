import json
from pathlib import Path
from datetime import datetime

from src.common_layers.llm_layer.llm_manager import LLMManager
from src.healthcare.workflows.healthcare_workflow import create_health_graph
from src.common_utilities.logger import log_trace

client = LLMManager().get_non_chat_client()

print("🚀 === HEALTHCARE CLAIMS PROCESSING SYSTEM STARTED ===")
print(f"⏰ Start Time: {datetime.now().isoformat()}")
print("🔧 Project initiated successfully")

if __name__ == "__main__":
    print(f"\n📁 === SETTING UP OUTPUT DIRECTORY ===")
    output_dir = Path("output")
    output_dir.mkdir(parents=True, exist_ok=True)
    print(f"✅ Output directory created: {output_dir.absolute()}")

    function_definitions = """
    verify_document: Verifies the validity of claim documents. Requires policy_id, document, is_valid_claim, and reason.
    check_eligibility: Checks if the claim is eligible based on policy details. Requires policy_id, policy_start, policy_end, and accident_date.
    check_fraud: Checks for fraud indicators in the claim. Requires policy_id, document, claim_amount, and estimated_damage_cost.
    generate_summary: Generates a summary of the claim processing results. Requires policy_id, doc_status, eligibility_status, and fraud_status.
    make_decision: Makes a final decision on the claim. Requires policy_id, doc_status, eligibility_status, fraud_status, and summary.
    """

    # print(f"📋 Function definitions loaded: {len(function_definitions.split('\\n'))} functions")
    # Split on new line and filter out empty strings

    functions = [line for line in function_definitions.strip().split('\n') if line]
    print(f"📋 Function definitions loaded: {len(functions)} functions")

    # claim_input_1 = {
    #     "policy_id": "HLT-2001",
    #     "domain": "Health Insurance (Major Medical Plan)",
    #     "claim_record": {
    #         "name": "Valid Medical",
    #         "policy_id": "HLT-2001",
    #         "policy_start": "2025-01-01",
    #         "policy_end": "2025-12-31",
    #         "claim_type": "Health Insurance (Major Medical Plan)",
    #         "accident_date": "2025-05-15",
    #         "claim_amount": 12000,
    #         "notes": [
    #             "document_verification_agent - submitted_documents_completeness: All required documents have likely been provided, as inferred from the valid claim status.",
    #             "document_verification_agent - authenticity_check: Submitted documents are genuine, as inferred from the valid claim status.",
    #             "document_verification_agent - duplicate_document_check: No duplicate bills or records have been submitted, as inferred from the valid claim status.",
    #             "document_verification_agent - provider_details_verification: Provider information matches official records, as inferred from the valid claim status.",
    #             "document_verification_agent - service_date_verification: Service dates on documents align with the claimed event, as inferred from the valid claim status.",
    #         ],
    #     },
    # }

    # Claim Rejected / Not Approved
    claim_input_not_approved_with_notes = {
        "policy_id": "HLT-2002",
        "domain": "Health Insurance (Major Medical Plan)",
        "claim_record": {
            "name": "Valid Medical",
            "policy_id": "HLT-2002",
            "policy_start": "2025-01-01",
            "policy_end": "2025-12-31",
            "claim_type": "Health Insurance (Major Medical Plan)",
            "accident_date": "2025-05-15",
            "claim_amount": 12000,
            "notes": [
                "document_verification_agent - submitted_documents_completeness: All required documents have likely been provided, as inferred from the claim status.",
                "document_verification_agent - authenticity_check: Submitted documents are invalid and likely fraudulent, as inferred from the fraudulent claim status.",
                "document_verification_agent - duplicate_document_check: Fraudulent bills or records have been submitted, as inferred from the claim status.",
                "document_verification_agent - provider_details_verification: Provider information matches official records, as inferred from the claim status.",
                "document_verification_agent - service_date_verification: Service dates on documents align with the claimed event, as inferred from the claim status.",
            ],
        },
    }

    claim_input_not_approved = {
    "policy_id": "HLT-4009",
    "domain": "Major Medical Health Plan",
    "claim_record": {
        "name": "Springfield Medical Center",
        "policy_id": "HLT-4009",
        "policy_start": "2025-01-01",
        "policy_end": "2025-12-31",
        "claim_type": "Health Insurance",
        "accident_date": "2025-05-15",
        "claim_amount": 6700,
        "notes": [],
    },
}

    # Claim Human Review
    claim_input_human_review = {
        "policy_id": "HLT-2002",
        "domain": "Health Insurance (Major Medical Plan)",
        "claim_record": {
            "name": "Valid Medical",
            "policy_id": "HLT-2002",
            "policy_start": "2025-01-01",
            "policy_end": "2025-12-31",
            "claim_type": "Health Insurance (Major Medical Plan)",
            "accident_date": "2025-05-15",
            "claim_amount": 12000,
            "notes": [
                "document_verification_agent: submitted_documents_completeness – All expected documentation appears to be included based on the claim contents.",
                "document_verification_agent: authenticity_check – Several anomalies were detected in the submitted documents, raising concerns about their legitimacy.",
                "document_verification_agent: duplicate_document_check – Some billing entries appear multiple times across documents with inconsistent formatting.",
                "document_verification_agent: provider_details_verification – Provider information aligns with known facility data and license registry records.",
                "document_verification_agent: service_date_verification – Dates of treatment correspond with the reported incident and fall within the policy coverage period."
            ],
        },
    }

    # Claim Passed / Approved
    claim_input_approved = {
        "policy_id": "HLT-3005",
        "domain": "Major Medical Health Plan",
        "claim_record": {
            "name": "Springfield Medical Center",
            "policy_id": "HLT-3005",
            "policy_start": "2025-01-01",
            "policy_end": "2025-12-31",
            "claim_type": "Health Insurance",
            "accident_date": "2025-05-15",
            "claim_amount": 6700,
            "notes": [
                "document_verification_agent: claim_amount_verification passed – claim amount approved and within coverage limits; validated by insurer.",
                "document_verification_agent: policy_status_verification passed – deductible met and policy status confirmed as current and valid.",
                "document_verification_agent: patient_and_provider_identity_verification passed – patient ID and provider information verified and matched official records.",
                "document_verification_agent: medical_records_completeness_verification passed – medical records complete, well-documented, and in full compliance with standards.",
                "document_verification_agent: service_date_verification passed – services rendered aligned with approved treatment plan; all dates are recent and within policy period.",
                "document_verification_agent: hospital_verification passed – emergency and follow-up visits cross-verified and hospital verified.",
                "document_verification_agent: billing_validation passed – billing and invoice information audit passed and reconciled.",
                "document_verification_agent: documentation_authenticity_verification passed – claim documentation is clear, legible, and digitally signed by the attending physician."
            ],
        },
    }

    claim_input = claim_input_human_review

    print(f"\n📋 === CLAIM INPUT ANALYSIS ===")
    print(f"🆔 Policy ID: {claim_input['policy_id']}")
    print(f"🏥 Domain: {claim_input['domain']}")
    print(f"💰 Claim Amount: ${claim_input['claim_record']['claim_amount']:,}")
    print(f"📝 Notes Count: {len(claim_input['claim_record']['notes'])}")
    print(f"📅 Policy Period: {claim_input['claim_record']['policy_start']} to {claim_input['claim_record']['policy_end']}")
    print(f"🗓️ Accident Date: {claim_input['claim_record']['accident_date']}")
    
    log_trace(
        claim_id=claim_input['policy_id'],
        step="healthcare_executor_start",
        output={
            "executor": "healthcare_executor",
            "policy_id": claim_input['policy_id'],
            "domain": claim_input['domain'],
            "claim_amount": claim_input['claim_record']['claim_amount'],
            "notes_count": len(claim_input['claim_record']['notes']),
            "policy_start": claim_input['claim_record']['policy_start'],
            "policy_end": claim_input['claim_record']['policy_end'],
            "accident_date": claim_input['claim_record']['accident_date']
        }
    )

    input_data = claim_input

    print(f"\n🔄 === CREATING HEALTHCARE WORKFLOW ===")
    print(f"🏗️ Building healthcare workflow graph...")
    
    log_trace(
        claim_id=claim_input['policy_id'],
        step="healthcare_executor_workflow_creation",
        output={
            "action": "creating_health_graph",
            "input_data_keys": list(input_data.keys())
        }
    )
    
    workflow = create_health_graph(claim_input)
    print(f"✅ Healthcare workflow graph created successfully")
    
    print(f"\n🚀 === EXECUTING HEALTHCARE WORKFLOW ===")
    print(f"⚡ Starting workflow execution for Policy ID: {claim_input['policy_id']}")
    
    log_trace(
        claim_id=claim_input['policy_id'],
        step="healthcare_executor_workflow_invoke",
        output={
            "action": "invoking_workflow",
            "policy_id": claim_input['policy_id'],
            "workflow_created": True
        }
    )
    
    result = workflow.invoke(input_data)
    
    print(f"✅ Workflow execution completed")
    print(f"📊 Result Keys: {list(result.keys())}")
    
    log_trace(
        claim_id=claim_input['policy_id'],
        step="healthcare_executor_workflow_result",
        output={
            "action": "workflow_completed",
            "result_keys": list(result.keys()),
            "workflow_successful": True
        }
    )

    print(f"\n📊 === PROCESSING WORKFLOW RESULTS ===")
    
    # Extract and infer fields
    decision = result.get("decision","N/A")
    reason = result.get("reason", "Document Verification Flow Incomplete")
    summary =  result.get("summary", "Summary not available. Document verification has not produced a summary.")
    reflection = "Reflection unavailable. The verification process did not generate additional insights."


    input_data_json = json.dumps(
        result.get("claim_record", {})
    )  # Using claim_record as input
    output_json = json.dumps(
        result.get("decision_result", {})
    )  # Using decision_result as output
    final_summary = summary  # Same as summary for consistency
    agent_results = (result.get("document_check_result", "") + "\n" + json.dumps(result.get("decision_result", {})))  # Concatenated results
    policy_id = result.get("policy_id", "unknown")
    
    print(f"📋 Extracted Results:")
    print(f"   Final Decision: {decision}")
    print(f"   Policy ID: {policy_id}")
    print(f"   Reason Length: {len(reason)} chars")
    print(f"   Summary Length: {len(summary)} chars")
    print(f"   Agent Results Length: {len(agent_results)} chars")
    
    log_trace(
        claim_id=policy_id,
        step="healthcare_executor_results_extraction",
        output={
            "final_decision": decision,
            "policy_id": policy_id,
            "summary_length": len(summary),
            "agent_results_length": len(agent_results),
            "result_processing_complete": True
        }
    )

    print(f"\n🎯 === HEALTHCARE CLAIMS PROCESSING COMPLETED ===")
    print(f"✅ Final Decision: {decision}")
    print(f"🆔 Policy ID: {policy_id}")
    print(f"⏰ End Time: {datetime.now().isoformat()}")
    print(f"📋 Summary: {summary}")
    print(f"💬 Reason: {reason}")
    
    log_trace(
        claim_id=policy_id,
        step="healthcare_executor_complete",
        output={
            "executor_completed": True,
            "final_decision": decision,
            "policy_id": policy_id,
            "end_time": datetime.now().isoformat(),
            "processing_successful": True
        }
    )
    
    print("🚀 === HEALTHCARE CLAIMS PROCESSING SYSTEM FINISHED ===")




    # Evaluation templates
    EVAL_TEMPLATES = {
        "decision_eval": """
    You are evaluating the final decision made by an AI agent for a claim.

    Decision: {decision}
    Reason: {decision_reason}
    Summary: {summary}

    Was this decision justified?

    Respond in JSON:
    {{
    "score": <0.0 to 1.0>,
    "decision_justified": <true/false>,
    "justification": "<explanation>"
    }}
    """,
        "reflection_eval": """
    Evaluate the quality of this agent's self-reflection.

    Reflection: {reflection}
    Input: {input}
    Output: {output}

    Was the reflection thoughtful and accurate?

    Respond in JSON:
    {{
    "score": <0.0 to 1.0>,
    "reflection_quality": "<brief comment>",
    "reflection_valid": <true/false>
    }}
    """,
        "final_call_eval": """
    You are reviewing the overall insurance claim workflow.

    Final Summary: {final_summary}
    Agent Results: {agent_results}

    Was the process consistent and complete?

    Respond in JSON:
    {{
    "overall_score": <0.0 to 1.0>,
    "consistent": <true/false>,
    "comment": "<brief final assessment>"
    }}
    """,
    }
