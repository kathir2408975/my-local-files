import json
import os
from typing import Dict, Optional, TypedDict, Any

from IPython.display import Image
from langchain_core.runnables.graph import MermaidDrawMethod
from langgraph.graph import StateGraph, END

import definitions
from src.common_layers.llm_layer.llm_manager import LLMManager
from src.healthcare.agents.decision_agent import decision_agent
from src.healthcare.agents.document_agent import health_document_agent
from src.healthcare.agents.fraud_checker_agents import (fraud_duplicate_claim_checker,
                                                        fraud_service_reasonability_checker,
                                                        fraud_provider_verification_checker,
                                                        fraud_inconsistency_checker,
                                                        get_health_fraud_checker_agents)
from src.healthcare.agents.summarizer_agent import get_summarizer_agent


class ClaimRecord(TypedDict):
    name: str
    policy_id: str
    policy_start: str
    policy_end: str
    claim_type: str
    accident_date: str
    claim_amount: float
    notes: list[str]


class GraphState(TypedDict):
    policy_id: str
    domain: str
    claim_record: ClaimRecord
    document_check_result: Optional[Dict]
    decision_result: Optional[Dict]
    decision: Optional[str]
    reason: Optional[str]
    fraud_detection_results: Optional[Dict[str, Any]]
    summary : Optional[str]

class ClaimAgents:
    def __init__(self, llm):
        self.llm = llm

    def document_verifier_agent(self, state: GraphState) -> Dict:
        # Invoke the health_document_agent with the state
        return health_document_agent()(state)

    def decision_agent(self, state: GraphState) -> Dict:
        return decision_agent()(state)

    def fraud_detector_agent(self, state: GraphState) -> Dict:
        fraud_checker = get_health_fraud_checker_agents(self.llm)
        return fraud_checker.invoke(state)

    def summarizer_agent(self, state: GraphState) -> Dict:
        summarizer = get_summarizer_agent(self.llm)
        return summarizer.invoke(state)


def decide_fraud(state: GraphState) -> str:
    raw_doc_result = state.get("document_check_result")
    try:
        # Attempt to parse the string into a dictionary
        doc_result = json.loads(raw_doc_result)
        if not isinstance(doc_result, dict):
            print("Parsed data is not a dictionary.")
            doc_result = {}
    except json.JSONDecodeError as e:
        print(f"Error decoding JSON: {e}")
        doc_result = {}
    except ValueError as e:
        print(f"Value error: {e}")
        doc_result = {}
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
        doc_result = {}
    doc_status = doc_result.get("status", "failed") if doc_result else "failed"
    if doc_status.lower() == "failed":
        print("Detected fraud. Going to fraud detector agent.")
        return "FraudDetector"
    else:
        print("Looks fine. Going to summarization agent")
        return "Summarizer"


def create_health_graph(state: GraphState):
    """
    Constructs and compiles the LangGraph StateGraph for insurance claim processing.
    """
    # Instantiate LLM and agent manager
    llm_manager = LLMManager()
    azure_openai = llm_manager.get_non_chat_client()
    agent = ClaimAgents(azure_openai)

    # Create graph builder with your state class
    builder = StateGraph(GraphState)

    # Add agent nodes - DecisionSupervisor now handles routing internally via tool calls
    builder.add_node("DocumentVerifier", agent.document_verifier_agent)
    builder.add_node("DecisionSupervisor", agent.decision_agent)
    builder.add_node("FraudDetector", agent.fraud_detector_agent)
    builder.add_node("Summarizer", agent.summarizer_agent)

    # Set entry point
    builder.set_entry_point("DocumentVerifier")

    # Define edges
    builder.add_conditional_edges('DocumentVerifier', decide_fraud, {
        "FraudDetector": "FraudDetector",
        "Summarizer": "Summarizer",
    })
    builder.add_edge("FraudDetector", "Summarizer")
    builder.add_edge("Summarizer", "DecisionSupervisor")
    
    # DecisionSupervisor handles routing internally via LLM tool calling and terminates workflow
    builder.add_edge("DecisionSupervisor", END)

    app = builder.compile()

    # There are much better ways to visualize this graph. But currently none of them works.
    # So using this as a last resort.
    app.get_graph().print_ascii()

    # Compile and return the graph
    return app
