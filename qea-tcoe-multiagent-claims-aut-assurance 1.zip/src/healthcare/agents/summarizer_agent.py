from langchain_core.runnables import Runnable
from langchain_core.messages import HumanMessage
from langchain_openai import AzureChatOpenAI
import os
from src.healthcare.agents.supervisors.supervisor_agent import *

from src.common_utilities.logger import log_trace

load_dotenv()

from langchain.schema import HumanMessage
import json
from src.common_layers.llm_layer.llm_manager import LLMManager
from src.healthcare.state import GraphState
from typing import Dict, Any
from langchain_core.runnables import Runnable
from langchain_core.runnables import RunnableLambda

def get_summarizer_agent(llm) -> Runnable:
    def run(state: GraphState) -> Dict[str, Any]:
        print(f"\n📝 === SUMMARIZER AGENT STARTED ===")
        print(state)

        claim_id = state.get("claim_id", f"CLM_{state.get('policy_id', '')}")
        notes = state.get("claim_record", {}).get("notes", [])
        claim_record = state.get("claim_record", {})
        document_check_result = state.get("document_check_result", {})
        fraud_detection_results = state.get("fraud_detection_results", {})

        print(f"📋 Summarizer Inputs:")
        print(f"🆔 Claim ID: {claim_id}")
        print(f"📄 Claim Record Fields: {len(claim_record)}")
        print(f"📝 Notes Count: {len(notes)}")
        print(f"🆔 Document Checker Results: {document_check_result}")
        print(f"🆔 Fraud Detector Results: {fraud_detection_results}")

        log_trace(
            claim_id,
            "summarizer_agent_input",
            {
                "state": state,
                "prompt_inputs": {
                    "claim_id": claim_id,
                    "notes": notes
                },
            },
        )

        print(f"🔄 Generating summary prompt for LLM...")

        prompt = f"""
        You are an AI assistant summarizing a vehicle insurance claim.

        Here are the claim details:

        - Claim ID: {claim_id}
        - Claim Record Details: {json.dumps(claim_record, indent=2)}
        - Notes: {notes}
        - Document Check Results: {json.dumps(document_check_result, indent=2)}
        - Fraud Detection Results: {json.dumps(fraud_detection_results, indent=2)}

        Based on all this information, generate:
        - A short summary suitable for internal review.
        - A summary_accuracy_score (between 0 and 1) reflecting how complete and accurate the information is.
        - Make sure the summary is clear and detailed with all the required information.
        
        Respond in the following JSON format:
        {{
            "summary": "<summary text>",
            "summary_accuracy_score": <float>
        }}

        Ensure the response is valid JSON. If insufficient data is provided, generate a summary based on available information and assign a lower summary_accuracy_score.
        """

        log_trace(
            claim_id,
            "summarizer_agent_llm_call",
            {
                "prompt_length": len(prompt),
                "action": "generate_claim_summary"
            }
        )

        print(f"🤖 Making LLM call for summary generation...")
        response = llm.chat.completions.create(
            model=os.getenv("AZURE_OPENAI_LLM_DEPLOYMENT"),
            messages=[
                {"role": "user", "content": prompt}
            ]
        ).choices[0].message
        print(f"✅ LLM Response Received (Length: {len(response.content)} chars)")
        response_content = (
            response.content.strip().replace("```json", "").replace("```", "")
        )
        print(f"📄 Raw LLM Response:\n{response.content}")

        try:
            parsed = json.loads(response_content)
            print(f"✅ Summary LLM Response Parsed Successfully")
            print(f"📊 Summary Result:")
            print(f"   Summary: {parsed.get('summary', 'N/A')[:100]}...")
            print(f"   Summary Accuracy Score: {parsed.get('summary_accuracy_score', 'N/A')}")

            if (
                    not isinstance(parsed, dict)
                    or "summary" not in parsed
                    or "summary_accuracy_score" not in parsed
            ):
                raise ValueError(
                    "Invalid LLM output: Expected a dictionary with 'summary' and 'summary_accuracy_score'"
                )

            log_trace(
                claim_id,
                "summarizer_agent_parse_success",
                {
                    "summary_length": len(parsed.get("summary", "")),
                    "summary_accuracy_score": parsed.get("summary_accuracy_score"),
                    "parsing_successful": True
                }
            )

        except (json.JSONDecodeError, ValueError) as e:
            print(f"❌ Failed to parse LLM response: {e}")
            print(f"📄 Raw response: {response_content}")

            log_trace(
                claim_id,
                "summarizer_agent_error",
                {"error": str(e), "raw_response": response.content},
            )
            parsed = {
                "summary": f"Claim {claim_id}: {notes[:100]}... (truncated). Failed to generate full summary due to invalid LLM response.",
                "summary_accuracy_score": 0.5,
            }
            print(f"🔄 Using fallback summary due to parsing error")
        output = {
            "summary": parsed.get("summary", "No summary generated"),
            "summary_accuracy_score": float(parsed.get("summary_accuracy_score", 0.0)),
        }

        print(f"📋 Final Summary Output:")
        print(f"   Summary: {output.get('summary')}")
        print(f"   Summary Accuracy Score: {output.get('summary_accuracy_score')}")

        log_trace(claim_id=claim_id, step="summarizer_agent_result", output=output)

        print(f"🏁 Summarizer Agent Completed")
        print(f"📝 === SUMMARIZER AGENT FINISHED ===\n")

        log_trace(
            claim_id=claim_id,
            step="summarizer_agent_complete",
            output={
                "agent_completed": True,
                "summary_length": len(output.get("summary", "")),
                "summary_accuracy_score": output.get("summary_accuracy_score")
            }
        )

        state["summary"] = output

        return output

    return RunnableLambda(run)
