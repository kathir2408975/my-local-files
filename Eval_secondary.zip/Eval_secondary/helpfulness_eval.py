"""
Helpfulness Evaluation Module
Evaluates the helpfulness of AI responses in conversation context.
"""

import os
import json
import re
from typing import List, Any, Dict, Tuple
from datetime import datetime
from langsmith import Client
from langchain_openai import AzureChatOpenAI
from utils import get_or_create_workbook, get_or_create_sheet

# ============================================================
# TRACE EXTRACTION
# ============================================================

def fetch_spans(trace_id: str) -> List[Any]:
    """Fetch all spans for a given trace ID."""
    client = Client(api_key=os.environ["LANGSMITH_API_KEY"])
    spans = list(client.list_runs(trace_id=trace_id))
    if not spans:
        raise ValueError("No spans found for trace.")
    return sorted(spans, key=lambda r: r.start_time or 0)

# ============================================================
# DATA EXTRACTION
# ============================================================

def extract_conversation_from_execute_span(spans: List[Any]) -> List[Dict[str, str]]:
    """Extract conversation from Execute span messages."""
    execute_spans = [span for span in spans if span.name == "Execute"]

    if not execute_spans:
        raise ValueError("No Execute span found in trace")

    execute_span = execute_spans[0]
    messages = execute_span.inputs.get("messages", [])

    conversation = []
    for msg in messages:
        role = msg.get("type")
        content = msg.get("content")
        if role in ("human", "ai") and content:
            conversation.append({"role": role.lower(), "content": content.strip()})

    if len(conversation) < 2:
        raise ValueError("Not enough conversation turns")

    return conversation

# ============================================================
# CONVERSATION WINDOWS
# ============================================================

def build_eval_windows(conversation: List[Dict[str, str]]) -> List[Tuple[List[Dict[str, str]], str]]:
    """Build evaluation windows from conversation."""
    windows = []
    last_ai_index = None

    for i in range(len(conversation)):
        turn = conversation[i]

        if turn["role"] == "ai":
            last_ai_index = i
        elif turn["role"] == "human":
            if last_ai_index is not None:
                context_turns = conversation[:last_ai_index]
                target_turn = conversation[last_ai_index]["content"]
                windows.append((context_turns, target_turn))
                last_ai_index = None

    # Handle final AI block if conversation ends with AI
    if last_ai_index is not None:
        context_turns = conversation[:last_ai_index]
        target_turn = conversation[last_ai_index]["content"]
        windows.append((context_turns, target_turn))

    if not windows:
        raise ValueError("No evaluatable AI turns found")

    return windows

# ============================================================
# SCORING
# ============================================================

SCORE_TO_OVERALL = {
    "Not Helpful At All": 0.0,
    "Very Unhelpful": 0.2,
    "Somewhat Unhelpful": 0.4,
    "Neutral/Mixed": 0.5,
    "Somewhat Helpful": 0.7,
    "Very Helpful": 0.9,
    "Above And Beyond": 1.0,
}

OVERALL_LABEL_THRESHOLDS = [
    (0.9, "Above And Beyond"),
    (0.8, "Very Helpful"),
    (0.6, "Somewhat Helpful"),
    (0.5, "Neutral/Mixed"),
    (0.3, "Somewhat Unhelpful"),
    (0.1, "Very Unhelpful"),
    (0.0, "Not Helpful At All"),
]

def score_to_label(score: float) -> str:
    """Convert numeric score to label."""
    for threshold, label in OVERALL_LABEL_THRESHOLDS:
        if score >= threshold:
            return label
    return "Not Helpful At All"

# ============================================================
# PROMPT BUILDERS
# ============================================================

EVAL_PROMPT_TEMPLATE = """
You are an objective judge evaluating the helpfulness of an AI assistant's response from the user's perspective. Your task is to assess whether the assistant's turn moves the user closer to achieving or formulating their goals.

IMPORTANT: Evaluate purely from the user's perspective, without considering the factual accuracy or backend operations. Focus only on how the response helps the user progress towards their goals.

**IMPORTANT**:
Base your evaluation strictly on the provided conversation context and target turn.
Do not introduce external facts or assumptions beyond the given inputs.

Infer the user's goals purely based on the user's initial request, and any additional context they may provide afterwards.

# Conversation Context:
## Previous turns:
<<context_text>>

## Target turn to evaluate:
<<target_turn>>

# Evaluation Guidelines:
Rate the helpfulness of the assistant's turn using this scale:

0. Not Helpful At All
- Gibberish or nonsense
- Actively obstructs goal progress
- Leads user down wrong path

1. Very Unhelpful
- Creates confusion or misunderstanding

2. Somewhat Unhelpful
- Delays goal progress
- Provides irrelevant information
- Makes unnecessary detours

3. Neutral/Mixed
- Has no impact on goal progress
- Appropriate chit-chat for conversation flow
- Contains mix of helpful and unhelpful elements that cancel out

4. Somewhat Helpful
- Moves user one step towards goal
- Provides relevant information
- Clarifies user's needs or situation

5. Very Helpful
- Moves user multiple steps towards goal
- Provides comprehensive, actionable information
- Significantly advances goal understanding or formation

6. Above And Beyond
- The response is Very Helpful and feedback about user input quality issues or content limitations are insightful and get the user as close as possible to their goal given the input's limitations
- The response is Very Helpful and it anticipates and addresses general user concerns.

The output should be a well-formatted JSON instance that conforms to the JSON schema below.

As an example, for the schema {"properties": {"foo": {"title": "Foo", "description": "a list of strings", "type": "array", "items": {"type": "string"}}}, "required": ["foo"]}
the object {"foo": ["bar", "baz"]} is a well-formatted instance of the schema. The object {"properties": {"foo": ["bar", "baz"]}} is not well-formatted.

Here is the output JSON schema:
```
{"properties": {"reasoning": {"description": "step by step reasoning to derive the final score, using no more than 250 words", "title": "Reasoning", "type": "string"}, "score": {"description": "score should be one of 'Not Helpful At All', 'Very Unhelpful', 'Somewhat Unhelpful', 'Neutral/Mixed', 'Somewhat Helpful', 'Very Helpful' or 'Above And Beyond'", "enum": ["Not Helpful At All", "Very Unhelpful", "Somewhat Unhelpful", "Neutral/Mixed", "Somewhat Helpful", "Very Helpful", "Above And Beyond"], "title": "Score", "type": "string"}}, "required": ["reasoning", "score"]}
```

Do not return any preamble or explanations, return only a pure JSON string surrounded by triple backticks (```).
"""

def build_eval_prompt(context_turns: List[Dict[str, str]], target_turn: str) -> str:
    """Build evaluation prompt for a single turn."""
    context_text = "\n".join(
        f"{turn['role'].upper()}: {turn['content']}"
        for turn in context_turns
    ) if context_turns else "(No prior context)"

    return (
        EVAL_PROMPT_TEMPLATE
        .replace("<<context_text>>", context_text)
        .replace("<<target_turn>>", target_turn)
    )

def parse_llm_json(raw_output: str) -> Dict[str, Any]:
    """Parse JSON from LLM output, handling markdown code blocks."""
    raw_output = raw_output.strip()
    if raw_output.startswith("```"):
        raw_output = raw_output.strip("`").strip()
        if raw_output.lower().startswith("json"):
            raw_output = raw_output[4:].strip()

    decoder = json.JSONDecoder()
    result, _ = decoder.raw_decode(raw_output.strip())
    return result

# ============================================================
# TURN-LEVEL EVALUATION
# ============================================================

def evaluate_single_turn(
    context_turns: List[Dict[str, str]],
    target_turn: str,
    turn_index: int,
    total_windows: int,
    llm_client: AzureChatOpenAI
) -> Dict[str, Any]:
    """Evaluate a single conversation turn."""

    eval_prompt = build_eval_prompt(context_turns, target_turn)
    context_text = "\n".join(
        f"{t['role'].upper()}: {t['content']}" for t in context_turns
    ) if context_turns else "(No prior context)"

    response = llm_client.invoke(eval_prompt)

    try:
        result = parse_llm_json(response.content)
    except (json.JSONDecodeError, ValueError) as e:
        raise ValueError(f"Invalid JSON returned for turn {turn_index}:\n{response.content}")

    label_score = result.get("score")
    if label_score not in SCORE_TO_OVERALL:
        raise ValueError(f"Unexpected score label: {label_score}")

    numeric_score = SCORE_TO_OVERALL[label_score]

    return {
        "turn_index":     turn_index,
        "total_windows":  total_windows,
        "eval_prompt":    eval_prompt,
        "eval_inputs": {
            "conversation_history": context_text,
            "target_turn":          target_turn,
        },
        "eval_output":    result,
        "numeric_score":  numeric_score,
    }

# ============================================================
# OVERALL SUMMARY
# ============================================================

def compute_overall_summary(
    all_eval_results: List[Dict[str, Any]],
    llm_client: AzureChatOpenAI
) -> Dict[str, Any]:
    """Compute overall summary across all turn evaluations."""

    avg_score     = sum(r["numeric_score"] for r in all_eval_results) / len(all_eval_results)
    overall_label = score_to_label(avg_score)

    all_reasonings = "\n\n".join(
        f"Turn {r['turn_index']}:\n"
        f"Score: {r['eval_output']['score']} ({r['numeric_score']})\n"
        f"Reasoning: {r['eval_output']['reasoning']}"
        for r in all_eval_results
    )

    overall_prompt = f"""
You are an evaluation meta-judge.
Below are turn-level helpfulness evaluations of an AI conversation.
Your task:
- Produce a concise overall reasoning (max 50 words)
- Mention key strengths and weaknesses only
- Be objective

Conversation Turn Evaluations:
{all_reasonings}

Numeric Average Score: {avg_score:.4f}
Mapped Overall Label: {overall_label}

Return ONLY JSON:
{{
  "overall_reasoning": "string (max 50 words)",
  "overall_label": "{overall_label}"
}}
"""

    overall_response = llm_client.invoke(overall_prompt)

    try:
        overall_result = parse_llm_json(overall_response.content)
    except (json.JSONDecodeError, ValueError):
        raise ValueError(f"Invalid JSON from meta-judge:\n{overall_response.content}")

    return {
        "overall_score":     round(avg_score, 4),
        "overall_label":     overall_result.get("overall_label", overall_label),
        "overall_reason":    overall_result.get("overall_reasoning", ""),
        # FIX BUG 2: added overall_reason alias so main.py
        # _get(helpfulness_result, "overall_summary", "overall_reason") works correctly.
        # Previously only "overall_reasoning" existed; main.py expects "overall_reason".
    }

# ============================================================
# FULL PIPELINE
# ============================================================

def run_helpfulness_eval(
    trace_id: str,
    scenario: str,
    llm_client: AzureChatOpenAI,
) -> Dict[str, Any]:
    """Full helpfulness evaluation pipeline."""
    try:
        spans        = fetch_spans(trace_id)
        conversation = extract_conversation_from_execute_span(spans)
        eval_windows = build_eval_windows(conversation)

        all_eval_results = []
        for eval_index, (context_turns, target_turn) in enumerate(eval_windows, start=1):
            turn_result = evaluate_single_turn(
                context_turns=context_turns,
                target_turn=target_turn,
                turn_index=eval_index,
                total_windows=len(eval_windows),
                llm_client=llm_client,
            )
            all_eval_results.append(turn_result)

        overall_summary = compute_overall_summary(all_eval_results, llm_client)

        return {
            "eval_name":             "helpfulness",
            "trace_id":              trace_id,
            "scenario":              scenario,
            "turn_level_evaluations": all_eval_results,
            "eval_output": [
                {
                    "reasoning": r["eval_output"]["reasoning"],
                    "score":     r["eval_output"]["score"],
                }
                for r in all_eval_results
            ],
            "overall_summary": overall_summary,
            "metadata": {
                "model":                "gpt-5",
                "total_turns_evaluated": len(all_eval_results),
                "timestamp":            datetime.utcnow().isoformat(),
            },
            # FIX BUG 3: was "completed", changed to "success" so the
            # critique judge filter (status in ("success","completed")) passes.
            # Also ensures _stats() in run_async_evaluation counts it correctly
            # since helpfulness uses ok_status="success".
            "status": "success",
        }

    except Exception as e:
        return {
            "eval_name":             "helpfulness",
            "trace_id":              trace_id,
            "scenario":              scenario,
            "turn_level_evaluations": [],
            "eval_output":           [],
            "overall_summary":       {},
            "metadata": {
                "model":                "gpt-5",
                "total_turns_evaluated": 0,
                "timestamp":            datetime.utcnow().isoformat(),
            },
            "status": "failed",
            "error":  str(e),
        }


# ============================================================
# EXCEL OUTPUT
# ============================================================

def dump_helpfulness_eval_to_excel(
    *,
    trace_id: str,
    query: str,
    eval_result: dict,
    excel_path: str = "final_eval_results.xlsx",
):
    """Save helpfulness evaluation results to Excel."""

    # FIX BUG 1: sheet name was "Helpfulness" which matches EVAL_SHEET_MAP
    # correctly — no change needed there. However the failed-path row had
    # 8 values written into a 7-column header → corrupted sheet.
    # Fixed: failed row now writes exactly 7 columns matching HEADERS.
    HEADERS = [
        "Query",
        "Eval_Input",
        "Eval_Output",
        "Overall_Score",
        "Overall_Label",
        "Overall_Reason",
        "Tracebacks",
    ]

    wb    = get_or_create_workbook(excel_path)
    # Sheet name "Helpfulness" matches EVAL_SHEET_MAP["helpfulness"] → no stray sheet
    sheet = get_or_create_sheet(wb, "Helpfulness", HEADERS)

    overall_summary   = eval_result.get("overall_summary", {})
    overall_score     = overall_summary.get("overall_score", "")
    overall_label     = overall_summary.get("overall_label", "")
    overall_reasoning = overall_summary.get("overall_reason", "")

    if eval_result.get("status") == "failed":
        # FIX BUG 1: was 8 values for a 7-column header → corrupt row
        sheet.append([
            query,
            "",
            "",
            "",
            "",
            eval_result.get("error", "Unknown error"),
            "",
        ])
    else:
        turn_level_evals = eval_result.get("turn_level_evaluations", [])

        if turn_level_evals:
            for i, turn_eval in enumerate(turn_level_evals):
                sheet.append([
                    query if i == 0 else "",
                    turn_eval.get("eval_inputs", {}).get("conversation_history", ""),
                    turn_eval.get("eval_inputs", {}).get("target_turn", ""),
                    turn_eval.get("eval_output", {}).get("score", ""),
                    turn_eval.get("eval_output", {}).get("reasoning", ""),
                    overall_score     if i == 0 else "",
                    overall_label     if i == 0 else "",
                    overall_reasoning if i == 0 else "",
                ])
        else:
            sheet.append([
                query,
                "",
                "",
                "",
                "",
                overall_score,
                overall_label,
                overall_reasoning,
            ])

    wb.save(excel_path)