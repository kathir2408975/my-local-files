"""
Tool Call Accuracy Evaluation Module
=====================================

Purpose:
  Verify whether tool calls executed in a trace conform to their
  authoritative specifications (name, parameters, formats).

Evaluation Logic:
  1. Extract all tool spans (run_type == "tool"), skip IGNORED_TOOLS
  2. LLM audit: tool_name_check, tool_parameter_check, parameter_format_check
  3. Python override: mark_unknown_tools, attach_format_checks
  4. Score: passed_tools / total_tools (0.0 – 1.0)
"""

import os
import ast
import json
from datetime import datetime
from typing import List, Dict, Any
from langsmith import Client
from langchain_openai import AzureChatOpenAI

# ============================================================
# CONFIG — EXPECTED TOOLS (WITH PARAMETER FORMATS)
# ============================================================

EXPECTED_TOOLS = {
    "analytics_vendors_find": {
        "allowed_parameters": {
            "base_location": "string",
            "is_available":  "string",
            "limit":         "int",
            "mode":          "string",
            "vendor_id":     "string",
        },
        "parameter_policy": "any_subset",
        "strict": False,
    },
    "analytics_vendors_count": {
        "allowed_parameters": {
            "base_location": "string",
            "mode":          "string",
        },
        "parameter_policy": "any_subset",
        "strict": False,
    },
    "analytics_confirmed_order_lookup": {
        "allowed_parameters": {
            "order_id": "string",
        },
        "parameter_policy": "exact",
        "strict": False,
    },
    "analytics_purchase_history": {
        "allowed_parameters": {
            "delivery_type": "string",
            "limit":         "int",
            "vendor_id":     "string",
        },
        "parameter_policy": "any_subset",
        "strict": False,
    },
    "analytics_get_unique_locations": {
        "allowed_parameters": {},
        "parameter_policy": "exact",
        "strict": False,
    },

    "Fetch Vendors Tool": {
        "allowed_parameters": {
            "base_location": "string",
        },
        "parameter_policy": "exact",
        "strict": True,
    },
    "Fetch Performance History": {
        "allowed_parameters": {
            "base_location": "string",
        },
        "parameter_policy": "exact",
        "strict": True,
    },
    "Web Search Tool": {
        "allowed_parameters": {
            "query": "string",
        },
        "parameter_policy": "exact",
        "strict": True,
    },

    "Calculate Extra Charges Tool": {
        "allowed_parameters": {
            "event_cost":   "int",
            "weather_cost": "int",
        },
        "parameter_policy": "exact",
        "strict": True,
    },
    "Calculate Delivery Cost Tool": {
        "allowed_parameters": {
            "extra_charges": "string",
            "vendor_id_1":   "string",
            "vendor_id_2":   "string/empty",
        },
        "parameter_policy": "exact",
        "strict": True,
    },
    "Calculate Delivery Time Tool": {
        "allowed_parameters": {
            "vendor_id_1": "string",
            "vendor_id_2": "string/empty",
        },
        "parameter_policy": "exact",
        "strict": True,
    },
    "Calculate Forecast Confidence Tool": {
        "allowed_parameters": {
            "estimated_date_1":    "string",
            "estimated_date_2":    "string/empty",
            "extra_charges":       "string",
            "total_estimated_cost":"string",
            "vendor_id_1":         "string",
            "vendor_id_2":         "string/empty",
        },
        "parameter_policy": "any_subset",
        "strict": True,
    },

    "Load Optimization Data Tool": {
        "allowed_parameters": {},
        "parameter_policy": "exact",
        "strict": True,
    },
    "Compute Vendor Performance Tool": {
        "allowed_parameters": {
            "order_history": "list",
        },
        "parameter_policy": "exact",
        "strict": True,
    },
    "Score Candidates Tool": {
        "allowed_parameters": {
            "order":               "dict",
            "context":             "dict",
            "vendor_performance":  "dict",
            "critique_candidates": "list",
        },
        "parameter_policy": "exact",
        "strict": True,
    },

    "Load Compliance Data Tool": {
        "allowed_parameters": {},
        "parameter_policy": "exact",
        "strict": True,
    },
    "Check Holiday Event Tool": {
        "allowed_parameters": {
            "base_location":   "string",
            "target_location": "string",
            "delivery_date":   "string",
        },
        "parameter_policy": "exact",
        "strict": True,
    },
    "Evaluate Compliance Tool": {
        "allowed_parameters": {
            "order":                     "dict",
            "context":                   "dict",
            "optimisation_output":       "dict",
            "holiday_info":              "dict",
            "sla_min_normal":            "float",
            "sla_min_high_risk":         "float",
            "vendor_min_reliab_normal":  "float",
            "vendor_min_reliab_high_risk":"float",
        },
        "parameter_policy": "exact",
        "strict": True,
    },

    "Get Plan Information Tool": {
        "allowed_parameters": {
            "planid": "string",
        },
        "parameter_policy": "exact",
        "strict": True,
    },
    "Save Confirmed Order Tool": {
        "allowed_parameters": {
            "plan_id":    "string",
            "user_email": "string",
        },
        "parameter_policy": "exact",
        "strict": True,
    },

    "Routing Combinator": {
        "allowed_parameters": {},
        "parameter_policy": "exact",
        "strict": True,
    },
    "get_routing_combinations": {
        "allowed_parameters": {},
        "parameter_policy": "exact",
        "strict": True,
    },
    "count_plans": {
        "allowed_parameters": {
            "min_conf": "float",
            "routes":   "list",
        },
        "parameter_policy": "exact",
        "strict": True,
    },
}

IGNORED_TOOLS = {
    "Searching Internet...",
    "Send Mail Tool",
    "Compute Vendor Performance Tool",
    "Score Candidates Tool",
    "Evaluate Compliance Tool",
}

# ============================================================
# EVAL PROMPT (stored for critique judge)
# ============================================================

TOOL_CALL_EVAL_PROMPT = """
Role:
You are an AUTOMATED TOOL CALL VERIFICATION ENGINE.
You are a STRICT, MECHANICAL AUDITOR.
You are NOT a planner, assistant, or problem solver.
Your ONLY responsibility is to verify whether tool calls that were ACTUALLY EXECUTED conform exactly to their authoritative specifications.
You must behave deterministically.
You must not infer, repair, or reinterpret behavior.

Inputs:
{EXPECTED_TOOLS}: Authoritative specification of valid tools. Defines valid tool names, allowed parameter names per tool, parameter_policy ("exact" or "any_subset"), whether parameter format checking is enforced via "strict", and parameter formats (if defined).
{ACTUAL_TOOL_CALLS}: The complete set of tool calls that were executed. Defines the ONLY evaluation universe.

Instructions:
Evaluation Scope (Critical):
Evaluate ONLY tools listed in ACTUAL_TOOL_CALLS.
Do NOT invent, infer, or mention tools that were not called.
Do NOT penalize missing tool calls.
Do NOT apply external or domain knowledge.

Evaluation Order (Strict and Mandatory):
You MUST apply checks in the following order, with NO deviation:
1. Tool Name Check
2. Tool Parameter Check
3. Parameter Format Check

Gating Rules (Mandatory Control Flow):
If Tool Name Check = incorrect:
- Tool Parameter Check → skipped
- Parameter Format Check → skipped

If Tool Parameter Check = incorrect:
- Parameter Format Check → skipped

Check Definitions:

1. Tool Name Check
correct:
- tool_name exists as a key in EXPECTED_TOOLS
incorrect:
- tool_name does NOT exist in EXPECTED_TOOLS

2. Tool Parameter Check
Validation depends on parameter_policy defined in EXPECTED_TOOLS.

parameter_policy = "exact":
- Provided parameter keys MUST match EXACTLY
- No missing parameters
- No extra parameters

parameter_policy = "any_subset":
- Provided parameter keys MUST be a subset of allowed_parameters
- Any extra parameter NOT listed is INVALID

If Tool Name Check is incorrect, this check MUST be skipped.

3. Parameter Format Check
Validate ONLY parameter VALUE formats.
Parameter formats are defined INSIDE EXPECTED_TOOLS.
Do NOT infer or assume formats.
If no format is defined for a parameter, do NOT validate it.

If Tool Parameter Check is incorrect, this check MUST be skipped.

Allowed Judgment Values:
You MUST use ONLY:
"pass"
"fail"

Rules:
- Any skipped check MUST be marked as "fail".
- Do NOT output "skipped".

Reason Construction Rules (STRICT):

The reason field MUST include the expected schema formats
for ALL provided arguments.

Format requirements:

- Use the word "arguments" (never parameters).
- When argument format check passes, append the expected formats
  in brackets using this pattern:

  expected_formats: arg1(type), arg2(type)

Example:
"Tool recognized; provided arguments comply with exact policy; argument value types align with schema expectations; expected_formats: vendor_id_1(string), vendor_id_2(string)."

Rules:

- expected_formats MUST come from EXPECTED_TOOLS.allowed_parameters.
- Include ONLY arguments that were provided in the ACTUAL_TOOL_CALL.
- Maintain professional audit tone.
- Do NOT add recommendations or suggestions.

Output Format:
Return ONLY a JSON object with the following structure:
{
  "tools": [
    {
      "tool_name": "string",
      "tool_name_check": "correct | incorrect",
      "tool_parameter_check": "correct | incorrect | skipped",
      "parameter_format_check": "correct | incorrect | skipped",
      "reason": "short, precise justification"
    }
  ],
  "overall_reason": "High-level assessment of tool-call correctness"
}

Few Shot Examples:

Example 1 — Fully Correct Tool Call

EXPECTED_TOOLS:
{
  "analytics_vendors_find": {
    "allowed_parameters": ["base_location", "limit"],
    "parameter_policy": "any_subset",
    "strict": false
  }
}

ACTUAL_TOOL_CALLS:
[{"tool_name": "analytics_vendors_find", "parameters": {"base_location": "BOSTON"}}]

Output:
{
  "tools": [
    {
      "tool_name": "analytics_vendors_find",
      "tool_name_check": "pass",
      "tool_parameter_check": "pass",
      "parameter_format_check": "pass",
      "reason": "Tool recognized; provided arguments comply with subset policy; argument value types align with schema expectations; expected_formats: base_location(string)."
    }
  ],
  "overall_reason": "All executed tools conform to their specifications."
}

Example 2 — Incorrect Tool Name

ACTUAL_TOOL_CALLS:
[{"tool_name": "analytics_vendor_search", "parameters": {"base_location": "BOSTON"}}]

Output:
{
  "tools": [
    {
      "tool_name": "analytics_vendor_search",
      "tool_name_check": "fail",
      "tool_parameter_check": "fail",
      "parameter_format_check": "fail",
      "reason": "Tool not recognized; executed tool is not present in EXPECTED_TOOLS."
    }
  ],
  "overall_reason": "At least one executed tool is not defined in EXPECTED_TOOLS."
}

Example 3 — Argument Mismatch (Exact Policy)

ACTUAL_TOOL_CALLS:
[{"tool_name": "analytics_confirmed_order_lookup", "parameters": {"order_id": "123", "status": "confirmed"}}]

Output:
{
  "tools": [
    {
      "tool_name": "analytics_confirmed_order_lookup",
      "tool_name_check": "pass",
      "tool_parameter_check": "fail",
      "parameter_format_check": "fail",
      "reason": "Tool recognized; provided arguments violate exact policy due to unexpected argument 'status'; expected_formats: order_id(string)."
    }
  ],
  "overall_reason": "One or more executed tools violate argument policy constraints."
}
""".strip()


# ============================================================
# STEP 1: EXTRACT ACTUAL TOOL CALLS
# ============================================================

def extract_tool_calls_from_trace(trace_id: str) -> List[Dict[str, Any]]:
    """Extract all non-ignored tool calls from a LangSmith trace."""
    client = Client(api_key=os.environ["LANGSMITH_API_KEY"])
    runs   = list(client.list_runs(trace_id=trace_id))

    calls = []
    for run in runs:
        if run.run_type != "tool":
            continue
        if run.name in IGNORED_TOOLS:
            continue

        raw_input = run.inputs.get("input", {})
        if isinstance(raw_input, str):
            try:
                raw_input = ast.literal_eval(raw_input)
            except Exception:
                raw_input = {"raw": raw_input}

        calls.append({
            "tool_name":  run.name,
            "parameters": raw_input,
        })

    return calls


# ============================================================
# STEP 2: LLM DIAGNOSTICS
# ============================================================

def evaluate_tool_calls(
    expected_tools: Dict,
    actual_tool_calls: List[Dict],
    llm: AzureChatOpenAI,
) -> Dict:
    """Run LLM audit over tool calls."""
    user_prompt = f"""
EXPECTED TOOLS (AUTHORITATIVE SPECIFICATION):
{json.dumps(expected_tools, indent=2)}

ACTUAL TOOL CALLS (OBSERVED EXECUTION):
{json.dumps(actual_tool_calls, indent=2)}

Return EXACTLY the JSON format defined in the prompt.
"""
    response = llm.invoke([
        {"role": "system", "content": TOOL_CALL_EVAL_PROMPT},
        {"role": "user",   "content": user_prompt},
    ])
    return json.loads(response.content)


# ============================================================
# STEP 3: PYTHON PARAMETER FORMAT VALIDATION
# ============================================================

TYPE_CHECKERS = {
    "string": lambda v: isinstance(v, str) and v.strip() != "",
    "int":    lambda v: isinstance(v, int),
    "float":  lambda v: isinstance(v, float),
    "bool":   lambda v: isinstance(v, bool),
    "list":   lambda v: isinstance(v, list),
    "dict":   lambda v: isinstance(v, dict),
    "null":   lambda v: v is None,
    "any":    lambda v: True,
    "empty":  lambda v: v == "",
}


def mark_unknown_tools(diagnostics: Dict) -> Dict:
    """Force-fail any tool the LLM didn't recognise as unknown."""
    for tool in diagnostics["tools"]:
        if tool.get("tool_name") not in EXPECTED_TOOLS:
            tool["tool_name_check"]        = "fail"
            tool["tool_parameter_check"]   = "N/A"
            tool["parameter_format_check"] = "N/A"
    return diagnostics


def build_tool_traceback(
    tool_name: str,
    parameters: Dict,
    tool_spec: Dict,
) -> Dict:
    """Build structured traceback for a single tool call."""
    allowed = tool_spec.get("allowed_parameters", {})
    return {
        "tool_name": tool_name,
        "parameters": {
            k: {"value": v, "expected_format": allowed.get(k, "any")}
            for k, v in parameters.items()
        },
    }


def validate_parameter_formats(
    tool_name: str,
    parameters: Dict,
    tool_spec: Dict,
) -> str:
    """Return 'pass' or 'fail' based on Python type checking."""
    expected_formats = tool_spec["allowed_parameters"]

    for param, value in parameters.items():
        expected_type_spec = expected_formats.get(param)
        if not expected_type_spec:
            continue

        allowed_types = expected_type_spec.split("/")
        matched = any(
            TYPE_CHECKERS.get(t) and TYPE_CHECKERS[t](value)
            for t in allowed_types
        )
        if not matched:
            return "fail"

    return "pass"


def attach_format_checks(
    diagnostics: Dict,
    actual_tool_calls: List[Dict],
) -> Dict:
    """Override parameter_format_check with Python validation results."""
    call_map = {c["tool_name"]: c for c in actual_tool_calls}

    for tool_diag in diagnostics["tools"]:
        name = tool_diag["tool_name"]

        if name not in EXPECTED_TOOLS:
            tool_diag["parameter_format_check"] = "N/A"
            continue

        if tool_diag.get("tool_parameter_check") != "pass":
            tool_diag["parameter_format_check"] = "N/A"
            continue

        params = call_map.get(name, {}).get("parameters", {})
        spec   = EXPECTED_TOOLS[name]
        tool_diag["parameter_format_check"] = validate_parameter_formats(
            name, params, spec
        )

    return diagnostics


def normalize_pass_fail(diagnostics: Dict) -> Dict:
    """Ensure consistent pass/fail labels (no-op guard)."""
    for tool in diagnostics["tools"]:
        if tool.get("tool_parameter_check") == "N/A":
            continue
        tool["tool_name_check"]        = tool.get("tool_name_check")
        tool["tool_parameter_check"]   = tool.get("tool_parameter_check")
        tool["parameter_format_check"] = tool.get("parameter_format_check")
    return diagnostics


# ============================================================
# STEP 4: SCORING
# ============================================================

def compute_tool_call_score(
    expected_tools: Dict,
    diagnostics: Dict,
) -> float:
    """Score = passed_tools / total_tools."""
    tools = diagnostics.get("tools", [])
    if not tools:
        return 1.0

    passed = 0
    total  = len(tools)

    for diag in tools:
        name = diag["tool_name"]
        spec = expected_tools.get(name)

        if not spec:
            continue
        if diag.get("tool_name_check")      != "pass":
            continue
        if diag.get("tool_parameter_check") != "pass":
            continue
        if spec["strict"] and diag.get("parameter_format_check") != "pass":
            continue

        passed += 1

    return round(passed / total, 2)


# ============================================================
# ENTRYPOINT — signature matches main.py call:
#   run_tool_call_accuracy_eval(trace_id, scenario, llm_client)
# ============================================================

def run_tool_call_accuracy_eval(
    trace_id: str,
    scenario: str,
    llm: AzureChatOpenAI,
) -> Dict[str, Any]:
    """
    Full tool-call accuracy evaluation pipeline.

    Returns a result dict compatible with main.py:
      - status        : "success" | "failed"
      - score         : float 0-1
      - overall_reason: str
      - eval_prompt   : str  (for critique judge)
      - eval_inputs   : dict (for critique judge)
      - eval_output   : dict (for critique judge)
    """
    try:
        actual_tool_calls = extract_tool_calls_from_trace(trace_id)

        diagnostics = evaluate_tool_calls(EXPECTED_TOOLS, actual_tool_calls, llm)
        diagnostics = mark_unknown_tools(diagnostics)
        diagnostics = attach_format_checks(diagnostics, actual_tool_calls)
        diagnostics = normalize_pass_fail(diagnostics)

        score = compute_tool_call_score(EXPECTED_TOOLS, diagnostics)

        # Attach per-tool tracebacks
        call_map = {c["tool_name"]: c for c in actual_tool_calls}
        for tool in diagnostics["tools"]:
            name   = tool["tool_name"]
            params = call_map.get(name, {}).get("parameters", {})
            spec   = EXPECTED_TOOLS.get(name, {})
            tool["traceback"] = build_tool_traceback(name, params, spec)

        return {
            "eval_name":      "tool_call_accuracy",
            "eval_type":      "hybrid",
            "trace_id":       trace_id,
            "scenario":       scenario,
            "status":         "success",
            "score":          score,
            "overall_reason": diagnostics.get("overall_reason", ""),
            # ── critique judge fields ──────────────────────────────
            "eval_prompt":  TOOL_CALL_EVAL_PROMPT,
            "eval_inputs": {
                "expected_tools":    EXPECTED_TOOLS,
                "actual_tool_calls": actual_tool_calls,
            },
            "eval_output": diagnostics,
            # ── metadata ──────────────────────────────────────────
            "metadata": {
                "model":       "gpt-5",
                "temperature": 1,
                "timestamp":   datetime.utcnow().isoformat(),
            },
        }

    except Exception as e:
        return {
            "eval_name":      "tool_call_accuracy",
            "eval_type":      "hybrid",
            "trace_id":       trace_id,
            "scenario":       scenario,
            "status":         "failed",
            "error":          str(e),
            # FIX: eval_output missing in original failed path
            "eval_output":    {},
            "score":          0.0,
            "overall_reason": "",
        }


# ============================================================
# EXCEL DUMP — new logger logic, original sheet/file name kept
# ============================================================

def dump_tool_call_eval_to_excel(
    *,
    trace_id: str,
    query: str,
    eval_result: Dict[str, Any],
    excel_path: str = "final_eval_results.xlsx",
):
    """
    Save tool call accuracy results to Excel.

    Sheet : "Tool Call Accuracy"  (matches EVAL_SHEET_MAP in main.py)
    Headers:
        Query | Tool Name | Tool Name accuracy |
        Tool Schema-Parameter Accuracy | Tool Schema-Format Accuracy |
        Reason | Overall Score | Overall Reason | Tracebacks
    """
    from openpyxl import Workbook, load_workbook
    from pathlib import Path

    SHEET_NAME = "Tool Call Accuracy"
    HEADERS = [
        "Query",
        "Tool Name",
        "Tool Name accuracy",
        "Tool Schema-Parameter Accuracy",
        "Tool Schema-Format Accuracy",
        "Reason",
        "Overall Score",
        "Overall Reason",
        "Tracebacks",
    ]

    # Open or create workbook
    if Path(excel_path).exists():
        wb = load_workbook(excel_path)
    else:
        wb = Workbook()
        wb.remove(wb.active)

    # Find or create sheet (case-insensitive match)
    target  = SHEET_NAME.strip().lower()
    matched = next((s for s in wb.sheetnames if s.strip().lower() == target), None)
    if matched is None:
        ws = wb.create_sheet(SHEET_NAME)
        ws.append(HEADERS)
    else:
        ws = wb[matched]

    eval_output    = eval_result.get("eval_output", {})
    tools          = eval_output.get("tools", [])
    overall_score  = eval_result.get("score", "")
    overall_reason = eval_output.get("overall_reason", "")

    if eval_result.get("status") == "failed":
        ws.append([
            query,
            "",     # Tool Name
            "fail", # Tool Name accuracy
            "fail", # Tool Schema-Parameter Accuracy
            "fail", # Tool Schema-Format Accuracy
            eval_result.get("error", "Unknown error"),
            overall_score,
            overall_reason,
            "",     # Tracebacks
        ])
    elif not tools:
        # No tool calls found
        ws.append([
            query,
            None,
            "fail",
            "fail",
            "fail",
            "No tool calls found in trace.",
            overall_score,
            overall_reason,
            None,
        ])
    else:
        # One row per tool call
        for tool in tools:
            ws.append([
                query,
                tool.get("tool_name",            ""),
                tool.get("tool_name_check",       ""),   # pass / fail
                tool.get("tool_parameter_check",  ""),   # pass / fail
                tool.get("parameter_format_check",""),   # pass / fail
                tool.get("reason",                ""),
                overall_score,
                overall_reason,
                json.dumps(tool.get("traceback"), ensure_ascii=False),
            ])

    wb.save(excel_path)