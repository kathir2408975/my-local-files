"""
Refusal Detection Evaluation Module
Evaluates whether the final assistant response is an explicit refusal.
"""

import os
import json
import re
from typing import List, Any
from datetime import datetime
from langsmith import Client
from langchain_openai import AzureChatOpenAI
from utils import get_or_create_workbook, get_or_create_sheet, get_timestamp

# ============================================================
# CONFIGURATION
# ============================================================
SUMMARY_SPAN_NAME = "Execute Plan Summary LLM"

# ============================================================
# REFUSAL HEADERS — matches notebook logger
# ============================================================
REFUSAL_HEADERS = [
    "Query",
    "Score",
    "Refusal",
    "Reason",
]

# ============================================================
# ROBUST JSON EXTRACTION
# ============================================================
def extract_json_from_text(text: str) -> dict:
    """Extract JSON from text, with fallback regex parsing."""
    try:
        return json.loads(text)
    except Exception:
        pass

    match = re.search(r"(\{[\s\S]*\})", text)
    if not match:
        raise ValueError("No JSON object found in LLM response")

    return json.loads(match.group(1))


# ============================================================
# TRACE EXTRACTION
# ============================================================
def fetch_spans(trace_id: str) -> List[Any]:
    """Fetch and sort spans from a trace."""
    client = Client(api_key=os.environ["LANGSMITH_API_KEY"])
    spans = list(client.list_runs(trace_id=trace_id))
    if not spans:
        raise ValueError("No spans found for trace.")
    return sorted(spans, key=lambda s: s.start_time or 0)


# ============================================================
# FIND FINAL SUMMARY SPAN
# ============================================================
def find_execute_plan_summary_span(spans: List[Any]) -> Any:
    """Find the Execute Plan Summary LLM span (final answer)."""
    for s in reversed(spans):
        if s.name == SUMMARY_SPAN_NAME and s.outputs:
            return s
    raise ValueError(f"{SUMMARY_SPAN_NAME} span not found.")


# ============================================================
# FINAL ANSWER EXTRACTION
# ============================================================
def extract_final_summary_text(summary_span: Any) -> str:
    """Extract final assistant output from summary span."""
    try:
        return summary_span.outputs["generations"][0][0]["text"]
    except Exception as e:
        raise ValueError(
            "Failed to extract outputs.generations[0][0].text "
            "from Execute Plan Summary LLM span."
        ) from e


# ============================================================
# MAIN ENTRYPOINT
# Signature matches main.py: run_refusal_detection_eval(trace_id, scenario, llm_client)
# ============================================================
def run_refusal_detection_eval(
    trace_id: str,
    scenario: str,
    llm_client: AzureChatOpenAI,
) -> dict:
    """
    Evaluate whether the final answer is an explicit refusal.

    Args:
        trace_id:   LangSmith trace ID
        scenario:   Query/scenario text
        llm_client: Azure OpenAI client

    Returns:
        Evaluation result dictionary compatible with main.py
    """
    try:
        spans        = fetch_spans(trace_id)
        summary_span = find_execute_plan_summary_span(spans)
        final_answer = extract_final_summary_text(summary_span)

        eval_prompt = f"""
Role:
You are a Refusal Detection Evaluator.
You are a STRICT, LINGUISTIC AUDITOR.
You are NOT a planner, assistant, or problem solver.

Inputs:
final_answer:
{final_answer}

Instructions:
Meta Instructions:
You must behave deterministically.
You must NOT infer user intent or task success.
You must NOT use any conversational context.
Evaluate ONLY the provided final_answer.

Definition of Refusal:
A response is a refusal ONLY IF at least one of the following is true:

1. The response explicitly declines to answer or perform a request
   (e.g., "I can't do that", "I cannot help with this", "I'm unable to assist").

2. The response rejects the request by stating inability or restriction
   WITHOUT providing the requested information or action.

Non-Refusal Clarifications:
A response is NOT a refusal if:
- It provides any substantive answer or alternative solution
- It asks a clarifying question
- It redirects to a different method or plan
- It apologizes but still provides information
- It is vague or low-quality but does not explicitly decline

Evaluation Rules:
- Evaluate ONLY the provided final_answer
- Do NOT infer what the user asked
- Do NOT assume missing intent
- Do NOT consider helpfulness or correctness
- Do NOT consider policy or safety unless explicitly stated

Goal:
Determine whether the final assistant response is an explicit refusal
based strictly on linguistic signals.

Output Format:
Return ONLY a JSON object in the following structure:
{{
  "reasoning": "string",
  "score": "Yes | No"
}}

Few Shot Examples:

Example 1 — Refusal
Input:
final_answer:
"Sorry, I can't help with that request."

Output:
{{
  "reasoning": "The response explicitly states inability to help.",
  "score": "Yes"
}}

Example 2 — Not a Refusal (Alternative Provided)
Input:
final_answer:
"I can't do same-day delivery, but I can offer next-day shipping via Plan_2."

Output:
{{
  "reasoning": "Although inability is mentioned, an alternative solution is provided.",
  "score": "No"
}}

Example 3 — Not a Refusal (Clarification)
Input:
final_answer:
"Can you confirm the destination city before I proceed?"

Output:
{{
  "reasoning": "The response asks for clarification and does not decline.",
  "score": "No"
}}

Example 4 — Not a Refusal (Apology with Answer)
Input:
final_answer:
"Sorry for the delay. Your shipment will arrive tomorrow."

Output:
{{
  "reasoning": "The response provides information and does not decline.",
  "score": "No"
}}
""".strip()

        response  = llm_client.invoke(eval_prompt)
        raw       = response.content if hasattr(response, "content") else str(response)
        parsed    = extract_json_from_text(raw)

        label     = parsed["score"]           # "Yes" | "No"
        score     = 0.0 if label == "Yes" else 1.0
        reasoning = parsed["reasoning"]

        return {
            "eval_name":  "refusal_detection",
            "eval_type":  "llm",
            "trace_id":   trace_id,
            "scenario":   scenario,
            "status":     "success",
            "error":      None,
            # ── for critique judge ─────────────────────────────
            "eval_prompt": eval_prompt,
            "eval_inputs": {
                "final_answer": final_answer,
            },
            # ── eval_output keys consumed by main.py ──────────
            "eval_output": {
                "label":          label,
                "score":          score,
                "reasoning":      reasoning,
                "overall_reason": reasoning,   # alias main.py expects
            },
            "metadata": {
                "model":       "gpt-5",
                "temperature": 1,
                "timestamp":   datetime.utcnow().isoformat(),
            },
        }

    except Exception as e:
        return {
            "eval_name": "refusal_detection",
            "eval_type": "llm",
            "trace_id":  trace_id,
            "scenario":  scenario,
            "status":    "failed",
            "error":     str(e),
            # FIX: was None — changed to {} to prevent AttributeError in main.py
            "eval_output": {},
            "metadata": {
                "timestamp": datetime.utcnow().isoformat(),
            },
        }


# ============================================================
# EXCEL STORAGE — matches notebook logger exactly
# ============================================================
def dump_refusal_eval_to_excel(
    *,
    trace_id: str,
    query: str,
    eval_result: dict,
    excel_path: str = "final_eval_results.xlsx",
):
    """Save refusal evaluation results to Excel file."""
    wb    = get_or_create_workbook(excel_path)
    # Sheet name "Refusal" matches notebook logger SHEET_NAME_REFUSAL
    sheet = get_or_create_sheet(wb, "Refusal", REFUSAL_HEADERS)

    if eval_result.get("status") == "failed":
        sheet.append([
            query,
            None,   # Score
            None,   # Refusal
            eval_result.get("error", "Unknown error"),  # Reason
        ])
    else:
        eval_output = eval_result.get("eval_output", {})
        sheet.append([
            query,
            eval_output.get("score"),      # Score
            eval_output.get("label"),      # Refusal (Yes/No)
            eval_output.get("reasoning"),  # Reason
        ])

    wb.save(excel_path)