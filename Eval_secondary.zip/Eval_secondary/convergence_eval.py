"""
Convergence Evaluation Module
Evaluates whether the agent's execution steps converge on the optimal path.
"""

import os
import json
from typing import List, Any, Dict, Tuple, Set
from datetime import datetime
from langsmith import Client
from utils import get_or_create_workbook, get_or_create_sheet

# ============================================================
# REFERENCE TRAJECTORY (OPTIMAL PATH)
# ============================================================

REFERENCE_OUTPUTS = [
    "Supervisor",
    "Supervisor Process",
    "ContextBuilder",
    "Context Builder Process",
    "Fetch Vendors Tool",
    "Fetch Performance History",
    "Web Search Tool",
    "Web Search Tool",
    "Web Search Tool",
    "Web Search Tool",
    "Context Builder Summarization Process",
    "Supervisor",
    "Supervisor Process",
    "TaskPlanner",
    "TaskPlanner Process",
    "Routing Combinator",
    "Forecast",
    "Forecast_Agent",
    "Forecast_Process",
    "Calculate Extra Charges Tool",
    "Calculate Delivery Cost Tool",
    "Calculate Delivery Time Tool",
    "Calculate Forecast Confidence Tool",
    "Forecast_Process",
    "Calculate Extra Charges Tool",
    "Calculate Delivery Cost Tool",
    "Calculate Delivery Time Tool",
    "Calculate Forecast Confidence Tool",
    "Critique",
    "Critique_Agent",
    "get_routing_combinations",
    "count_plans",
    "Optimization",
    "Optimization_Agent",
    "Load Optimization Data Tool",
    "Compute Vendor Performance Tool",
    "Score Candidates Tool",
    "Optimization Process",
    "Compliance",
    "Compliance_Agent",
    "Load Compliance Data Tool",
    "Check Holiday Event Tool",
    "Evaluate Compliance Tool",
    "Compliance Process",
    "Supervisor",
    "Supervisor Process",
    "Execute",
    "Execute Process",
    "Execute Tool Calling Process",
    "Get Plan Information Tool",
    "Save Confirmed Order Tool",
    "Send Mail Tool",
    "Supervisor",
    "Supervisor Process",
]

# ============================================================
# FILTERING
# ============================================================

IGNORE_PREFIXES = ("Runnable", "Pydantic", "Chat")
IGNORE_EXACT = {"model", "tools", "LangGraph"}
IGNORE_SUFFIXES = ("LLM",)

def is_ignored(name: str) -> bool:
    """Check if a span name should be ignored."""
    if name in IGNORE_EXACT:
        return True
    if name.startswith(IGNORE_PREFIXES):
        return True
    if name.endswith(IGNORE_SUFFIXES):
        return True
    return False

# ============================================================
# TRACE EXTRACTION
# ============================================================

def fetch_spans(trace_id: str) -> List[Any]:
    """Fetch all spans for a given trace ID."""
    client = Client(api_key=os.environ["LANGSMITH_API_KEY"])
    spans = list(client.list_runs(trace_id=trace_id))
    if not spans:
        raise ValueError("No spans found for trace.")
    return sorted(spans, key=lambda r: r.start_time or 0)

# ============================================================
# ACTUAL OUTPUTS EXTRACTION
# ============================================================

def extract_actual_outputs(trace_id: str) -> List[str]:
    """Extract actual execution steps from trace, filtering noise."""
    runs = fetch_spans(trace_id)
    actual = []
    for run in runs:
        name = run.name
        if is_ignored(name):
            continue
        actual.append(name)
    return actual

# ============================================================
# CONVERGENCE SCORING
# ============================================================

def compute_convergence_score(reference: List[str], actual: List[str]) -> float:
    """
    Compute convergence score = optimal_steps / actual_steps
    Score is capped at 1.0
    """
    optimal_steps = len(reference)
    actual_steps = len(actual)
    
    if actual_steps == 0:
        return 0.0
    
    return round(min(optimal_steps / actual_steps, 1.0), 3)

# ============================================================
# ALIGNMENT ANALYSIS
# ============================================================

def compute_alignment(
    reference: List[str],
    actual: List[str],
    score: float
) -> Tuple[str, str, List[str], List[str]]:
    """Compute alignment status, reasoning, missing and extra steps."""
    
    optimal_steps = len(reference)
    actual_steps = len(actual)
    extra_count = max(actual_steps - optimal_steps, 0)
    
    ref_set: Set[str] = set(reference)
    act_set: Set[str] = set(actual)
    
    # Steps in reference but missing from actual
    missing_steps = sorted(ref_set - act_set)
    
    # Steps in actual but not in reference
    extra_steps = sorted(act_set - ref_set)
    
    if score == 1.0:
        status = "Aligned"
        reasoning = (
            f"The agent completed the task in exactly {actual_steps} steps, "
            f"matching the optimal path perfectly. No unnecessary steps were detected."
        )
    elif score >= 0.75:
        status = "Partially_Aligned"
        reasoning = (
            f"The agent took {actual_steps} steps versus the optimal {optimal_steps}, "
            f"introducing {extra_count} extra step(s). "
            f"Efficiency is acceptable but there is minor wandering ({score:.1%} convergence)."
        )
    elif score >= 0.50:
        status = "Partially_Aligned"
        reasoning = (
            f"The agent took {actual_steps} steps versus the optimal {optimal_steps}, "
            f"with {extra_count} unnecessary step(s). "
            f"Noticeable inefficiency detected — convergence score is {score:.1%}."
        )
    else:
        status = "Not_Aligned"
        reasoning = (
            f"The agent significantly over-executed, taking {actual_steps} steps "
            f"against an optimal path of {optimal_steps} steps ({extra_count} extra). "
            f"Convergence score of {score:.1%} indicates excessive wandering."
        )
    
    return status, reasoning, missing_steps, extra_steps

# ============================================================
# FULL PIPELINE
# ============================================================

def run_convergence_eval(trace_id: str, scenario: str) -> Dict[str, Any]:
    """Full convergence evaluation pipeline."""
    try:
        # Extract actual outputs from trace
        actual_outputs = extract_actual_outputs(trace_id)
        
        # Compute convergence score
        convergence_score = compute_convergence_score(REFERENCE_OUTPUTS, actual_outputs)
        
        # Compute alignment
        alignment_status, reasoning, missing_steps, extra_steps = compute_alignment(
            REFERENCE_OUTPUTS,
            actual_outputs,
            convergence_score
        )
        
        return {
            "eval_name": "convergence",
            "trace_id": trace_id,
            "scenario": scenario,
            "eval_inputs": {
                "reference_outputs": REFERENCE_OUTPUTS,
                "actual_outputs": actual_outputs
            },
            "eval_output": {
                "optimal_steps": len(REFERENCE_OUTPUTS),
                "actual_steps": len(actual_outputs),
                "extra_steps_count": max(len(actual_outputs) - len(REFERENCE_OUTPUTS), 0),
                "missing_steps": missing_steps,
                "extra_steps": extra_steps,
                "alignment_status": alignment_status,
                "reasoning": reasoning
            },
            "metadata": {
                "model": "python_rule_based",
                "timestamp": datetime.utcnow().isoformat()
            },
            "status": "completed",
            "score": convergence_score
        }
    except Exception as e:
        return {
            "eval_name": "convergence",
            "trace_id": trace_id,
            "scenario": scenario,
            "eval_inputs": {},
            "eval_output": {},
            "metadata": {
                "model": "python_rule_based",
                "timestamp": datetime.utcnow().isoformat()
            },
            "status": "failed",
            "error": str(e),
            "score": 0.0
        }

# ============================================================
# EXCEL OUTPUT
# ============================================================

def dump_convergence_eval_to_excel(
    *,
    trace_id: str,
    query: str,
    eval_result: dict,
    excel_path: str = "final_eval_results.xlsx",
):
    """Save convergence evaluation results to Excel."""
    
    SHEET_NAME = "Convergence"
    HEADERS = [
        "Query",
        "Reference_Output",
        "Actual_Output",
        "Optimal_Steps",
        "Actual_Steps",
        "Extra_Steps_Count",
        "Missing_Steps",
        "Extra_Steps",
        "Alignment_Status",
        "Overall_Score",
        "Overall_Reason",

    ]
    
    wb = get_or_create_workbook(excel_path)
    sheet = get_or_create_sheet(wb, SHEET_NAME, HEADERS)
    
    eval_inputs = eval_result.get("eval_inputs", {})
    eval_output = eval_result.get("eval_output", {})
    score = eval_result.get("score", "")
    
    if eval_result.get("status") == "failed":
        sheet.append([
            query,
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            eval_result.get("error", "Unknown error")
        ])
    else:
        reference_outputs = json.dumps(eval_inputs.get("reference_outputs", []))
        actual_outputs = json.dumps(eval_inputs.get("actual_outputs", []))
        missing_steps = json.dumps(eval_output.get("missing_steps", []))
        extra_steps = json.dumps(eval_output.get("extra_steps", []))
        
        sheet.append([
            query,
            reference_outputs,
            actual_outputs,
            eval_output.get("optimal_steps", ""),
            eval_output.get("actual_steps", ""),
            eval_output.get("extra_steps_count", ""),
            missing_steps,
            extra_steps,
            eval_output.get("alignment_status", ""),
            score,
            eval_output.get("reasoning", "")
        ])
    
    wb.save(excel_path)
