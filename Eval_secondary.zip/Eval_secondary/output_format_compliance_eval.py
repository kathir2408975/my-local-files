"""
Output Format Compliance Evaluation Module
Evaluates whether PydanticOutputParser outputs are well-formed JSON.
"""

import os
import json
import re
from typing import List, Any, Dict
from datetime import datetime
from uuid import UUID
from langsmith import Client
from langchain_openai import AzureChatOpenAI
from utils import get_or_create_workbook, get_or_create_sheet

# ============================================================
# TRACE EXTRACTION
# ============================================================

def fetch_spans(trace_id: str) -> List[Any]:
    """Fetch all spans for a given trace ID."""
    client = Client(api_key=os.environ["LANGSMITH_API_KEY"])
    spans = list(client.list_runs(trace_id=trace_id))
    if not spans:
        raise ValueError("No spans found for trace.")
    return sorted(spans, key=lambda r: r.start_time or 0)

# ============================================================
# SPAN FILTERING
# ============================================================

TARGET_SPAN_NAMES = {"PydanticOutputParser"}

def filter_target_spans(spans: List[Any]) -> List[Any]:
    """Filter spans to only PydanticOutputParser spans."""
    return sorted(
        [s for s in spans if s.name in TARGET_SPAN_NAMES],
        key=lambda s: s.start_time or 0
    )

# ============================================================
# JSON SERIALIZATION
# ============================================================

def uuid_serializer(obj: Any) -> str:
    """Serialize UUID objects to strings for JSON."""
    if isinstance(obj, UUID):
        return str(obj)
    raise TypeError(f"Object of type {obj.__class__.__name__} is not JSON serializable")

# ============================================================
# JSON PARSING
# ============================================================

def safe_json_load(raw: str) -> Dict[str, Any]:
    """Safely parse JSON from LLM output, handling markdown code blocks."""
    raw = raw.strip()
    if raw.startswith("```"):
        raw = raw.strip("`").strip()
        if raw.lower().startswith("json"):
            raw = raw[4:].strip()

    decoder = json.JSONDecoder()
    obj, _ = decoder.raw_decode(raw)
    return obj

# ============================================================
# FORMAT COMPLIANCE EVALUATION
# ============================================================

def evaluate_output_format_compliance(
    filtered_spans: List[Any],
    llm_client: AzureChatOpenAI,
) -> Dict[str, Any]:
    """Evaluate JSON format compliance of PydanticOutputParser spans."""

    eval_prompt = {
        "meta_instruction": (
            "Follow the analysis internally but output ONLY the final JSON object "
            "that conforms exactly to the output_structure_mandate."
        ),
        "metric_name": "PydanticOutputParser - JSON Format Compliance",
        "role": (
            "You are an Output Format Compliance Auditor specializing in PydanticOutputParser spans. "
            "Each span represents an attempt by LangChain's PydanticOutputParser to parse LLM output "
            "into a structured Pydantic model. Evaluate each span independently, then provide an overall summary. "
            "You MUST NOT invent data or infer beyond the provided spans."
        ),
        "goal": (
            "For each PydanticOutputParser span, determine whether the output is a well-formed, "
            "valid JSON object - free of extra prose, markdown artifacts, or structural issues. "
            "IMPORTANT: If span_outputs is empty or null, set json_output_accuracy to 'SKIP' - "
            "this means the span had no output (likely due to an upstream error) and should NOT be "
            "evaluated for JSON format compliance. "
            "Only evaluate spans where span_outputs contains actual data. "
            "Do NOT assess span success/failure status or exceptions. "
            "Do NOT compute numeric scores."
        ),
        "inputs": {
            "spans": "List of PydanticOutputParser spans with span_id, span_name, span_inputs, span_outputs"
        },
        "rubric": {
            "PASS": (
                "span_outputs is non-empty AND the parsed output is a clean, well-formed JSON object "
                "with no extra prose, no markdown fences, and no structural corruption."
            ),
            "FAIL": (
                "span_outputs is non-empty BUT the output is malformed JSON, contains extra text or "
                "markdown outside the JSON structure, is an unexpected type (e.g. plain string or array "
                "when an object is expected), or is structurally corrupted."
            ),
            "SKIP": (
                "span_outputs is empty or null. This span is excluded from evaluation entirely. "
                "Do NOT treat this as a failure - the span simply has no output to evaluate."
            )
        },
        "what_to_check": [
            "FIRST: Check if span_outputs is empty or null. If so, assign SKIP and stop evaluation for this span.",
            "If span_outputs has data: Check if the parsed output is a clean, well-formed JSON object.",
            "Verify there is no stray text, markdown fences, or prose mixed into the output.",
            "Verify the output is a JSON object (dict), not a raw string or unexpected type.",
            "Do NOT check for errors, exceptions, or span execution status.",
            "Do NOT mark empty spans as FAIL - use SKIP instead."
        ],
        "analysis_approach": [
            "Iterate through each span independently.",
            "Check span_outputs first: if empty/null -> assign SKIP, move to next span.",
            "If span_outputs has data: inspect for a clean, well-formed JSON object.",
            "Check for stray text, markdown artifacts, or structural issues in the output.",
            "Assign PASS or FAIL based solely on JSON format correctness.",
            "After evaluating all spans, provide a concise overall summary covering only evaluated (non-SKIP) spans."
        ],
        "output_structure_mandate": {
            "type": "object",
            "properties": {
                "per_span_results": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "span_id":   {"type": "string"},
                            "span_name": {"type": "string"},
                            "json_output_accuracy": {
                                "type": "string",
                                "description": "PASS | FAIL | SKIP"
                            },
                            "failure_reason": {
                                "type": "string",
                                "description": (
                                    "Empty string if PASS or SKIP. "
                                    "Specific JSON format issue if FAIL."
                                )
                            }
                        },
                        "required": [
                            "span_id",
                            "span_name",
                            "json_output_accuracy",
                            "failure_reason"
                        ]
                    }
                },
                "overall_reason": {"type": "string"}
            },
            "required": ["per_span_results", "overall_reason"]
        }
    }

    payload = {
        "spans": [
            {
                "span_id":      str(span.id),
                "span_name":    span.name,
                "span_inputs":  span.inputs  or {},
                "span_outputs": span.outputs or {},
            }
            for span in filtered_spans
        ]
    }

    messages = [
        ("system", json.dumps(eval_prompt, indent=2)),
        ("human",  json.dumps(payload, indent=2, default=uuid_serializer)),
    ]

    response = llm_client.invoke(messages)

    try:
        parsed_eval = safe_json_load(response.content)
    except (json.JSONDecodeError, ValueError) as e:
        raise ValueError(f"Failed to parse evaluation output: {e}\n{response.content}")

    return parsed_eval

# ============================================================
# SCORING
# ============================================================

def compute_output_format_score(verification_results: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Compute format compliance score, excluding SKIP spans."""

    evaluated_results = [
        r for r in verification_results
        if r.get("json_output_accuracy") in ("PASS", "FAIL")
    ]

    skipped_results = [
        r for r in verification_results
        if r.get("json_output_accuracy") == "SKIP"
    ]

    total_count   = len(evaluated_results)
    pass_count    = sum(1 for r in evaluated_results if r.get("json_output_accuracy") == "PASS")
    fail_count    = total_count - pass_count
    skip_count    = len(skipped_results)
    overall_score = round(pass_count / total_count, 2) if total_count > 0 else 0.0

    return {
        "total_count":   total_count,
        "pass_count":    pass_count,
        "fail_count":    fail_count,
        "skip_count":    skip_count,
        "overall_score": overall_score,
    }

# ============================================================
# FULL PIPELINE
# ============================================================

def run_output_format_compliance_eval(
    trace_id: str,
    scenario: str,
    llm_client: AzureChatOpenAI,
) -> Dict[str, Any]:
    """Full output format compliance evaluation pipeline."""
    try:
        spans          = fetch_spans(trace_id)
        filtered_spans = filter_target_spans(spans)

        if not filtered_spans:
            raise ValueError("No PydanticOutputParser spans found in trace")

        parsed_eval          = evaluate_output_format_compliance(filtered_spans, llm_client)
        verification_results = parsed_eval.get("per_span_results", [])
        overall_reason       = parsed_eval.get("overall_reason", "")
        analytics            = compute_output_format_score(verification_results)

        return {
            "eval_name": "output_format_compliance",
            "trace_id":  trace_id,
            "scenario":  scenario,
            "eval_inputs": {
                "spans": [
                    {
                        "span_id":      str(span.id),
                        "span_name":    span.name,
                        "span_inputs":  span.inputs  or {},
                        "span_outputs": span.outputs or {},
                    }
                    for span in filtered_spans
                ],
                "total_spans_evaluated": len(filtered_spans),
            },
            "eval_output": {
                "per_span_results": verification_results,
                "overall_reason":   overall_reason,
            },
            "analytics": analytics,
            "metadata": {
                "model":       "gpt-5",
                "temperature": 0,
                "timestamp":   datetime.utcnow().isoformat(),
            },
            # FIX BUG 2: was "completed" — main.py summary stats use
            # ok_status="success" for output_format_compliance.
            # Changed so it is counted correctly in EVALUATION SUMMARY.
            "status": "success",
            # FIX BUG 1: "score" and "overall_reason" must be at top level
            # so main.py _get(format_result, "score") and
            # _get(format_result, "overall_reason") resolve correctly.
            "score":         analytics["overall_score"],
            "overall_reason": overall_reason,
        }

    except Exception as e:
        return {
            "eval_name":  "output_format_compliance",
            "trace_id":   trace_id,
            "scenario":   scenario,
            "eval_inputs":  {},
            "eval_output":  {},
            "analytics": {
                "total_count":   0,
                "pass_count":    0,
                "fail_count":    0,
                "skip_count":    0,
                "overall_score": 0.0,
            },
            "metadata": {
                "model":       "gpt-5",
                "temperature": 0,
                "timestamp":   datetime.utcnow().isoformat(),
            },
            "status":        "failed",
            "error":         str(e),
            "score":         0.0,
            "overall_reason": "",
        }

# ============================================================
# EXCEL OUTPUT
# ============================================================

def dump_output_format_compliance_to_excel(
    *,
    trace_id: str,
    query: str,
    eval_result: dict,
    excel_path: str = "final_eval_results.xlsx",
):
    """Save output format compliance evaluation results to Excel."""

    HEADERS = [
        "Query",
        "Json_Output_Accuracy",
        "Total_Count",
        "Pass_Count",
        "Fail_Count",
        "Skip_Count",
        "Overall_Score",
        "Overall_Reason",
        "Per_Span_Results",
    ]

    wb    = get_or_create_workbook(excel_path)
    # FIX BUG 3: was "Output Format Compliance" — caused stray sheet creation.
    # main.py EVAL_SHEET_MAP maps "output_format_compliance" → "Output format Check"
    sheet = get_or_create_sheet(wb, "Output format Check", HEADERS)

    analytics        = eval_result.get("analytics", {})
    eval_output      = eval_result.get("eval_output", {})
    total_count      = analytics.get("total_count",   0)
    pass_count       = analytics.get("pass_count",    0)
    fail_count       = analytics.get("fail_count",    0)
    skip_count       = analytics.get("skip_count",    0)
    overall_score    = analytics.get("overall_score", 0.0)
    overall_reason   = eval_output.get("overall_reason", "")
    per_span_results = eval_output.get("per_span_results", [])

    # Determine overall accuracy label
    if total_count == 0:
        json_output_accuracy = "NO_EVALUATED_SPANS"
    elif overall_score == 1.0:
        json_output_accuracy = "PASS"
    elif overall_score == 0.0:
        json_output_accuracy = "FAIL"
    else:
        json_output_accuracy = "PARTIAL"

    if eval_result.get("status") == "failed":
        sheet.append([
            query,
            "",           # Json_Output_Accuracy
            "",           # Total_Count
            "",           # Pass_Count
            "",           # Fail_Count
            "",           # Skip_Count
            "",           # Overall_Score
            eval_result.get("error", "Unknown error"),  # Overall_Reason
            "",           # Per_Span_Results
        ])
    else:
        sheet.append([
            query,
            json_output_accuracy,
            total_count,
            pass_count,
            fail_count,
            skip_count,
            overall_score,
            overall_reason,
            json.dumps(per_span_results, indent=2),
        ])

    wb.save(excel_path)