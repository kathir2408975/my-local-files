"""
Trajectory Match Evaluation Module
Evaluates whether the actual agent execution trajectory matches the reference trajectory.
"""

import os
import re
import json
from datetime import datetime
from typing import List, Dict, Any
from langsmith import Client
from langchain_openai import AzureChatOpenAI
from utils import get_or_create_workbook, get_or_create_sheet, get_timestamp

# ============================================================
# AGENT SEQUENCE DEFINITION
# ============================================================
AGENT_SEQUENCE = [
    "Supervisor",
    "Supervisor Process",
    "ContextBuilder",
    "Context Builder Process",
    "Fetch Vendors Tool",
    "Fetch Performance History",
    "Web Search Tool",
    "Web Search Tool",
    "Web Search Tool",
    "Web Search Tool",
    "Context Builder Summarization Process",
    "Supervisor",
    "Supervisor Process",
    "TaskPlanner",
    "TaskPlanner Process",
    "Routing Combinator",
    "Forecast",
    "Forecast_Agent",
    "Forecast_Process",
    "Calculate Extra Charges Tool",
    "Calculate Delivery Cost Tool",
    "Calculate Delivery Time Tool",
    "Calculate Forecast Confidence Tool",
    "Forecast_Process",
    "Calculate Extra Charges Tool",
    "Calculate Delivery Cost Tool",
    "Calculate Delivery Time Tool",
    "Calculate Forecast Confidence Tool",
    "Critique",
    "Critique_Agent",
    "get_routing_combinations",
    "count_plans",
    "Optimization",
    "Optimization_Agent",
    "Load Optimization Data Tool",
    "Compute Vendor Performance Tool",
    "Score Candidates Tool",
    "Optimization Process",
    "Compliance",
    "Compliance_Agent",
    "Load Compliance Data Tool",
    "Check Holiday Event Tool",
    "Evaluate Compliance Tool",
    "Compliance Process",
    "Supervisor",
    "Supervisor Process",
    "Execute",
    "Execute Process",
    "Execute Tool Calling Process",
    "Get Plan Information Tool",
    "Save Confirmed Order Tool",
    "Send Mail Tool",
    "Supervisor",
    "Supervisor Process",
]

ALL_MODES = ["strict", "unordered", "subset", "superset"]

# ============================================================
# TRADEOFF SCENARIOS
# Acceptable deviations that must be treated as neutral
# during evaluation if encountered.
# Note: avoid words like "Ignore" — Azure content filters
# may flag them. Use "Treat as neutral behaviour" instead.
# ============================================================
TRADEOFF_SCENARIOS = [
    "Repeated Supervisor exchanges may occur during clarification cycles.",
    "Additional Web Search Tool calls beyond the reference count are acceptable.",
]

def build_tradeoff_text(tradeoffs: list) -> str:
    if not tradeoffs:
        return "None"
    return "\n".join([
        f"- {t.replace('Ignore', 'Treat as neutral behaviour when observed')}"
        for t in tradeoffs
    ])


# ============================================================
# TRAJECTORY HEADERS
# ============================================================
TRAJECTORY_HEADERS = [
    "Query",
    "Expected_Trajectory",
    "Actual_Trajectory",
    "Comparison_Strict_Mode",
    "Reason_Strict_Mode",
    "Comparison_Unordered_Mode",
    "Reason_Unordered_Mode",
    "Comparison_Subset_Mode",
    "Reason_Subset_Mode",
    "Comparison_Superset_Mode",
    "Reason_Superset_Mode",
    "Overall_Score",
    "Passed_Modes",
    "Total_Modes",
    "Overall_Reason",
]


# ============================================================
# TRACE EXTRACTION
# ============================================================
def extract_all_run_names(trace_id: str) -> List[str]:
    """Extract all run names from a trace, sorted by start time."""
    client = Client(api_key=os.environ["LANGSMITH_API_KEY"])
    runs = list(client.list_runs(trace_id=trace_id))
    runs_sorted = sorted(runs, key=lambda r: r.start_time or 0)
    return [r.name for r in runs_sorted if r.name]


def extract_actual_agent_trajectory(trace_id: str) -> List[str]:
    """Extract actual agent trajectory from trace, filtered by reference sequence."""
    all_run_names = extract_all_run_names(trace_id)
    return [n for n in all_run_names if n in AGENT_SEQUENCE]


# ============================================================
# SCORING LOGIC
# ============================================================
def compute_trajectory_match_score(mode: str, match_value: str) -> float:
    """Compute score based on mode and match result."""
    if mode == "strict" and match_value == "Pass":
        return 1.0
    return 0.0


# ============================================================
# PROMPT BUILDER
# ============================================================
def build_trajectory_prompt(
    reference_outputs: List[str],
    actual_outputs: List[str],
    mode: str,
    tradeoff_text: str,
) -> str:
    """Build the per-mode trajectory evaluation prompt."""
    return f"""
Role:
You are an Expert Agent-Trajectory Evaluator.

Your task is to determine whether the ACTUAL agent execution trajectory
conforms to the REFERENCE agent trajectory under a specific matching MODE.

Tradeoff Scenarios (IMPORTANT):
The following scenarios define acceptable deviations that MUST be treated as
neutral behaviour during evaluation if encountered:
{tradeoff_text}

You must behave deterministically.
You must not infer intent, repair execution, or reinterpret system behavior.

Inputs:
reference_outputs:
{json.dumps(reference_outputs, indent=2)}

actual_outputs:
{json.dumps(actual_outputs, indent=2)}

mode:
{mode}

Instructions:

Meta Instructions:
Return ONLY valid JSON matching output_structure_mandate.
Do NOT include explanations outside the JSON object.
Do NOT infer missing agents, intent, or system behavior.

Global Context:
This evaluation is part of a MULTI-MODE agent trajectory analysis.
The same reference_outputs and actual_outputs may be evaluated across multiple modes.
Your per-mode decision MUST remain logically consistent across modes.

CRITICAL MODE EXCLUSIVITY RULES (MANDATORY):

- If strict mode = Pass → ALL other modes MUST return Fail.
- subset mode requires: len(actual_outputs) < len(reference_outputs)
- superset mode requires: len(actual_outputs) > len(reference_outputs)
- unordered mode requires:
  same agent names BUT execution order must differ.
- Modes must NEVER overlap.

Definitions:

Agent Invocation:
Every occurrence of an agent in the sequence is significant.
Duplicate executions MUST be preserved and compared.
Do NOT collapse repeated agents into a single occurrence.

Reference Outputs:
The authoritative, expected agent sequence.

Actual Outputs:
The observed agent invocation sequence from execution.

Mode Semantics:

strict:
actual_outputs MUST exactly match reference_outputs.

unordered:
Same agents but order different.

subset:
Actual must be smaller than expected.

superset:
Actual must be larger than expected.

Evaluation Rules:

The reason MUST describe:
- where order differs
- which agents are missing
- which agents appear extra
- how many times agents appear when relevant

The reason MUST include a short comparison narrative like:
"reference has X while actual has Y".

Use simple wording:
Use "larger", "smaller", "extra", "missing".
Avoid complex phrases.

Analysis Approach:

1. Compare sequences.
2. Check ordering.
3. Count extra occurrences.
4. Count missing occurrences.
5. Produce a detailed but simple explanation.

Output Format:

{{
  "match": "Pass | Fail",
  "mode": "{mode}",
  "reference_sequence": {json.dumps(reference_outputs)},
  "actual_sequence": {json.dumps(actual_outputs)},
  "missing_agents": ["string"],
  "extra_agents": ["string"],
  "reason": "Detailed comparison explanation"
}}
""".strip()


# ============================================================
# LLM EVALUATION
# ============================================================
def evaluate_trajectory_match(
    reference_outputs: List[str],
    actual_outputs: List[str],
    mode: str,
    llm_client: AzureChatOpenAI,
    tradeoff_text: str,
) -> tuple:
    """
    Evaluate trajectory match for a specific mode using LLM.

    Returns:
        (eval_output dict, prompt string used)
    """
    prompt = build_trajectory_prompt(reference_outputs, actual_outputs, mode, tradeoff_text)
    response = llm_client.invoke(prompt)
    eval_output = json.loads(response.content)
    return eval_output, prompt


def generate_overall_reason(per_mode_results: List[Dict], llm_client: AzureChatOpenAI) -> str:
    """Generate overall summary of trajectory evaluation across all modes."""
    prompt = f"""
Return STRICT JSON only.

Role:
You are an evaluation summarizer.

Use SIMPLE wording.

Explain overall trajectory behaviour using all modes.

Inputs:
{json.dumps([
    {
        "mode": r.get("mode"),
        "match": r.get("match"),
        "reason": r.get("reason")
    }
    for r in per_mode_results
], indent=2)}

Output:
{{
  "overall_reason": "string"
}}
"""

    response = llm_client.invoke(prompt)
    raw = response.content if hasattr(response, "content") else str(response)

    try:
        return json.loads(raw)["overall_reason"]
    except Exception:
        m = re.search(r"\{.*\}", raw, re.DOTALL)
        return json.loads(m.group(0))["overall_reason"]


# ============================================================
# MAIN EVALUATION PIPELINE
# ============================================================
def run_trajectory_eval(trace_id: str, scenario: str, llm_client: AzureChatOpenAI):
    """
    Run trajectory evaluation for a single trace.

    Args:
        trace_id:   LangSmith trace ID
        scenario:   Query/scenario text
        llm_client: Azure OpenAI client (temperature=0)

    Returns:
        Evaluation result dictionary compatible with main.py
    """
    try:
        reference_outputs = AGENT_SEQUENCE
        actual_outputs    = extract_actual_agent_trajectory(trace_id)
        tradeoff_text     = build_tradeoff_text(TRADEOFF_SCENARIOS)

        all_results  = []
        all_prompts  = []

        for mode in ALL_MODES:
            eval_output, prompt_used = evaluate_trajectory_match(
                reference_outputs, actual_outputs, mode, llm_client, tradeoff_text
            )
            score = compute_trajectory_match_score(mode, eval_output.get("match"))

            all_prompts.append(prompt_used)

            all_results.append({
                "mode":               mode,
                "match":              eval_output.get("match"),
                "reference_sequence": eval_output.get("reference_sequence"),
                "actual_sequence":    eval_output.get("actual_sequence"),
                "missing_agents":     eval_output.get("missing_agents", []),
                "extra_agents":       eval_output.get("extra_agents", []),
                "reason":             eval_output.get("reason"),
                "score":              score,
            })

        # Overall score driven by strict mode
        strict_result = next((r for r in all_results if r["mode"] == "strict"), None)
        final_score   = 1.0 if strict_result and strict_result["match"] == "Pass" else 0.0

        overall_reason = generate_overall_reason(all_results, llm_client)
        passed_modes   = sum(1 for r in all_results if r["match"] == "Pass")

        return {
            "eval_name": "trajectory_match_agents_only",
            "eval_type": "hybrid",
            "trace_id":  trace_id,
            "scenario":  scenario,
            "status":    "success",
            "error":     None,
            # ── per-mode prompts (list) for critique judge ──────
            "eval_prompt": all_prompts,
            # ── inputs exposed for critique judge ───────────────
            "eval_inputs": {
                "reference_outputs": reference_outputs,
                "actual_outputs":    actual_outputs,
                "modes":             ALL_MODES,
                "tradeoff_scenarios": TRADEOFF_SCENARIOS,
            },
            # ── outputs — keys match what main.py reads ──────────
            #   main.py reads: eval_output.final_score
            #                  eval_output.overall_reason
            "eval_output": {
                "per_mode_results": all_results,
                "final_score":      final_score,   # ← main.py uses this key
                "passed_modes":     passed_modes,
                "total_modes":      len(ALL_MODES),
                "overall_reason":   overall_reason,
            },
            "metadata": {
                "model":       "gpt-5",
                "temperature": 0,
                "timestamp":   datetime.utcnow().isoformat(),
            },
        }

    except Exception as e:
        return {
            "eval_name":  "trajectory_match_agents_only",
            "eval_type":  "hybrid",
            "trace_id":   trace_id,
            "scenario":   scenario,
            "status":     "failed",
            "error":      str(e),
            "eval_output": None,
            "metadata": {
                "timestamp": datetime.utcnow().isoformat(),
            },
        }


# ============================================================
# EXCEL STORAGE
# ============================================================
def dump_trajectory_eval_to_excel(
    *,
    trace_id: str,
    query: str,
    eval_result: dict,
    excel_path: str = "final_eval_results.xlsx",
):
    """Save trajectory evaluation results to Excel file."""
    wb    = get_or_create_workbook(excel_path)
    sheet = get_or_create_sheet(wb, "Trajectory", TRAJECTORY_HEADERS)

    if eval_result.get("status") == "failed":
        sheet.append([
            query,
            None, None, None, None, None, None,
            None, None, None, None, None, None, None, None,
        ])
    else:
        eval_inputs      = eval_result.get("eval_inputs", {})
        eval_output      = eval_result.get("eval_output", {})
        per_mode_results = eval_output.get("per_mode_results", [])

        mode_map = {
            "strict":    {"match": "", "reason": ""},
            "unordered": {"match": "", "reason": ""},
            "subset":    {"match": "", "reason": ""},
            "superset":  {"match": "", "reason": ""},
        }
        for result in per_mode_results:
            mode = result.get("mode")
            if mode in mode_map:
                mode_map[mode]["match"]  = result.get("match", "")
                mode_map[mode]["reason"] = result.get("reason", "")

        sheet.append([
            query,
            json.dumps(eval_inputs.get("reference_outputs", []), ensure_ascii=False),
            json.dumps(eval_inputs.get("actual_outputs",    []), ensure_ascii=False),
            mode_map["strict"]["match"],
            mode_map["strict"]["reason"],
            mode_map["unordered"]["match"],
            mode_map["unordered"]["reason"],
            mode_map["subset"]["match"],
            mode_map["subset"]["reason"],
            mode_map["superset"]["match"],
            mode_map["superset"]["reason"],
            eval_output.get("final_score", ""),
            eval_output.get("passed_modes", ""),
            eval_output.get("total_modes", ""),
            eval_output.get("overall_reason", ""),
        ])

    wb.save(excel_path)