"""
Parameter Extraction Accuracy Evaluation Module
"""

import os
import json
from datetime import datetime
from langsmith import Client
from langchain_openai import AzureChatOpenAI
from utils import get_or_create_workbook, get_or_create_sheet, get_timestamp

# ============================================================
# EXPECTED PARAMETER SCHEMA
# ============================================================
EXPECTED_PARAMETER_SCHEMA = {
    "item_name": "string",
    "item_type": "string",
    "weight": "string/number",
    "number_of_boxes": "number",
    "box_height": "string/number",
    "box_width": "string/number",
    "box_length": "string/number",
    "delivery_date": "string",
    "base_location": "string",
    "target_location": "string"
}

# ============================================================
# PARAMETER EXTRACTION HEADERS
# FIX: header names use spaces (matching notebook logger)
# ============================================================
PARAMETER_HEADERS = [
    "Query",
    "Parameter Name",
    "Extracted Value",
    "Parameter vs Query Accuracy",
    "Parameter Format Check",
    "Reason",
    "Overall Score",
    "Overall Reason",
    "Traceback",
]

# ============================================================
# LANGSMITH HELPERS
# ============================================================
def fetch_spans(trace_id: str):
    """Fetch all spans for a given trace ID from LangSmith."""
    client = Client(api_key=os.environ["LANGSMITH_API_KEY"])
    return list(client.list_runs(trace_id=trace_id))


def find_taskplanner_span(spans):
    """Find the TaskPlanner span in the list of spans."""
    taskplanner_spans = [
        s for s in spans
        if s.run_type == "chain" and s.name == "TaskPlanner"
    ]
    if not taskplanner_spans:
        raise ValueError("No TaskPlanner span found")
    return taskplanner_spans[-1]


# ============================================================
# DATA EXTRACTION
# ============================================================
def extract_user_messages(span):
    """Extract user messages from span inputs."""
    messages = span.inputs.get("messages", [])
    return [
        m.get("content")
        for m in messages
        if m.get("type") == "human"
    ]


def extract_supervisor_extracted_parameters(span):
    """Extract supervisor-extracted parameters from span inputs."""
    messages = span.inputs.get("messages", [])
    try:
        extracted = messages[8].get("content")
    except (IndexError, AttributeError):
        raise ValueError("Expected extracted parameters at messages[8]")
    return extracted


# ============================================================
# AUDIT PROMPT TEMPLATE
# FIX: output format changed from bare JSON array to object
# with audit_results, score, overall_reason keys
# ============================================================
AUDIT_PROMPT_TEMPLATE = r'''
Role:
You are a STRICT Parameter Extraction Evaluation Engine.
You behave deterministically and mechanically.

Goal:
Evaluate extracted parameters using TWO SEQUENTIAL CHECKS.

Inputs:
INPUT_TEXT:
{INPUT_TEXT}

EXTRACTED_PARAMETERS:
{EXTRACTED_PARAMETERS}

EXPECTED_PARAMETER_SCHEMA:
{EXPECTED_PARAMETER_SCHEMA}

------------------------------------------------------------
EVALUATION FRAMEWORK (STRICT GATING LOGIC)
------------------------------------------------------------

You MUST evaluate parameters using EXACTLY TWO checks:

1. parameter_vs_query_accuracy
2. parameter_format_check

Additionally you MUST output:
- parameter_name with expected format in brackets
- extracted_value

------------------------------------------------------------
CHECK DEFINITIONS
------------------------------------------------------------

CHECK 1 — parameter_vs_query_accuracy

Pass(value):
- Value is explicitly grounded in INPUT_TEXT.
- NORMALIZATION RULE (HIGH PRIORITY):

Some parameters represent NORMALIZED ENUM VALUES rather than literal text.

If the extracted_value is a valid normalized classification
derived from INPUT_TEXT, it MUST be considered grounded.

Example mappings:
"normal goods", "office stationary", "general items" → Pass(Normal)
"frozen fish", "ice cream" → Pass(Frozen)
"glassware", "vase" → Pass(Fragile)
"fresh apples", "edible goods" → Pass(Food)

Normalization DOES NOT count as hallucination.
- Semantic equivalence allowed, but wording MUST reflect the original value.
- Examples:
  Pass(Fresh Apples)
  Pass(30)
  Pass(BOSTON)

Fail(query_value):
- Value contradicts INPUT_TEXT or is incorrect.
- query_value MUST still be extracted from INPUT_TEXT.
- NEVER return null.

IMPORTANT ACCURACY FORMAT RULE:

parameter_vs_query_accuracy MUST be returned strictly as:

Pass(query_value)
Fail(query_value)

Where:
- query_value MUST be the grounded value from INPUT_TEXT.
- NEVER output null.

If parameter_vs_query_accuracy starts with Fail:
- parameter_format_check MUST be exactly: N/A

------------------------------------------------------------

CHECK 2 — parameter_format_check

Evaluate ONLY if parameter_vs_query_accuracy = Pass(value).

Pass(actual_format):
- Value matches EXPECTED_PARAMETER_SCHEMA format.

Fail(actual_format):
- Type mismatch
- Wrong unit or malformed value.

IMPORTANT FORMAT RULE:

parameter_format_check MUST be returned as:

Pass(actual_format)
Fail(actual_format)
N/A

Where actual_format MUST be one of:
string | number | null

Examples:
Pass(number)
Fail(string)
skipped(null)

------------------------------------------------------------
STRICT RULES
------------------------------------------------------------

- Do NOT infer missing values.
- Do NOT use external knowledge.
- Respect gating rules EXACTLY.
- Every schema parameter MUST appear once in output.
- parameter_name MUST be returned as:
  key(expected_type)
  Example: weight(number)
- extracted_value MUST reflect the value present in EXTRACTED_PARAMETERS.

------------------------------------------------------------
OUTPUT FORMAT (STRICT JSON OBJECT)
------------------------------------------------------------

Return a JSON object with this exact structure:

{
  "audit_results": [
    {
      "parameter_name": "string(expected_type)",
      "extracted_value": "string",
      "parameter_vs_query_accuracy": "Pass(value) | Fail(null)",
      "parameter_format_check": "Pass(type) | Fail(type) | skipped(null)",
      "reasoning": "short deterministic explanation"
    }
  ]
}

------------------------------------------------------------
FEW SHOT EXAMPLE
------------------------------------------------------------

EXPECTED_PARAMETER_SCHEMA:
{"weight":"number"}

INPUT_TEXT:
"Ship 12kg box"

EXTRACTED_PARAMETERS:
{"weight":"12kg"}

Output:
{
  "audit_results": [
    {
      "parameter_name": "weight(number)",
      "extracted_value": "12kg",
      "parameter_vs_query_accuracy": "Pass(12kg)",
      "parameter_format_check": "Fail(string)",
      "reasoning": "Value grounded but format not numeric."
    }
  ]
}
'''

# ============================================================
# SCORING LOGIC
# ============================================================
def compute_score(audit_results, expected_schema):
    """Compute overall score based on audit results."""
    total = len(expected_schema)
    score = 0.0

    for r in audit_results:
        value = str(r.get("parameter_vs_query_accuracy", ""))
        fmt   = str(r.get("parameter_format_check", ""))

        if value.startswith("Pass") and fmt.startswith("Pass"):
            score += 1.0
        elif value.startswith("Pass") and fmt.startswith("Fail"):
            score += 0.5
        else:
            score += 0.0

    return round(score / total, 2)


# ============================================================
# OVERALL REASON GENERATION
# ============================================================
def generate_overall_reason(audit_results, llm_client):
    """Generate an overall summary of the evaluation results."""
    prompt = f'''
Role:
You are a STRICT Evaluation Summary Generator.

Purpose:
Produce a concise structural summary describing the parameter extraction results.

CRITICAL CONSTRAINT:
This is NOT a recommendation or improvement task.
You MUST NOT provide suggestions, advice, fixes, or optimization ideas.

Allowed Behaviour:
- Describe ONLY what is observed in the audit_results.
- Mention patterns such as grounding accuracy, formatting consistency, or failures.
- Use neutral, descriptive language.

Forbidden Behaviour:
- Do NOT suggest improvements.
- Do NOT propose standardization.
- Do NOT say "should", "consider", "recommend", "improve", "minor improvement".
- Do NOT give forward-looking guidance.

Inputs:
audit_results:
{json.dumps(audit_results, indent=2)}

Output Requirements:
- 1-3 concise factual sentences.
- Purely observational.
- No prescriptive or advisory language.

Output Format:
Return ONLY JSON:

{{
  "overall_reason": "string"
}}
'''
    response = llm_client.invoke(prompt)
    return json.loads(response.content).get("overall_reason", "")


# ============================================================
# MAIN EVALUATION PIPELINE
# ============================================================
def run_parameter_extraction_eval(trace_id: str, scenario: str, llm_client: AzureChatOpenAI):
    """
    Run parameter extraction accuracy evaluation for a single trace.

    Args:
        trace_id:   LangSmith trace ID
        scenario:   Query/scenario text
        llm_client: Azure OpenAI client

    Returns:
        Evaluation result dictionary compatible with main.py
    """
    try:
        spans            = fetch_spans(trace_id)
        taskplanner_span = find_taskplanner_span(spans)

        user_msgs        = extract_user_messages(taskplanner_span)
        extracted_params = extract_supervisor_extracted_parameters(taskplanner_span)

        prompt = (
            AUDIT_PROMPT_TEMPLATE
            .replace("{INPUT_TEXT}",                json.dumps(user_msgs, indent=2))
            .replace("{EXTRACTED_PARAMETERS}",      extracted_params)
            .replace("{EXPECTED_PARAMETER_SCHEMA}", json.dumps(EXPECTED_PARAMETER_SCHEMA, indent=2))
        )

        llm_response = llm_client.invoke(prompt)

        # LLM returns { "audit_results": [...] }
        llm_output    = json.loads(llm_response.content)
        audit_results = llm_output.get("audit_results", [])

        # Compute score deterministically in Python
        score = compute_score(audit_results, EXPECTED_PARAMETER_SCHEMA)

        # Generate overall reason via dedicated LLM call (preserved from original)
        overall_reason = generate_overall_reason(audit_results, llm_client)

        return {
            "eval_name":   "parameter_extraction_accuracy",
            "trace_id":    trace_id,
            "scenario":    scenario,
            "eval_prompt": prompt,
            "eval_inputs": {
                "input_text":           user_msgs,
                "extracted_parameters": extracted_params,
                "expected_schema":      EXPECTED_PARAMETER_SCHEMA,
            },
            # FIX: eval_output is now a dict matching notebook logger structure:
            # eval_output.audit_results, eval_output.score, eval_output.overall_reason
            "eval_output": {
                "audit_results":  audit_results,
                "score":          score,
                "overall_reason": overall_reason,
            },
            "score":          score,
            "overall_reason": overall_reason,
            "metadata": {
                "model":       "gpt-5",
                "temperature": 1,
                "timestamp":   datetime.utcnow().isoformat(),
            },
            "status": "success",
            "error":  None,
        }

    except Exception as e:
        return {
            "eval_name": "parameter_extraction_accuracy",
            "trace_id":  trace_id,
            "scenario":  scenario,
            "status":    "failed",
            "error":     str(e),
            # FIX: was None — changed to {} to prevent AttributeError in main.py
            "eval_output": {},
            "score":          None,
            "overall_reason": None,
            "metadata": {
                "timestamp": datetime.utcnow().isoformat(),
            },
        }


# ============================================================
# EXCEL STORAGE (notebook logger logic applied)
# ============================================================
def dump_parameter_eval_to_excel(
    *,
    trace_id: str,
    query: str,
    eval_result: dict,
    excel_path: str = "final_eval_results.xlsx",
):
    """Save parameter extraction evaluation results to Excel file."""
    wb    = get_or_create_workbook(excel_path)
    sheet = get_or_create_sheet(wb, "Parameter Extraction Accuracy", PARAMETER_HEADERS)

    if eval_result.get("status") == "failed":
        # FIX: was writing 11 values for 9-column header — now exactly 9
        sheet.append([
            query,
            None,   # Parameter Name
            None,   # Extracted Value
            None,   # Parameter vs Query Accuracy
            None,   # Parameter Format Check
            None,   # Reason
            None,   # Overall Score
            None,   # Overall Reason
            eval_result.get("error", "Unknown error"),  # Traceback
        ])
        wb.save(excel_path)
        return

    # Pull from eval_output — matches notebook logger structure
    eval_output    = eval_result.get("eval_output", {})
    audit_results  = eval_output.get("audit_results", [])
    overall_score  = eval_output.get("score")
    overall_reason = eval_output.get("overall_reason", "")

    for param in audit_results:
        # Traceback = full param dict serialised as JSON (per notebook logger)
        traceback_json = json.dumps(param, ensure_ascii=False)

        sheet.append([
            query,
            param.get("parameter_name"),
            param.get("extracted_value"),
            param.get("parameter_vs_query_accuracy"),
            param.get("parameter_format_check"),
            param.get("reasoning"),
            overall_score,
            overall_reason,
            traceback_json,
        ])

    wb.save(excel_path)