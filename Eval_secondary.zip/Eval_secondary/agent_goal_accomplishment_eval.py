"""
Agent Goal Accomplishment Evaluation Module
Evaluates whether the Execute Plan Summary addresses the user's original task.

Updated: deterministic fragment-based score overwrites LLM verdict.
"""

import os
import json
import re
from typing import List, Any, Dict
from datetime import datetime
from langsmith import Client
from langchain_openai import AzureChatOpenAI
from utils import get_or_create_workbook, get_or_create_sheet


# ============================================================
# TRACE EXTRACTION
# ============================================================
def fetch_spans(trace_id: str) -> List[Any]:
    """Fetch all spans for a given trace ID."""
    client = Client(api_key=os.environ["LANGSMITH_API_KEY"])
    spans  = list(client.list_runs(trace_id=trace_id))
    if not spans:
        raise ValueError("No spans found for trace.")
    return sorted(spans, key=lambda r: r.start_time or 0)


# ============================================================
# SPAN FINDERS
# ============================================================
def find_supervisor_span(spans: List[Any]) -> Any:
    """Find the Supervisor span."""
    for s in spans:
        if s.name == "Supervisor":
            return s
    raise ValueError("Supervisor span not found")


def find_execute_plan_summary_llm(spans: List[Any]) -> Any:
    """Find the Execute Plan Summary LLM span."""
    for s in spans:
        if s.name == "Execute Plan Summary LLM":
            return s
    raise ValueError("Execute Plan Summary LLM span not found")


# ============================================================
# DATA EXTRACTION
# ============================================================
def extract_user_task_from_supervisor(supervisor_span: Any) -> str:
    """Extract user task from Supervisor span messages."""
    messages = supervisor_span.inputs.get("messages", [])
    if not messages or "content" not in messages[0]:
        raise ValueError("Could not extract user task from Supervisor span")
    return messages[0]["content"].strip()


def extract_execute_plan_summary(summary_span: Any) -> str:
    """Extract the summary text from Execute Plan Summary LLM outputs."""
    try:
        return summary_span.outputs["generations"][0][0]["text"]
    except Exception as e:
        raise ValueError(f"Could not extract Execute Plan Summary text: {e}")


# ============================================================
# GOAL ACCOMPLISHMENT EVALUATOR
# Returns (parsed_result, eval_prompt) tuple
# ============================================================
def task_completion_llm_eval(
    task: str,
    actual_outcome: str,
    llm_client: AzureChatOpenAI,
) -> tuple:
    """
    Evaluate whether the actual outcome accomplishes the user task.

    Returns:
        (llm_output dict, eval_prompt str)
    """
    eval_prompt = f'''
meta_instruction:
You MUST strictly follow the analysis_approach and output_structure_mandate.
Produce ONLY the required JSON object, without commentary outside the JSON.

metric_name:
Goal Accomplishment - Execute Plan Summary

role:
You are a Goal Accomplishment Evaluator.
Your responsibility is to determine whether the Execute Plan Summary
directly answers the user's request.

goal:
Evaluate whether each explicit fragment of the user's query
is addressed in the Execute Plan Summary.

inputs:

task:
{task}

actual_outcome:
{actual_outcome}

evaluation_definition:

User Query Fragment:
A concrete requirement, constraint, or intent expressed by the user.
Examples include:
- item details
- delivery conditions
- routing constraints
- optimisation requests
- confirmations or decisions

Match:
A clear corresponding statement exists in actual_outcome that fulfills
or directly addresses the fragment.

Missed:
No clear statement exists that addresses the fragment.

analysis_approach:

STEP 1:
Break the task into explicit query fragments.
Fragments must be grounded only in provided text.

STEP 2:
Search actual_outcome for statements that address each fragment.

STEP 3:
For each fragment:
- mark Match if a direct or semantically equivalent statement exists.
- mark Missed if absent.

STEP 4:
Assess overall accomplishment:
- If most critical fragments are Match -> higher verdict.
- If several fragments are Missed -> lower verdict.

STEP 5:
Provide a concise reasoning summary describing overall alignment.

strict_rules:

- Evaluate ONLY provided inputs.
- Do NOT infer hidden intent.
- Do NOT add fragments not present in task.
- Do NOT use external knowledge.
- Do NOT judge writing quality or style.

output_structure_mandate:

Return ONLY JSON:

{{
  "verdict": number,
  "reason": "1-3 sentences summarizing overall goal accomplishment",
  "fragments": [
    {{
      "query_fragment": "string",
      "summary_evidence": "string",
      "status": "Match | Missed"
    }}
  ]
}}

few_shot_example:

task:
Ship frozen salmon using airways only and deliver before Feb 5.

actual_outcome:
Plan uses air freight via UPS. Delivery ETA Feb 4.

Output:
{{
  "verdict": 1.0,
  "reason": "All user requirements appear in the summary.",
  "fragments": [
    {{
      "query_fragment": "frozen salmon shipment",
      "summary_evidence": "Plan uses air freight via UPS",
      "status": "Match"
    }},
    {{
      "query_fragment": "airways only",
      "summary_evidence": "air freight via UPS",
      "status": "Match"
    }},
    {{
      "query_fragment": "deliver before Feb 5",
      "summary_evidence": "Delivery ETA Feb 4",
      "status": "Match"
    }}
  ]
}}
'''.strip()

    response = llm_client.invoke(eval_prompt)
    raw = response.content if hasattr(response, "content") else str(response)

    try:
        return json.loads(raw), eval_prompt
    except Exception:
        m = re.search(r"(\{.*\})", raw, re.DOTALL)
        if not m:
            raise RuntimeError(f"Unparseable output:\n{raw}")
        return json.loads(m.group(1)), eval_prompt


# ============================================================
# DETERMINISTIC SCORING — overwrites LLM verdict
# ============================================================
def compute_goal_accomplishment_score(fragment_results: List[Dict]) -> float:
    """
    Deterministic score: matched fragments / total fragments.
    Overwrites the LLM-generated verdict to remove subjectivity.
    """
    if not fragment_results:
        return 1.0

    total   = len(fragment_results)
    matches = sum(1 for f in fragment_results if f.get("status") == "Match")
    return round(matches / total, 2)


# ============================================================
# FULL PIPELINE
# ============================================================
def run_agent_goal_accomplishment_eval(
    trace_id: str,
    scenario: str,
    llm_client: AzureChatOpenAI,
) -> Dict[str, Any]:
    """
    Full agent goal accomplishment evaluation pipeline.

    Args:
        trace_id:   LangSmith trace ID
        scenario:   Query/scenario text
        llm_client: Azure OpenAI client

    Returns:
        Evaluation result dictionary compatible with main.py
    """
    try:
        spans = fetch_spans(trace_id)

        supervisor_span = find_supervisor_span(spans)
        summary_span    = find_execute_plan_summary_llm(spans)

        task           = extract_user_task_from_supervisor(supervisor_span)
        actual_outcome = extract_execute_plan_summary(summary_span)

        llm_output, eval_prompt = task_completion_llm_eval(
            task=task,
            actual_outcome=actual_outcome,
            llm_client=llm_client,
        )

        # Overwrite LLM verdict with deterministic fragment-based score
        computed_score        = compute_goal_accomplishment_score(
            llm_output.get("fragments", [])
        )
        llm_output["verdict"] = computed_score

        reason = llm_output.get("reason", "")

        return {
            "eval_name":  "agent_goal_accomplishment",
            "eval_type":  "llm",
            "trace_id":   trace_id,
            "scenario":   scenario,
            # FIX 1: was "completed" — main.py summary stats use ok_status="success"
            "status":     "success",
            "error":      None,
            "eval_prompt": eval_prompt,
            "eval_inputs": {
                "task":           task,
                "actual_outcome": actual_outcome,
            },
            "eval_output": {
                **llm_output,
                "overall_reason": reason,
                "actual_output":  actual_outcome,
            },
            "metadata": {
                "model":       "gpt-5",
                "temperature": 1,
                "timestamp":   datetime.utcnow().isoformat(),
            },
        }

    except Exception as e:
        return {
            "eval_name":  "agent_goal_accomplishment",
            "eval_type":  "llm",
            "trace_id":   trace_id,
            "scenario":   scenario,
            "status":     "failed",
            "error":      str(e),
            "eval_inputs":  {},
            "eval_output":  {},
            "metadata": {
                "model":     "gpt-5",
                "timestamp": datetime.utcnow().isoformat(),
            },
        }


# ============================================================
# EXCEL OUTPUT — aligned with notebook logger
# ============================================================
def dump_agent_goal_accomplishment_to_excel(
    *,
    trace_id: str,
    query: str,
    eval_result: dict,
    excel_path: str = "final_eval_results.xlsx",
):
    """Save agent goal accomplishment results to Excel."""

    # FIX 2: headers updated to match notebook logger HEADERS_AGA exactly
    # old: 8 cols with underscores, included Matched_Fragments/Total_Fragments
    # new: 7 cols with spaces, includes Traceback instead
    HEADERS = [
        "Query",
        "Query Fragment",
        "Summary Evidence",
        "Status",
        "Overall Score",
        "Overall Reason",
        "Traceback",
    ]

    wb    = get_or_create_workbook(excel_path)
    # Sheet name "Goal Accomplishment" matches EVAL_SHEET_MAP and notebook logger
    sheet = get_or_create_sheet(wb, "Goal Accomplishment", HEADERS)

    eval_output     = eval_result.get("eval_output", {})
    fragments       = eval_output.get("fragments",  [])
    overall_verdict = eval_output.get("verdict",    "")
    overall_reason  = eval_output.get("reason",     "")

    if eval_result.get("status") == "failed":
        sheet.append([
            query,
            "",
            "",
            "",
            "",
            eval_result.get("error", "Unknown error"),
            "{}",
        ])
    elif not fragments:
        # no fragments — matches notebook logger no-fragment fallback
        sheet.append([
            query,
            None,
            None,
            "Missed",
            overall_verdict,
            overall_reason,
            "{}",
        ])
    else:
        for frag in fragments:
            sheet.append([
                query,
                frag.get("query_fragment",  ""),
                frag.get("summary_evidence", ""),
                frag.get("status",           ""),
                overall_verdict,
                overall_reason,
                json.dumps(frag, ensure_ascii=False),  # Traceback = full frag as JSON
            ])

    wb.save(excel_path)