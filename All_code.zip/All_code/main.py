import warnings
from datetime import datetime
import pandas as pd
from reportlab.pdfgen import canvas
import demo
import albumentations as A
import cv2
import numpy as np
import math
from PIL import Image
import os
import shutil

warnings.filterwarnings('ignore')
import os


bias = input("Enter the bias: \n")
style = input("Enter the style: \n")
thickness = input("Enter the width: \n")
num_style = input("Enter the style for numbers: \n")
numStyle = "style" + str(num_style)
tick_style = input("Enter the style for tick/cross: \n")
in_file = input("Enter the name of input file: \n")
alignment = input("Enter the alignment: \n")
folder_path = 'inputfiles'
entity = 0
augment_list =['Wrinkled']
df = pd.read_excel(in_file, engine='openpyxl', dtype=object)
df = df.reset_index()

def wrinkled_paper(dis_field,img_path,distorted_path):
    img = cv2.imread(image_path).astype("float32") / 255.0
    hh, ww = img.shape[:2]

    # Read wrinkle effect image as grayscale float32 [0, 1]
    wrinkles = cv2.imread('Effects/'+dis_field+'.jpg', 0).astype("float32") / 255.0
    wrinkles = cv2.resize(wrinkles, (ww, hh), fx=0, fy=0)

    # Adjust wrinkle brightness
    mean = np.mean(wrinkles)
    shift = mean - 0.4
    wrinkles = wrinkles - shift
    wrinkles = np.clip(wrinkles, 0, 1)

    # Generate folds using gradients
    hh1 = math.ceil(hh / 2)
    ww1 = math.ceil(ww / 3)
    val = math.sqrt(0.2)
    grady = np.linspace(-val, val, hh1, dtype=np.float32)
    gradx = np.linspace(-val, val, ww1, dtype=np.float32)

    grad1 = np.outer(grady, gradx)
    grad2 = cv2.flip(grad1, 0)
    grad3 = cv2.flip(grad1, 1)
    grad4 = cv2.flip(grad1, -1)

    foldx1 = np.hstack([grad1 - 0.1, grad2, grad3])
    foldx2 = np.hstack([grad2 + 0.1, grad3, grad1 + 0.2])
    folds = np.vstack([foldx1, foldx2])
    folds = folds[0:hh, 0:ww]

    # Add wrinkles and folds
    wrinkle_folds = wrinkles + folds
    wrinkle_folds = np.clip(wrinkle_folds, 0, 1)

    # Add creases
    creases = np.zeros((hh, ww), dtype=np.float32)
    ww2 = 2 * ww1
    cv2.line(creases, (0, hh1), (ww - 1, hh1), 0.25, 1)
    cv2.line(creases, (ww1, 0), (ww1, hh - 1), 0.25, 1)
    cv2.line(creases, (ww2, 0), (ww2, hh - 1), 0.25, 1)
    creases = cv2.GaussianBlur(creases, (3, 3), 0)

    wrinkle_folds_creases = wrinkle_folds + creases
    wrinkle_folds_creases = np.clip(wrinkle_folds_creases, 0, 1)

    # Thresholding
    _, thresh = cv2.threshold(wrinkle_folds_creases, 0.7, 1.0, cv2.THRESH_BINARY)
    thresh = cv2.cvtColor(thresh, cv2.COLOR_GRAY2BGR)
    thresh_inv = 1.0 - thresh

    # Convert wrinkle pattern to 3 channels
    wrinkle_folds_creases_bgr = cv2.cvtColor(wrinkle_folds_creases, cv2.COLOR_GRAY2BGR)

    # Apply light/dark blend
    low = 2.0 * img * wrinkle_folds_creases_bgr
    high = 1.0 - 2.0 * (1.0 - img) * (1.0 - wrinkle_folds_creases_bgr)
    blended = low * thresh_inv + high * thresh
    result = (255 * np.clip(blended, 0, 1)).astype(np.uint8)
    cv2.imwrite(img_path+ '_' + distorted_val + '.jpg', result)
    distorted_path.append(img_path+ '_' + distorted_val + '.jpg')
    return distorted_path


for index, row in df.iterrows():
    p=0
    file_name_list = []
    for filename in os.listdir(folder_path):
        file_path = os.path.join(folder_path, filename)
        if os.path.isfile(file_path):
            img1 = Image.open(file_path)
            split_result = file_path.split("_")
            last_element = int(split_result[-1].split(".")[0])
            df_cord = pd.read_excel("coordinates_file.xlsx", sheet_name=last_element, engine='openpyxl')
            input_dict = {}
            special_key = {}
            for i in df_cord['Field']:
                if pd.isna(row[i]):
                    continue
                else:
                    val = row[i]
                    fill_type = df_cord.loc[df_cord['Field'] == i, 'fill_type'].item()
                    if fill_type == 'blocks':
                        special_key[i] = val
                    input_dict[i] = val
            input_dict['blocks'] = special_key
            print(input_dict)
            demo.main(input_dict, bias, style, thickness)

            for i in df_cord['Field']:
                if pd.isna(row[i]):
                    continue
                print(i)
                fill_type = df_cord.loc[df_cord['Field'] == i, 'fill_type'].item()
                if fill_type == 'blocks':
                    value = str(row[i])
                    x_cordinate = df_cord.loc[df_cord['Field'] == i, 'X-coordinates'].item()
                    y_cordinate = df_cord.loc[df_cord['Field'] == i, 'Y-coordinates'].item()
                    for z in value:
                        img2 = Image.open(
                            r"numbers/" + numStyle + "/" + str(z) + ".png")
                        height = img2.height
                        img1.paste(img2, (x_cordinate, y_cordinate - height), mask=img2)
                        x_cordinate = x_cordinate + 30
                elif fill_type == 'checkbox':
                    value = str(row[i])
                    x_cordinate = df_cord.loc[df_cord['Field'] == i, 'X-coordinates'].item()
                    y_cordinate = df_cord.loc[df_cord['Field'] == i, 'Y-coordinates'].item()
                    if value == 'tick':
                        img2 = Image.open(r"ticks_cross/style" + str(tick_style) + "/tick.png")
                    else:
                        img2 = Image.open(r"ticks_cross/style" + str(tick_style) + "/cross.png")

                    height = img2.height
                    img1.paste(img2, (x_cordinate, y_cordinate - height), mask=img2)

                else:

                    def validNumber(value):
                        import re
                        phone_pattern = re.compile(r'\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}')
                        m = re.fullmatch(phone_pattern, value.strip())
                        if m is not None:
                            phone_val = 'Correct'
                        else:
                            phone_val = 'Incorrect'
                        return phone_val


                    def time(value):
                        time_list = []
                        time_format = ['%I%p', '%I:%M', '%I:%M%p']
                        for time in time_format:
                            try:
                                datetime.strptime(value, time)
                                time_list.append('True')
                            except ValueError:
                                time_list.append('False')
                        return time_list


                    def datecheck(value):
                        date_format = ['%d-%m-%Y', '%d/%m/%Y', '%m-%d-%Y', '%m/%d/%Y', '%m/%d', '%m-%d', '%d-%m-%y',
                                       '%d/%m/%y']
                        date_list = []

                        for date in date_format:
                            try:
                                datetime.strptime(value, date)
                                date_list.append('True')
                            except ValueError:
                                date_list.append('False')
                        return date_list


                    value = str(row[i])
                    if 'sign' in value:
                        print("in sign")
                        x_cordinate = df_cord.loc[df_cord['Field'] == i, 'X-coordinates'].item()
                        y_cordinate = df_cord.loc[df_cord['Field'] == i, 'Y-coordinates'].item()
                        x_max = df_cord.loc[df_cord['Field'] == i, 'x_max'].item()
                        y_max = df_cord.loc[df_cord['Field'] == i, 'y_max'].item()
                        img2 = Image.open("signatures/" + value + ".png")
                        if alignment == "left":
                            img2 = img2.resize((150, 50))
                            height = img2.height
                        elif alignment == "center":
                            img2 = img2.resize((150, 50))
                            shift = int((x_max - x_cordinate) / 2)
                            x_cordinate = x_cordinate + shift
                            height = img2.height
                        elif alignment == "random":
                            img2 = img2.resize(((x_max - x_cordinate), (y_cordinate - y_max)))
                            height = int((img2.height) / 2)
                        img1.paste(img2, (x_cordinate, y_cordinate - height), mask=img2)
                        continue
                    elif validNumber(value) == 'Correct':
                        x_cordinate = df_cord.loc[df_cord['Field'] == i, 'X-coordinates'].item()
                        y_cordinate = df_cord.loc[df_cord['Field'] == i, 'Y-coordinates'].item()
                        x_max = df_cord.loc[df_cord['Field'] == i, 'x_max'].item()
                        y_max = df_cord.loc[df_cord['Field'] == i, 'y_max'].item()
                        k = len(value)
                        if alignment == "center":
                            shift = int((x_max - x_cordinate) / 2)
                            x = x_cordinate + shift
                            if x_max - x >= (len(value) * 16):
                                x_cordinate = x_cordinate + shift
                            else:
                                temp = (len(value) * 16) - (x_max - x)
                                x_cordinate = x_cordinate + (shift - temp)
                        for z in value:
                            if z == '-':
                                img2 = Image.open("symbols/hyphen.png")
                            elif z == '.':
                                img2 = Image.open("symbols/..png")
                            elif z == '(':
                                img2 = Image.open("symbols/open_bracket.png")
                            elif z == ')':
                                img2 = Image.open("symbols/close_bracket.png")
                            else:
                                img2 = Image.open(
                                    r"numbers/" + numStyle + "/" + str(z) + ".png")
                            if alignment == "random":
                                img2 = img2.resize((int((x_max - x_cordinate) / k), ((y_cordinate - y_max) + 16)))
                                height = img2.height
                                img1.paste(img2, (x_cordinate, y_cordinate - int(height / 1.5)), mask=img2)
                                x_cordinate = x_cordinate + img2.width
                                k = k - 1
                            else:
                                height = img2.height
                                img1.paste(img2, (x_cordinate, y_cordinate - height), mask=img2)
                                x_cordinate = x_cordinate + 16
                        continue
                    elif all(val.isdigit() or (val == ',') or (val == '.') for val in value):
                        x_cordinate = df_cord.loc[df_cord['Field'] == i, 'X-coordinates'].item()
                        y_cordinate = df_cord.loc[df_cord['Field'] == i, 'Y-coordinates'].item()
                        x_max = df_cord.loc[df_cord['Field'] == i, 'x_max'].item()
                        y_max = df_cord.loc[df_cord['Field'] == i, 'y_max'].item()
                        k = len(value) + 1
                        if alignment == "center":
                            shift = int((x_max - x_cordinate) / 2)
                            x = x_cordinate + shift
                            if x_max - x >= (len(value) * 16):
                                x_cordinate = x_cordinate + shift
                            else:
                                temp = (len(value) * 16) - (x_max - x)
                                x_cordinate = x_cordinate + (shift - temp)
                        for z in value:
                            if z.isdigit():
                                img2 = Image.open(
                                    r"numbers/" + numStyle + "/" + str(z) + ".png")
                                if alignment == "random":
                                    img2 = img2.resize((int((x_max - x_cordinate) / k), y_cordinate - y_max))
                                    height = img2.height
                                    img1.paste(img2, (x_cordinate, y_cordinate - int(height / 1.5)), mask=img2)
                                    x_cordinate = x_cordinate + int((x_max - x_cordinate) / len(value))
                                    k = k - 1
                                else:
                                    height = img2.height
                                    img1.paste(img2, (x_cordinate, y_cordinate - height), mask=img2)
                                    x_cordinate = x_cordinate + 16
                            else:
                                if z == ',':
                                    img2 = Image.open("symbols/comma.png")
                                else:
                                    img2 = Image.open("symbols/..png")
                                height = img2.height
                                # if alignment == "random":
                                height = int(height / 2)

                                img1.paste(img2, (x_cordinate, y_cordinate - height), mask=img2)
                                x_cordinate = x_cordinate + 16

                    elif all(val.isalpha() or val.isspace() or val == '.' for val in value):
                        x_cordinate = df_cord.loc[df_cord['Field'] == i, 'X-coordinates'].item()
                        y_cordinate = df_cord.loc[df_cord['Field'] == i, 'Y-coordinates'].item()
                        x_max = df_cord.loc[df_cord['Field'] == i, 'x_max'].item()
                        y_max = df_cord.loc[df_cord['Field'] == i, 'y_max'].item()
                        img2 = Image.open(
                            r"final_images_png/Bias_" + str(bias) + "_Style_" + str(style) + "_Width_" + str(
                                thickness) + "/" + i + ".png")

                        if len(value) != 1:
                            img2 = img2.resize((25 + (img2.width), (y_cordinate - y_max)))
                        else:
                            img2 = img2.resize((20, (y_cordinate - y_max)))

                        if alignment == "center":
                            shift = int((x_max - x_cordinate) / 2)
                            x_cordinate = x_cordinate + shift
                        if alignment == "random":
                            if len(value) == 1:
                                img2 = img2.resize((50, ((y_cordinate - y_max) + 5)))
                            else:
                                img2 = img2.resize(((25 * len(value)), ((y_cordinate - y_max) + 5)))
                            l = ['f', 'g', 'j', 'p', 'q', 'y', 'Q']
                            if any(char in l for char in value):
                                y_cordinate = y_cordinate + 10
                            # x_cordinate = x_cordinate + shift
                        height = img2.height
                        img1.paste(img2, (x_cordinate, y_cordinate - height), mask=img2)

                    # --------------------------------------------------------------------------------------------------------------
                    elif any(char.isalpha() for char in value) and any(char == '@' for char in value) and any(
                            char == '.' for char in value) and not any(char.isdigit() for char in value):
                        res = value.split("@")
                        x_cordinate = df_cord.loc[df_cord['Field'] == i, 'X-coordinates'].item()
                        y_cordinate = df_cord.loc[df_cord['Field'] == i, 'Y-coordinates'].item()
                        y_max = df_cord.loc[df_cord['Field'] == i, 'y_max'].item()
                        x_max = df_cord.loc[df_cord['Field'] == i, 'x_max'].item()
                        if alignment == "center":
                            shift = int((x_max - x_cordinate) / 2)
                            x_cordinate = x_cordinate + shift
                        for k in res:
                            img2 = Image.open(
                                "final_images_png/Bias_" + str(bias) + "_Style_" + str(style) + "_Width_" + str(
                                    thickness) + "/" + i + str(res.index(k)) + ".png")
                            if len(value) != 1:
                                img2 = img2.resize((25 + (img2.width), (y_cordinate - y_max)))
                                if alignment == "random":
                                    img2 = img2.resize(((20 * len(k)), ((y_cordinate - y_max) + 10)))
                                    l = ['f', 'g', 'j', 'p', 'q', 'y', 'Q']
                                    if any(char in l for char in k):
                                        y_cordinate = y_cordinate + 10
                                    height = img2.height
                                    img1.paste(img2, (x_cordinate, y_cordinate - height), mask=img2)
                                    x_cordinate = x_cordinate + img2.width
                                else:
                                    height = img2.height
                                    img1.paste(img2, (x_cordinate, y_cordinate - (height - 5)), mask=img2)
                                    x_cordinate = x_cordinate + img2.width

                            else:
                                img2 = img2.resize((20, (y_cordinate - y_max)))
                                if alignment == "random":
                                    img2 = img2.resize((50, ((y_cordinate - y_max) + 10)))
                                    height = img2.height
                                    img1.paste(img2, (x_cordinate, y_cordinate - height), mask=img2)
                                    x_cordinate = x_cordinate + img2.width
                                else:
                                    height = img2.height
                                    img1.paste(img2, (x_cordinate, y_cordinate - height), mask=img2)
                                    x_cordinate = x_cordinate + img2.width

                            if res.index(k) == 0:
                                img2 = Image.open("symbols/@.png")
                                if alignment == "random":
                                    img2 = img2.resize((35, 40))
                                    height = img2.height
                                    img1.paste(img2, (x_cordinate, y_cordinate - height), mask=img2)
                                    x_cordinate = x_cordinate + img2.width
                                else:
                                    height = img2.height
                                    img1.paste(img2, (x_cordinate, y_cordinate - height), mask=img2)
                                    x_cordinate = x_cordinate + img2.width

                    elif 'True' in time(value):
                        print('in time')
                        time_list = time(value)
                        x_cordinate = df_cord.loc[df_cord['Field'] == i, 'X-coordinates'].item()
                        y_cordinate = df_cord.loc[df_cord['Field'] == i, 'Y-coordinates'].item()
                        y_max = df_cord.loc[df_cord['Field'] == i, 'y_max'].item()
                        x_max = df_cord.loc[df_cord['Field'] == i, 'x_max'].item()
                        if alignment == "center":
                            shift = int((x_max - x_cordinate) / 2)
                            x_cordinate = x_cordinate + shift
                        n = time_list.index('True')
                        l = len(value)
                        if n == 1:
                            res = value.split(':')
                            for k in res:
                                for num in k:
                                    img2 = Image.open("numbers/" + numStyle + "/" + str(num) + ".png")
                                    if alignment == "random":
                                        img2 = img2.resize((int((x_max - x_cordinate) / (l)), y_cordinate - y_max))
                                        height = img2.height
                                        img1.paste(img2, (x_cordinate, y_cordinate - int(height / 1.5)), mask=img2)
                                        x_cordinate = x_cordinate + int((x_max - x_cordinate) / len(value))
                                    # height = img2.height
                                    else:
                                        height = img2.height
                                        img1.paste(img2, (x_cordinate, y_cordinate - height), mask=img2)
                                        x_cordinate = x_cordinate + 16
                                if res.index(k) != len(res) - 1:
                                    img2 = Image.open("symbols/colon.png")
                                    height = img2.height
                                    img1.paste(img2, (x_cordinate, y_cordinate - height), mask=img2)
                                    x_cordinate = x_cordinate + 16
                                l = l - 1
                        elif n == 0:
                            numeric_part = ''
                            for char in value:
                                if char.isdigit():
                                    numeric_part += char
                            for num in numeric_part:
                                img2 = Image.open("numbers/" + numStyle + "/" + str(num) + ".png")
                                if alignment == "random":
                                    img2 = img2.resize((int((x_max - x_cordinate) / (l)), y_cordinate - y_max))
                                    height = img2.height
                                    img1.paste(img2, (x_cordinate, y_cordinate - int(height / 1.5)), mask=img2)
                                    x_cordinate = x_cordinate + int((x_max - x_cordinate) / len(value))
                                # height = img2.height
                                else:
                                    height = img2.height
                                    img1.paste(img2, (x_cordinate, y_cordinate - height), mask=img2)
                                    x_cordinate = x_cordinate + 16
                                l = l - 1
                            img2 = Image.open(
                                "final_images_png/Bias_" + str(bias) + "_Style_" + str(style) + "_Width_" + str(
                                    thickness) + "/" + i + str(len(numeric_part)) + ".png")
                            height = img2.height
                            if alignment == "random":
                                img1.paste(img2, (x_cordinate, y_cordinate - int(height / 1.5)), mask=img2)
                            else:
                                img1.paste(img2, (x_cordinate, y_cordinate - height), mask=img2)
                        elif n == 2:
                            res = value.split(':')
                            z = 0
                            for k in res:
                                if z == 0:
                                    for num in k:
                                        img2 = Image.open("numbers/" + numStyle + "/" + str(num) + ".png")
                                        if alignment == "random":
                                            img2 = img2.resize((int((x_max - x_cordinate) / (l)), y_cordinate - y_max))
                                            height = img2.height
                                            img1.paste(img2, (x_cordinate, y_cordinate - int(height / 1.5)), mask=img2)
                                            x_cordinate = x_cordinate + int((x_max - x_cordinate) / len(value))
                                        else:
                                            height = img2.height
                                            img1.paste(img2, (x_cordinate, y_cordinate - height), mask=img2)
                                            x_cordinate = x_cordinate + 16
                                    if res.index(k) != len(res) - 1:
                                        img2 = Image.open("symbols/colon.png")
                                        height = img2.height
                                        img1.paste(img2, (x_cordinate, y_cordinate - height), mask=img2)
                                        x_cordinate = x_cordinate + 16
                                    l = l - 1
                                else:
                                    numeric_part = ''
                                    for char in k:
                                        if char.isdigit():
                                            numeric_part += char
                                    for num in numeric_part:
                                        img2 = Image.open("numbers/" + numStyle + "/" + str(num) + ".png")
                                        if alignment == "random":
                                            img2 = img2.resize((int((x_max - x_cordinate) / (l)), y_cordinate - y_max))
                                            height = img2.height
                                            img1.paste(img2, (x_cordinate, y_cordinate - int(height / 1.5)), mask=img2)
                                            x_cordinate = x_cordinate + int((x_max - x_cordinate) / len(value))
                                        else:
                                            height = img2.height
                                            img1.paste(img2, (x_cordinate, y_cordinate - height), mask=img2)
                                            x_cordinate = x_cordinate + 16
                                        l = l - 1
                                    print(str(len(numeric_part)))
                                    img2 = Image.open(
                                        "final_images_png/Bias_" + str(bias) + "_Style_" + str(style) + "_Width_" + str(
                                            thickness) + "/" + i + str(len(numeric_part) + 2) + ".png")
                                    height = img2.height
                                    if alignment == "random":
                                        img1.paste(img2, (x_cordinate, y_cordinate - int(height / 1.5)), mask=img2)
                                    else:
                                        if img2.width > x_max - x_cordinate:
                                            img2 = img2.resize((x_max - x_cordinate, img2.height))
                                        img1.paste(img2, (x_cordinate, y_cordinate - height), mask=img2)
                                z = z + 1
                        continue

                    elif 'True' in datecheck(value):
                        print('in date')
                        date_list = datecheck(value)
                        x_cordinate = df_cord.loc[df_cord['Field'] == i, 'X-coordinates'].item()
                        y_cordinate = df_cord.loc[df_cord['Field'] == i, 'Y-coordinates'].item()
                        x_max = df_cord.loc[df_cord['Field'] == i, 'x_max'].item()
                        y_max = df_cord.loc[df_cord['Field'] == i, 'y_max'].item()
                        if alignment == "center":
                            shift = int((x_max - x_cordinate) / 2)
                            x = x_cordinate + shift
                            if x_max - x >= (len(value) * 16):
                                x_cordinate = x_cordinate + shift
                            else:
                                temp = (len(value) * 16) - (x_max - x)
                                x_cordinate = x_cordinate + (shift - temp)
                        n = date_list.index('True')
                        l = len(value)
                        if "/" in value:
                            res = value.split('/')
                        else:
                            res = value.split('-')
                        for i in res:
                            for num in i:
                                img2 = Image.open("numbers/" + numStyle + "/" + str(num) + ".png")
                                if alignment == "random":
                                    img2 = img2.resize((int((x_max - x_cordinate) / (l)), y_cordinate - y_max))
                                    height = img2.height
                                    img1.paste(img2, (x_cordinate, y_cordinate - int(height / 1.5)), mask=img2)
                                    x_cordinate = x_cordinate + img2.width
                                else:
                                    # height = img2.height
                                    height = img2.height
                                    img1.paste(img2, (x_cordinate, y_cordinate - height), mask=img2)
                                    x_cordinate = x_cordinate + 16
                                l = l - 1
                            if res.index(i) != len(res) - 1:
                                if (n == 0 or n == 2 or n == 5 or n == 6):
                                    img2 = Image.open("symbols/hyphen.png")
                                    if alignment == "random":
                                        img2 = img2.resize((img2.width, 35))
                                    height = img2.height
                                    img1.paste(img2, (x_cordinate, y_cordinate - (height + 3)), mask=img2)
                                    x_cordinate = x_cordinate + 16
                                    l = l - 1
                                if (n == 1 or n == 3 or n == 4 or n == 7):
                                    img2 = Image.open("symbols/slash.png")
                                    height = img2.height
                                    if alignment == "random":
                                        img2 = img2.resize((img2.width, y_cordinate - y_max))
                                        height = int(img2.height / 1.5)

                                    img1.paste(img2, (x_cordinate, y_cordinate - height), mask=img2)
                                    x_cordinate = x_cordinate + 16
                                    l = l - 1
                        continue

                    elif any(char.isalpha() for char in value) and any(char.isdigit() for char in value):
                        import re

                        print('in alphadigit')
                        x_cordinate = df_cord.loc[df_cord['Field'] == i, 'X-coordinates'].item()
                        y_cordinate = df_cord.loc[df_cord['Field'] == i, 'Y-coordinates'].item()
                        x_max = df_cord.loc[df_cord['Field'] == i, 'x_max'].item()
                        y_max = df_cord.loc[df_cord['Field'] == i, 'y_max'].item()
                        if alignment == "center":
                            shift = int((x_max - x_cordinate) / 2)
                            x_cordinate = x_cordinate + shift

                        word_pattern = re.compile(r'[a-zA-Z]+')
                        number_pattern = re.compile(r'\d+')
                        special_char_pattern = re.compile(r'[^\w\s]')
                        Words = [(match.group(), match.start()) for match in word_pattern.finditer(value)]
                        Numbers = [(match.group(), match.start()) for match in
                                   number_pattern.finditer(value)]
                        special_chars = [(match.group(), match.start()) for match in
                                         special_char_pattern.finditer(value)]
                        res = Words + Numbers + special_chars
                        sorted_data = sorted(res, key=lambda x: x[1])
                        for k in sorted_data:
                            # print(k[0])
                            if k[0].isalpha():
                                img2 = Image.open(
                                    r"final_images_png/Bias_" + str(bias) + "_Style_" + str(style) + "_Width_" + str(
                                        thickness) + "/" + i + str(k[1]) + ".png")
                                # print(img2.width)
                                if len(value) != 1:
                                    img2 = img2.resize((10 + (img2.width), 40))
                                else:
                                    img2 = img2.resize((10, 40))
                                if alignment == "random":
                                    img2 = img2.resize(((img2.width + 15), 40))

                                height = img2.height
                                img1.paste(img2, (x_cordinate, y_cordinate - (height - 10)), mask=img2)
                                x_cordinate = x_cordinate + img2.width
                            elif k[0].isdigit():
                                for z in k[0]:
                                    img2 = Image.open(
                                        r"numbers/" + numStyle + "/" + str(z) + ".png")
                                    if alignment == "random":
                                        img2 = img2.resize((20, 30))
                                    height = img2.height
                                    img1.paste(img2, (x_cordinate, y_cordinate - height), mask=img2)
                                    x_cordinate = x_cordinate + 16
                            else:
                                img2 = Image.open(
                                    r"symbols/" + str(k[0]) + ".png")
                                height = img2.height
                                img1.paste(img2, (x_cordinate, y_cordinate - height), mask=img2)
                                x_cordinate = x_cordinate + 16

            fpath = 'replica/result_BSWN_' + str(bias) + str(style) + str(thickness) + str(num_style) + alignment+"Entity_"+str(entity)
            if not os.path.exists(fpath):
                os.makedirs(fpath)
            img1.save(fpath + '/page' + str(p) + '.jpg')
            file_name_list.append(fpath + '/page' + str(p) + '.jpg')
            p = p + 1


    if augment_list != []:
        for distorted_val in augment_list:
            distorted_path =[]
            for image_path in file_name_list:
                img_path = image_path.split('.')[0]
                image = cv2.imread(image_path)
                image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
                if distorted_val != 'Wrinkled' and distorted_val != 'Spilled Coffee' and distorted_val != 'Shadow':
                    if distorted_val == 'Blurred':
                        transform = A.Compose([
                            A.Blur(always_apply=False, p=1.0, blur_limit=(3, 7))
                        ])

                    elif distorted_val == 'Optical Distortion':
                        transform = A.Compose([
                            A.OpticalDistortion(
                                always_apply=False, p=1.0,
                                distort_limit=(-0.3, 0.3),
                                shift_limit=(-0.05, 0.05),
                                interpolation=0,
                                border_mode=0, value=(0, 0, 0),
                                mask_value=None
                            )
                        ])


                    elif distorted_val == 'Cropped':
                        transform = A.Compose([
                            A.RandomCrop(width=600, height=800)
                        ])
                    elif distorted_val == 'Random Brightness':
                        transform = A.Compose([A.RandomBrightnessContrast(
                            always_apply=False, p=1.0, limit=(0.03, 0.5)
                        )])

                    augmented_image = transform(image=image)['image']
                    transformed_pil_image = Image.fromarray(augmented_image)
                    transformed_pil_image.save(img_path+ '_' + distorted_val + '.jpg')
                    distorted_path.append(img_path+ '_' + distorted_val + '.jpg')
                else:
                    distorted_path=wrinkled_paper(distorted_val, img_path,distorted_path)
            c = canvas.Canvas(
                'output/result_BSWN_' + str(bias) + str(style) + str(thickness) + str(
                    num_style) + alignment + "Entity_" + str(entity)+'/'+distorted_val + '.pdf')
            directory = 'output/result_BSWN_' + str(bias) + str(style) + str(thickness) + str(
                num_style) + alignment + "Entity_" + str(entity)
            if not os.path.exists(directory):
                os.makedirs(directory)
            for dis_image_path in distorted_path:
                img = Image.open(dis_image_path)
                width, height = img.size
                c.setPageSize((width, height))
                c.drawInlineImage(dis_image_path, 0, 0, width, height)
                c.showPage()
            c.save()


    c = canvas.Canvas(
        'output/result_BSWN_' + str(bias) + str(style) + str(thickness) + str(
                    num_style) + alignment + "Entity_" + str(entity)+'/original.pdf')
    directory = 'output/result_BSWN_' + str(bias) + str(style) + str(thickness) + str(
                num_style) + alignment + "Entity_" + str(entity)

    for image_path in file_name_list:
        img = Image.open(image_path)
        width, height = img.size
        c.setPageSize((width, height))
        c.drawInlineImage(image_path, 0, 0, width, height)
        c.showPage()
    c.save()
    entity = entity+1
