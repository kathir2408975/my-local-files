import albumentations as A
import cv2
import numpy as np
import math
from PIL import Image
import os
import shutil

image_path = "input_image.jpg"
output_directory = image_path.split('.')[0]
if not os.path.exists(output_directory):
    os.makedirs(output_directory)

augment_list =['Wrinkled','Blurred','Random Brightness','Cropped']
image = cv2.imread(image_path)
image = cv2.cvtColor(image,cv2.COLOR_BGR2RGB)
def wrinkled_paper(dis_field):
    img = cv2.imread(image_path).astype("float32") / 255.0
    hh, ww = img.shape[:2]

    # Read wrinkle effect image as grayscale float32 [0, 1]
    wrinkles = cv2.imread('Effects/'+dis_field+'.jpg', 0).astype("float32") / 255.0
    wrinkles = cv2.resize(wrinkles, (ww, hh), fx=0, fy=0)

    # Adjust wrinkle brightness
    mean = np.mean(wrinkles)
    shift = mean - 0.4
    wrinkles = wrinkles - shift
    wrinkles = np.clip(wrinkles, 0, 1)

    # Generate folds using gradients
    hh1 = math.ceil(hh / 2)
    ww1 = math.ceil(ww / 3)
    val = math.sqrt(0.2)
    grady = np.linspace(-val, val, hh1, dtype=np.float32)
    gradx = np.linspace(-val, val, ww1, dtype=np.float32)

    grad1 = np.outer(grady, gradx)
    grad2 = cv2.flip(grad1, 0)
    grad3 = cv2.flip(grad1, 1)
    grad4 = cv2.flip(grad1, -1)

    foldx1 = np.hstack([grad1 - 0.1, grad2, grad3])
    foldx2 = np.hstack([grad2 + 0.1, grad3, grad1 + 0.2])
    folds = np.vstack([foldx1, foldx2])
    folds = folds[0:hh, 0:ww]

    # Add wrinkles and folds
    wrinkle_folds = wrinkles + folds
    wrinkle_folds = np.clip(wrinkle_folds, 0, 1)

    # Add creases
    creases = np.zeros((hh, ww), dtype=np.float32)
    ww2 = 2 * ww1
    cv2.line(creases, (0, hh1), (ww - 1, hh1), 0.25, 1)
    cv2.line(creases, (ww1, 0), (ww1, hh - 1), 0.25, 1)
    cv2.line(creases, (ww2, 0), (ww2, hh - 1), 0.25, 1)
    creases = cv2.GaussianBlur(creases, (3, 3), 0)

    wrinkle_folds_creases = wrinkle_folds + creases
    wrinkle_folds_creases = np.clip(wrinkle_folds_creases, 0, 1)

    # Thresholding
    _, thresh = cv2.threshold(wrinkle_folds_creases, 0.7, 1.0, cv2.THRESH_BINARY)
    thresh = cv2.cvtColor(thresh, cv2.COLOR_GRAY2BGR)
    thresh_inv = 1.0 - thresh

    # Convert wrinkle pattern to 3 channels
    wrinkle_folds_creases_bgr = cv2.cvtColor(wrinkle_folds_creases, cv2.COLOR_GRAY2BGR)

    # Apply light/dark blend
    low = 2.0 * img * wrinkle_folds_creases_bgr
    high = 1.0 - 2.0 * (1.0 - img) * (1.0 - wrinkle_folds_creases_bgr)
    blended = low * thresh_inv + high * thresh
    result = (255 * np.clip(blended, 0, 1)).astype(np.uint8)
    cv2.imwrite(output_directory+'/'+distorted_val+'.jpg', result)


for distorted_val in augment_list:
    if distorted_val != 'Wrinkled' and distorted_val != 'Spilled Coffee' and distorted_val != 'Shadow':
        if distorted_val == 'Blurred':
            transform = A.Compose([
                A.Blur(always_apply=False, p=1.0, blur_limit=(3, 7))
            ])

        elif distorted_val == 'Optical Distortion':
            transform = A.Compose([
                A.OpticalDistortion(
                    always_apply=False, p=1.0,
                    distort_limit=(-0.3, 0.3),
                    shift_limit=(-0.05, 0.05),
                    interpolation=0,
                    border_mode=0, value=(0, 0, 0),
                    mask_value=None
                )
            ])


        elif distorted_val == 'Cropped':
            transform = A.Compose([
                A.RandomCrop(width=600, height=800)
            ])
        elif distorted_val == 'Random Brightness':
                transform = A.Compose([A.RandomBrightnessContrast(
                    always_apply=False, p=1.0, limit=(0.03, 0.5)
                )])

        augmented_image = transform(image=image)['image']
        transformed_pil_image = Image.fromarray(augmented_image)
        transformed_pil_image.save(output_directory+'/'+distorted_val+'.jpg')
    else:
        wrinkled_paper(distorted_val)

folder_to_zip = output_directory
shutil.make_archive(folder_to_zip, 'zip', folder_to_zip)