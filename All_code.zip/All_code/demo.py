from hand import Hand
import os


def main(input_dict,bias,style,width):
    hand = Hand()
    for key in input_dict:
        # print(key)
        if key != 'blocks':
            input_value = str(input_dict[key])
            if all(val.isalpha() or val.isspace() or val == '.' for val in input_value):
                lines = [str(input_dict[key])]
                biases = [bias for i in lines]
                styles = [style for i in lines]
                stroke_colors = ['black']
                stroke_widths = [width]
                f_name = 'final_images_svg/Bias_' + str(bias) + '_Style_' + str(style) + '_Width_' + str(width)
                os.makedirs(f_name, exist_ok=True)

                hand.write(
                    filename=f_name + '/' + key + '.svg',
                    lines=lines,
                    biases=biases,
                    styles=styles,
                    stroke_colors=stroke_colors,
                    stroke_widths=stroke_widths
                )

                import aspose.words as aw
                # for file in im
                file_storage = 'final_images_png/Bias_' + str(bias) + '_Style_' + str(style) + '_Width_' + str(width)
                fileName = f_name + '/' + key + '.svg'
                doc = aw.Document()
                builder = aw.DocumentBuilder(doc)
                shape = builder.insert_image(fileName)
                # print(shape.width)
                pageSetup = builder.page_setup
                pageSetup.page_width = shape.width
                pageSetup.page_height = shape.height
                pageSetup.top_margin = 0
                pageSetup.left_margin = 0
                pageSetup.bottom_margin = 0
                pageSetup.right_margin = 0
                doc.save(file_storage + '/' + key + '.jpg')

                from PIL import Image, ImageOps
                image = Image.open(file_storage + '/' + key + '.jpg')
                bbox = ImageOps.invert(image).getbbox()
                trimmed = image.crop(bbox)
                # trimmed.save(file_storage+'/' + key + '.jpg')
                img = trimmed.convert("RGBA")
                datas = img.getdata()
                newData = []
                for item in datas:
                    if item[0] == 255 and item[1] == 255 and item[2] == 255:
                        newData.append((255, 255, 255, 0))
                    else:
                        newData.append(item)
                img.putdata(newData)
                img.save(file_storage + '/' + key + '.png', 'PNG')

            elif any(char.isalpha() for char in input_value) and any(char.isdigit() for char in input_value):
                import re
                word_pattern = re.compile(r'[a-zA-Z]+')
                Words= [(match.group(), match.start()) for match in
                                        word_pattern.finditer(input_value)]
                for i in Words:
                    lines = [str(i[0])]
                    biases = [bias for i in lines]
                    styles = [style for i in lines]
                    stroke_colors = ['black']
                    stroke_widths = [width]
                    f_name = 'final_images_svg/Bias_' + str(bias) + '_Style_' + str(style) + '_Width_' + str(width)
                    os.makedirs(f_name, exist_ok=True)

                    hand.write(
                        filename=f_name + '/' + key +str(i[1])+ '.svg',
                        lines=lines,
                        biases=biases,
                        styles=styles,
                        stroke_colors=stroke_colors,
                        stroke_widths=stroke_widths
                    )

                    import aspose.words as aw
                    # for file in im
                    file_storage = 'final_images_png/Bias_' + str(bias) + '_Style_' + str(style) + '_Width_' + str(
                        width)
                    fileName = f_name + '/' + key +str(i[1])+ '.svg'
                    doc = aw.Document()
                    builder = aw.DocumentBuilder(doc)
                    shape = builder.insert_image(fileName)
                    # print(shape.width)
                    pageSetup = builder.page_setup
                    pageSetup.page_width = shape.width
                    pageSetup.page_height = shape.height
                    pageSetup.top_margin = 0
                    pageSetup.left_margin = 0
                    pageSetup.bottom_margin = 0
                    pageSetup.right_margin = 0
                    doc.save(file_storage + '/' + key +str(i[1]) + '.jpg')

                    from PIL import Image, ImageOps
                    image = Image.open(file_storage + '/' + key +str(i[1]) + '.jpg')
                    bbox = ImageOps.invert(image).getbbox()
                    trimmed = image.crop(bbox)
                    # trimmed.save(file_storage+'/' + key + '.jpg')
                    img = trimmed.convert("RGBA")
                    datas = img.getdata()
                    newData = []
                    for item in datas:
                        if item[0] == 255 and item[1] == 255 and item[2] == 255:
                            newData.append((255, 255, 255, 0))
                        else:
                            newData.append(item)
                    img.putdata(newData)
                    img.save(file_storage + '/' + key +str(i[1])+ '.png', 'PNG')

            elif any(char.isalpha() for char in input_value) and any(char=='@' for char in input_value) and any(char=='.' for char in input_value) and not any(char.isdigit() for char in input_value):
                res = input_value.split("@")
                for k in res:
                    lines = [str(k)]
                    biases = [bias for i in lines]
                    styles = [style for i in lines]
                    stroke_colors = ['black']
                    stroke_widths = [width]
                    f_name = 'final_images_svg/Bias_' + str(bias) + '_Style_' + str(style) + '_Width_' + str(width)
                    os.makedirs(f_name, exist_ok=True)

                    hand.write(
                        filename=f_name + '/' + key+str(res.index(k)) + '.svg',
                        lines=lines,
                        biases=biases,
                        styles=styles,
                        stroke_colors=stroke_colors,
                        stroke_widths=stroke_widths
                    )

                    import aspose.words as aw
                    # for file in im
                    file_storage = 'final_images_png/Bias_' + str(bias) + '_Style_' + str(style) + '_Width_' + str(
                        width)
                    fileName = f_name + '/' + key+str(res.index(k)) + '.svg'
                    doc = aw.Document()
                    builder = aw.DocumentBuilder(doc)
                    shape = builder.insert_image(fileName)
                    # print(shape.width)
                    pageSetup = builder.page_setup
                    pageSetup.page_width = shape.width
                    pageSetup.page_height = shape.height
                    pageSetup.top_margin = 0
                    pageSetup.left_margin = 0
                    pageSetup.bottom_margin = 0
                    pageSetup.right_margin = 0
                    doc.save(file_storage + '/' + key+str(res.index(k))  + '.jpg')

                    from PIL import Image, ImageOps
                    image = Image.open(file_storage + '/' + key+str(res.index(k)) + '.jpg')
                    bbox = ImageOps.invert(image).getbbox()
                    trimmed = image.crop(bbox)
                    # trimmed.save(file_storage+'/' + key + '.jpg')
                    img = trimmed.convert("RGBA")
                    datas = img.getdata()
                    newData = []
                    for item in datas:
                        if item[0] == 255 and item[1] == 255 and item[2] == 255:
                            newData.append((255, 255, 255, 0))
                        else:
                            newData.append(item)
                    img.putdata(newData)
                    img.save(file_storage + '/' + key+str(res.index(k)) + '.png', 'PNG')