import cv2
import pytesseract
from pytesseract import Output
import json

pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"


manual_bbox = []  # global for callback


def draw_rectangle(event, x, y, flags, param):
    global manual_bbox

    if event == cv2.EVENT_LBUTTONDOWN:
        manual_bbox[:] = [(x, y)]  # first corner
    elif event == cv2.EVENT_LBUTTONUP:
        manual_bbox.append((x, y))  # second corner
        cv2.rectangle(param, manual_bbox[0], manual_bbox[1], (0, 0, 255), 2)
        cv2.imshow("Manual Correction", param)

def draw_value_bbox_near_key(image_path, selected_pairs):
    global manual_bbox
    img = cv2.imread(image_path)
    if img is None:
        print(f"❌ Could not load image: {image_path}")
        return

    final_img = img.copy()  # ✅ Make a copy for final drawing

    ocr_data = pytesseract.image_to_data(img, output_type=Output.DICT)
    n_boxes = len(ocr_data['text'])

    print("\n=== Auto-drawing all bboxes ===")
    for pair in selected_pairs:
        key = pair['key'].strip().lower()
        value = pair['value'].strip().lower()
        found = False

        for block_num in set(ocr_data['block_num']):
            for line_num in set(ocr_data['line_num']):
                line_words = [
                    (ocr_data['text'][i].strip().lower(), i)
                    for i in range(n_boxes)
                    if ocr_data['block_num'][i] == block_num
                    and ocr_data['line_num'][i] == line_num
                    and ocr_data['text'][i].strip()
                ]
                if not line_words:
                    continue

                line_text = " ".join([w for w, _ in line_words])
                if key in line_text and value in line_text:
                    print(f"✅ Found line with key '{key}' and value '{value}'")
                    for word, idx in line_words:
                        if word in value:
                            x, y, w, h = (
                                ocr_data['left'][idx],
                                ocr_data['top'][idx],
                                ocr_data['width'][idx],
                                ocr_data['height'][idx]
                            )
                            x2, y2 = x + w, y + h

                            # ✅ Draw on final image
                            cv2.rectangle(final_img, (x, y), (x2, y2), (0, 255, 0), 2)
                            pair['bbox'] = [x, y, x2, y2]
                            found = True

        if not found:
            print(f"❌ Value not found near key for ID {pair['id']}")

    # ✅ Show the final image for verification
    cv2.namedWindow("Verify All BBoxes", cv2.WINDOW_NORMAL)
    max_width, max_height = 1200, 800
    h, w = final_img.shape[:2]
    if w > max_width or h > max_height:
        scale = min(max_width / w, max_height / h)
        img_resized = cv2.resize(final_img, (int(w * scale), int(h * scale)))
    else:
        img_resized = final_img

    cv2.imshow("Verify All BBoxes", img_resized)
    print("\nInspect the window. Press any key to continue...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()

    # Confirm correctness
    user_input = input("\nAre all bboxes correct? (ok/not): ").strip().lower()
    if user_input == "ok":
        print("✅ Keeping all auto-drawn bboxes.")
    else:
        wrong_ids = input("Enter IDs to correct (comma separated): ").strip()
        wrong_ids = [int(x.strip()) for x in wrong_ids.split(",") if x.strip()]

        for wid in wrong_ids:
            pair = next((p for p in selected_pairs if p['id'] == wid), None)
            if not pair:
                print(f"❌ ID {wid} not found!")
                continue

            print(f"📝 Draw manual bbox for ID {wid} ({pair['key']} → {pair['value']})")

            temp_img = final_img.copy()
            cv2.namedWindow("Manual Correction", cv2.WINDOW_NORMAL)
            cv2.setMouseCallback("Manual Correction", draw_rectangle, param=temp_img)

            manual_bbox.clear()
            while True:
                cv2.imshow("Manual Correction", temp_img)
                key = cv2.waitKey(1) & 0xFF
                if key == ord('q'):
                    break
                elif key == ord('r'):
                    print("🔄 Redo drawing...")
                    temp_img = final_img.copy()
                    cv2.setMouseCallback("Manual Correction", draw_rectangle, param=temp_img)
                    manual_bbox.clear()

            cv2.destroyWindow("Manual Correction")

            if manual_bbox and len(manual_bbox) == 2:
                x1, y1 = manual_bbox[0]
                x2, y2 = manual_bbox[1]
                bbox = [min(x1, x2), min(y1, y2), max(x1, x2), max(y1, y2)]
                print(f"✅ New bbox for ID {wid}: {bbox}")
                pair['bbox'] = bbox

                # ✅ Draw corrected bbox on final image
                cv2.rectangle(final_img, (bbox[0], bbox[1]), (bbox[2], bbox[3]), (0, 0, 255), 2)
                cv2.putText(final_img, f"ID {wid}", (bbox[0], bbox[1] - 5),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1)
            else:
                print(f"❌ No manual bbox drawn for ID {wid}.")

    print("\n✅ Final selected pairs with any corrections:")
    for pair in selected_pairs:
        print(pair)

    with open("output/selected_pairs_with_bbox.json", "w") as f:
        json.dump(selected_pairs, f, indent=2)
    print("\n✅ Saved: output/selected_pairs_with_bbox.json")

    # ✅ Now this works!
    cv2.imwrite("output/final_bbox_result.png", final_img)
    print("✅ Final image saved as: output/final_bbox_result.png")
