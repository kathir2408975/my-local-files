# # # streamlit_app.py

# # import os
# # import json
# # import streamlit as st
# # from PIL import Image
# # import cv2
# # import numpy as np

# # # Your modules:
# # from extractor import extract_text_from_file, convert_to_png
# # from llm_client import get_key_value_pairs
# # from bbox_utils import draw_value_bbox_near_key  # only if you want auto
# # from replacer import replace_bboxes


# # st.set_page_config(page_title="📄 BBox Replacer", layout="wide")
# # st.title("📄 Text Extraction + BBox Editor")

# # # 1️⃣ Upload file
# # uploaded_file = st.file_uploader("Upload a file (PDF/Image)", type=["pdf", "png", "jpg", "jpeg"])

# # if uploaded_file:
# #     # Save uploaded file
# #     input_path = os.path.join("input", uploaded_file.name)
# #     os.makedirs("input", exist_ok=True)
# #     with open(input_path, "wb") as f:
# #         f.write(uploaded_file.getbuffer())
# #     st.success(f"Saved to {input_path}")

# #     # Convert to PNG if needed
# #     png_path = convert_to_png(input_path, output_path="input/input.png")
# #     if not os.path.exists(png_path):
# #         st.error(f"❌ PNG not created: {png_path}")
# #         st.stop()

# #     # Extract text + LLM
# #     extracted_text = extract_text_from_file(input_path)
# #     kv_pairs = get_key_value_pairs(extracted_text)

# #     # Save kv_pairs.json for consistency
# #     os.makedirs("output", exist_ok=True)
# #     with open("output/kv_pairs.json", "w") as f:
# #         json.dump(kv_pairs, f, indent=2)

# #     # 2️⃣ Layout: sidebar pairs + image
# #     col1, col2 = st.columns([1, 2])

# #     with col1:
# #         st.header("🔑 Available Pairs")
# #         for pair in kv_pairs:
# #             st.write(f"ID {pair['id']}: {pair['key']} => {pair['value']}")

# #     with col2:
# #         st.header("📄 Uploaded Image")
# #         st.image("input/input.png", caption="Input Document", use_column_width=True)

# #     # 3️⃣ Select IDs
# #     selected_ids = st.text_input(
# #         "👉 Enter IDs you want to draw bbox for (comma separated)", placeholder="e.g. 2,6"
# #     )

# #     if selected_ids:
# #         ids = [int(x.strip()) for x in selected_ids.split(",") if x.strip()]
# #         selected_pairs = [pair for pair in kv_pairs if pair['id'] in ids]

# #         st.success("✅ Found:")
# #         for p in selected_pairs:
# #             st.json(p)

# #         # 4️⃣ AUTO bbox draw (or your logic)
# #         st.subheader("🔲 Auto-drawn BBoxes")
# #         # 👉 You'd run your draw_value_bbox_near_key() logic here to fill `bbox`:
# #         # For demo, add dummy bbox
# #         for pair in selected_pairs:
# #             pair["bbox"] = [50, 50, 200, 80]  # 👈 Dummy values, replace with your detection

# #         # Draw on image
# #         img = cv2.imread("input/input.png")
# #         for pair in selected_pairs:
# #             if "bbox" in pair:
# #                 x1, y1, x2, y2 = map(int, pair["bbox"])
# #                 cv2.rectangle(img, (x1, y1), (x2, y2), (0, 255, 0), 2)

# #         st.image(img, channels="BGR", caption="Auto-detected BBoxes")

# #         # 5️⃣ Confirm or redo bboxes
# #         confirm = st.radio("✅ Are all bboxes correct?", ["ok", "not"])
# #         if confirm == "not":
# #             st.warning("📝 Provide corrected bboxes below:")
# #             for pair in selected_pairs:
# #                 st.write(f"✏️ ID {pair['id']}: {pair['key']} => {pair['value']}")
# #                 x1 = st.number_input(f"ID {pair['id']} - X1", value=int(pair['bbox'][0]))
# #                 y1 = st.number_input(f"ID {pair['id']} - Y1", value=int(pair['bbox'][1]))
# #                 x2 = st.number_input(f"ID {pair['id']} - X2", value=int(pair['bbox'][2]))
# #                 y2 = st.number_input(f"ID {pair['id']} - Y2", value=int(pair['bbox'][3]))
# #                 pair['bbox'] = [x1, y1, x2, y2]

# #             st.success("✅ BBoxes updated!")

# #         st.subheader("✅ Final selected pairs with BBoxes")
# #         for pair in selected_pairs:
# #             st.json(pair)

# #         # 6️⃣ Enter new values for replacement
# #         st.subheader("✏️ Provide new values:")
# #         for pair in selected_pairs:
# #             new_val = st.text_input(
# #                 f"Original: {pair['value']}\nNew value for ID {pair['id']} ({pair['key']}):",
# #                 value=pair['value']
# #             )
# #             pair["new_value"] = new_val

# #         # 7️⃣ Replace and show final
# #         if st.button("🚀 Replace Text & Show Final Image"):
# #             final_pairs = replace_bboxes("input/input.png", selected_pairs)
# #             final_img = Image.open("output/final_replaced_image.png")
# #             st.image(final_img, caption="✅ Final Replaced Image", use_column_width=True)
# #             st.success("🎉 Done!")






# import streamlit as st
# import os
# import json
# import cv2
# import numpy as np
# from PIL import Image, ImageDraw, ImageFont
# import pytesseract
# from pytesseract import Output
# import google.generativeai as genai
# from pdfminer.high_level import extract_text
# from pdf2image import convert_from_path
# import cairosvg
# import tempfile
# import io



# # ### pdf to image convert and text extract

# import streamlit as st
# import os
# import tempfile
# from PIL import Image
# from extractor import extract_text_from_file, convert_to_png
# from config import TESSERACT_PATH, POPPLER_PATH

# # Streamlit page config
# st.set_page_config(page_title="Document Text Extractor", layout="wide")
# st.title("📄 Document Text Extractor")

# # Override extractor config from sidebar
# st.sidebar.header("Configuration")
# tesseract_path = st.sidebar.text_input("Tesseract Path", value=TESSERACT_PATH)
# poppler_path = st.sidebar.text_input("Poppler Path", value=POPPLER_PATH)

# # Set runtime config
# import pytesseract
# from pdf2image import convert_from_path
# pytesseract.pytesseract.tesseract_cmd = tesseract_path

# # File uploader
# uploaded_file = st.file_uploader("📤 Upload a file", type=["pdf", "jpg", "jpeg", "png", "svg"])

# if uploaded_file:
#     with tempfile.NamedTemporaryFile(delete=False, suffix=os.path.splitext(uploaded_file.name)[1]) as tmp_file:
#         tmp_file.write(uploaded_file.read())
#         file_path = tmp_file.name

#     st.success(f"Uploaded: {uploaded_file.name}")

#     # Text extraction
#     if st.button("🔍 Extract Text"):
#         try:
#             text = extract_text_from_file(file_path)
#             st.subheader("📝 Extracted Text")
#             st.text_area("Output", text, height=300)
#         except Exception as e:
#             st.error(f"Failed to extract text: {e}")

#     # Preview image
#     try:
#         png_path = convert_to_png(file_path)
#         image = Image.open(png_path)
#         st.subheader("🖼️ Preview")
#         st.image(image, caption="Document Preview", use_column_width=True)
#     except Exception as e:
#         st.error(f"Failed to convert or preview image: {e}")


# # Configuration
# st.set_page_config(page_title="Document Processing App", layout="wide")

# # Initialize session state
# if 'kv_pairs' not in st.session_state:
#     st.session_state.kv_pairs = []
# if 'selected_pairs' not in st.session_state:
#     st.session_state.selected_pairs = []
# if 'processed_image' not in st.session_state:
#     st.session_state.processed_image = None
# if 'final_image' not in st.session_state:
#     st.session_state.final_image = None

# # Configuration settings
# st.sidebar.header("Configuration")
# tesseract_path = st.sidebar.text_input("Tesseract Path", value=r"C:\Program Files\Tesseract-OCR\tesseract.exe")
# poppler_path = st.sidebar.text_input("Poppler Path", value=r"C:\Users\KTHRMFST\Downloads\Release-24.07.0-0\poppler-24.07.0\Library\bin")
# gemini_api_key = st.sidebar.text_input("Gemini API Key", type="password", value="AIzaSyBzNKe5Je3wWCld6FSXimF3SPmN0mTpJT4")

# # Set paths
# pytesseract.pytesseract.tesseract_cmd = tesseract_path
# genai.configure(api_key=gemini_api_key)

# def extract_text_from_file(file_path, file_type):
#     """Extract text from uploaded file"""
#     text = ""
    
#     if file_type == "pdf":
#         text = extract_text(file_path)
#         if not text.strip():
#             st.info("No text found with pdfminer. Using OCR fallback...")
#             images = convert_from_path(file_path, poppler_path=poppler_path)
#             for img in images:
#                 text += pytesseract.image_to_string(img)
#     elif file_type in ["jpg", "jpeg", "png"]:
#         img = Image.open(file_path)
#         text = pytesseract.image_to_string(img)
#     elif file_type == "svg":
#         png_path = file_path + ".png"
#         cairosvg.svg2png(url=file_path, write_to=png_path)
#         img = Image.open(png_path)
#         text = pytesseract.image_to_string(img)
#         os.remove(png_path)
#     else:
#         st.error("Unsupported file type!")
#         return ""
    
#     return text

# def convert_to_png(uploaded_file, file_type):
#     """Convert uploaded file to PNG"""
#     if file_type == "pdf":
#         with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp_file:
#             tmp_file.write(uploaded_file.getvalue())
#             tmp_path = tmp_file.name
        
#         pages = convert_from_path(tmp_path, poppler_path=poppler_path)
#         if pages:
#             img_array = np.array(pages[0])
#             os.unlink(tmp_path)
#             return img_array
#     elif file_type in ["jpg", "jpeg", "png"]:
#         img = Image.open(uploaded_file)
#         return np.array(img)
#     elif file_type == "svg":
#         with tempfile.NamedTemporaryFile(delete=False, suffix=".svg") as tmp_file:
#             tmp_file.write(uploaded_file.getvalue())
#             tmp_path = tmp_file.name
        
#         png_path = tmp_path + ".png"
#         cairosvg.svg2png(url=tmp_path, write_to=png_path)
#         img = Image.open(png_path)
#         img_array = np.array(img)
#         os.unlink(tmp_path)
#         os.unlink(png_path)
#         return img_array
    
#     return None

# def get_key_value_pairs(text):
#     """Extract key-value pairs using Gemini"""
#     prompt = (
#         "Extract all key-value pairs clearly from this insurance text. "
#         "Format the output as a JSON array with keys: 'key' and 'value'.\n\n"
#         f"{text}"
#     )
    
#     with st.spinner("Extracting key-value pairs with Gemini..."):
#         try:
#             model = genai.GenerativeModel("gemini-1.5-flash-latest")
#             response = model.generate_content(prompt)
#             raw_output = response.text.strip()
            
#             st.subheader("Raw Gemini Output")
#             st.code(raw_output, language="json")
            
#             # Clean output
#             cleaned_output = raw_output
#             if cleaned_output.startswith("```json"):
#                 cleaned_output = cleaned_output[len("```json"):].strip()
#             if cleaned_output.endswith("```"):
#                 cleaned_output = cleaned_output[:-3].strip()
            
#             data = json.loads(cleaned_output)
            
#             # Add numbering
#             for idx, pair in enumerate(data, 1):
#                 pair["id"] = idx
            
#             st.success(f"✅ Extracted {len(data)} key-value pairs")
#             return data
            
#         except Exception as e:
#             st.error(f"Failed to extract key-value pairs: {e}")
#             return []

# def draw_bboxes_on_image(image_array, selected_pairs):
#     """Draw bounding boxes on image using OCR"""
#     img = cv2.cvtColor(image_array, cv2.COLOR_RGB2BGR)
#     final_img = img.copy()
    
#     ocr_data = pytesseract.image_to_data(img, output_type=Output.DICT)
#     n_boxes = len(ocr_data['text'])
    
#     st.subheader("Auto-drawing Bounding Boxes")
    
#     for pair in selected_pairs:
#         key = pair['key'].strip().lower()
#         value = pair['value'].strip().lower()
#         found = False
        
#         for block_num in set(ocr_data['block_num']):
#             for line_num in set(ocr_data['line_num']):
#                 line_words = [
#                     (ocr_data['text'][i].strip().lower(), i)
#                     for i in range(n_boxes)
#                     if ocr_data['block_num'][i] == block_num
#                     and ocr_data['line_num'][i] == line_num
#                     and ocr_data['text'][i].strip()
#                 ]
#                 if not line_words:
#                     continue
                
#                 line_text = " ".join([w for w, _ in line_words])
#                 if key in line_text and value in line_text:
#                     st.success(f"✅ Found line with key '{key}' and value '{value}'")
#                     for word, idx in line_words:
#                         if word in value:
#                             x, y, w, h = (
#                                 ocr_data['left'][idx],
#                                 ocr_data['top'][idx],
#                                 ocr_data['width'][idx],
#                                 ocr_data['height'][idx]
#                             )
#                             x2, y2 = x + w, y + h
                            
#                             cv2.rectangle(final_img, (x, y), (x2, y2), (0, 255, 0), 2)
#                             cv2.putText(final_img, f"ID {pair['id']}", (x, y-5),
#                                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
#                             pair['bbox'] = [x, y, x2, y2]
#                             found = True
        
#         if not found:
#             st.warning(f"❌ Value not found near key for ID {pair['id']}")
    
#     return cv2.cvtColor(final_img, cv2.COLOR_BGR2RGB)

# def replace_bboxes(image_array, pairs_with_bboxes, replacement_values):
#     """Replace text in bounding boxes"""
#     img = cv2.cvtColor(image_array, cv2.COLOR_RGB2BGR)
    
#     # Create mask for inpainting
#     mask = np.zeros(img.shape[:2], dtype=np.uint8)
    
#     for pair in pairs_with_bboxes:
#         bbox = pair.get("bbox")
#         if bbox:
#             x1, y1, x2, y2 = bbox
#             mask[y1:y2, x1:x2] = 255
    
#     # Inpaint to remove text
#     img_inpainted = cv2.inpaint(img, mask, 3, cv2.INPAINT_TELEA)
    
#     # Use PIL for text drawing
#     img_pil = Image.fromarray(cv2.cvtColor(img_inpainted, cv2.COLOR_BGR2RGB))
#     draw = ImageDraw.Draw(img_pil)
    
#     for pair in pairs_with_bboxes:
#         bbox = pair.get("bbox")
#         if not bbox:
#             continue
        
#         x1, y1, x2, y2 = bbox
#         pair_id = pair['id']
#         new_text = replacement_values.get(pair_id, pair['value'])
#         pair["new_value"] = new_text
        
#         # Try to load font
#         try:
#             font = ImageFont.truetype("arial.ttf", 14)
#         except:
#             font = ImageFont.load_default()
        
#         # Calculate text position
#         bbox_text = draw.textbbox((0,0), new_text, font=font)
#         text_w = bbox_text[2] - bbox_text[0]
#         text_h = bbox_text[3] - bbox_text[1]
#         text_x = x1 + ((x2 - x1 - text_w) // 2)
#         text_y = y1 + ((y2 - y1 - text_h) // 2)
        
#         # Draw white background and text
#         draw.rectangle([x1, y1, x2, y2], fill=(255, 255, 255))
#         draw.text((text_x, text_y), new_text, font=font, fill=(0, 0, 0))
    
#     return np.array(img_pil)

# # Main App
# st.title("📄 Document Processing App")
# st.markdown("Upload a document to extract key-value pairs and edit them visually!")

# # File upload
# uploaded_file = st.file_uploader(
#     "Choose a file", 
#     type=['pdf', 'jpg', 'jpeg', 'png', 'svg'],
#     help="Upload PDF, Image, or SVG file"
# )

# if uploaded_file is not None:
#     file_type = uploaded_file.name.split('.')[-1].lower()
    
#     col1, col2 = st.columns(2)
    
#     with col1:
#         st.subheader("📁 File Information")
#         st.write(f"**Filename:** {uploaded_file.name}")
#         st.write(f"**File Type:** {file_type.upper()}")
#         st.write(f"**File Size:** {uploaded_file.size:,} bytes")
    
#     # Convert to image
#     if st.button("🔄 Process Document"):
#         with st.spinner("Converting document to image..."):
#             img_array = convert_to_png(uploaded_file, file_type)
#             if img_array is not None:
#                 st.session_state.processed_image = img_array
#                 st.success("✅ Document converted successfully!")
#             else:
#                 st.error("❌ Failed to convert document")
    
#     # Show converted image
#     if st.session_state.processed_image is not None:
#         with col2:
#             st.subheader("🖼️ Converted Image")
#             st.image(st.session_state.processed_image, caption="Processed Document", use_column_width=True)
        
#         # Extract text
#         if st.button("📝 Extract Text"):
#             with tempfile.NamedTemporaryFile(delete=False, suffix=f".{file_type}") as tmp_file:
#                 tmp_file.write(uploaded_file.getvalue())
#                 tmp_path = tmp_file.name
            
#             with st.spinner("Extracting text..."):
#                 text = extract_text_from_file(tmp_path, file_type)
#                 os.unlink(tmp_path)
            
#             if text.strip():
#                 st.subheader("📄 Extracted Text")
#                 st.text_area("Raw Text", text, height=200)
                
#                 # Get key-value pairs
#                 kv_pairs = get_key_value_pairs(text)
#                 if kv_pairs:
#                     st.session_state.kv_pairs = kv_pairs
                    
#                     st.subheader("🔑 Extracted Key-Value Pairs")
#                     for pair in kv_pairs:
#                         st.write(f"**ID {pair['id']}:** {pair['key']} → {pair['value']}")
#             else:
#                 st.warning("⚠️ No text found in the document")
    
#     # Select pairs for processing
#     if st.session_state.kv_pairs:
#         st.subheader("✅ Select Pairs to Process")
        
#         selected_ids = st.multiselect(
#             "Choose pairs to draw bounding boxes for:",
#             options=[pair['id'] for pair in st.session_state.kv_pairs],
#             format_func=lambda x: f"ID {x}: {next(p['key'] for p in st.session_state.kv_pairs if p['id'] == x)} → {next(p['value'] for p in st.session_state.kv_pairs if p['id'] == x)}"
#         )
        
#         if selected_ids and st.button("📦 Draw Bounding Boxes"):
#             selected_pairs = [pair for pair in st.session_state.kv_pairs if pair['id'] in selected_ids]
#             st.session_state.selected_pairs = selected_pairs
            
#             with st.spinner("Drawing bounding boxes..."):
#                 bbox_image = draw_bboxes_on_image(st.session_state.processed_image, selected_pairs)
#                 st.session_state.bbox_image = bbox_image
            
#             st.subheader("📦 Image with Bounding Boxes")
#             st.image(bbox_image, caption="Bounding Boxes Drawn", use_column_width=True)
    
#     # Replace text
#     if st.session_state.selected_pairs:
#         st.subheader("✏️ Replace Text")
        
#         replacement_values = {}
#         for pair in st.session_state.selected_pairs:
#             if pair.get('bbox'):
#                 new_value = st.text_input(
#                     f"New value for ID {pair['id']} ({pair['key']}):",
#                     value=pair['value'],
#                     key=f"replace_{pair['id']}"
#                 )
#                 replacement_values[pair['id']] = new_value
        
#         if st.button("🔄 Apply Replacements"):
#             with st.spinner("Applying text replacements..."):
#                 final_image = replace_bboxes(
#                     st.session_state.processed_image, 
#                     st.session_state.selected_pairs, 
#                     replacement_values
#                 )
#                 st.session_state.final_image = final_image
            
#             st.subheader("🎯 Final Result")
#             col1, col2 = st.columns(2)
            
#             with col1:
#                 st.write("**Original with Bounding Boxes:**")
#                 if 'bbox_image' in st.session_state:
#                     st.image(st.session_state.bbox_image, use_column_width=True)
            
#             with col2:
#                 st.write("**Final Result:**")
#                 st.image(final_image, use_column_width=True)
            
#             # Download button
#             img_pil = Image.fromarray(final_image)
#             buf = io.BytesIO()
#             img_pil.save(buf, format='PNG')
#             buf.seek(0)
            
#             st.download_button(
#                 label="📥 Download Final Image",
#                 data=buf,
#                 file_name="final_replaced_image.png",
#                 mime="image/png"
#             )
            
#             # Show replacement summary
#             st.subheader("📊 Replacement Summary")
#             for pair in st.session_state.selected_pairs:
#                 if pair.get('new_value'):
#                     st.write(f"**ID {pair['id']}:** {pair['key']}")
#                     st.write(f"  Original: {pair['value']}")
#                     st.write(f"  New: {pair['new_value']}")
#                     st.write("---")

# # Sidebar info
# st.sidebar.markdown("---")
# st.sidebar.subheader("📋 Instructions")
# st.sidebar.markdown("""
# 1. **Upload** your document (PDF, Image, or SVG)
# 2. **Process** the document to convert it to image
# 3. **Extract** text using OCR
# 4. **Select** key-value pairs to process
# 5. **Draw** bounding boxes around selected pairs
# 6. **Replace** text with new values
# 7. **Download** the final result
# """)

# st.sidebar.markdown("---")
# st.sidebar.subheader("ℹ️ About")
# st.sidebar.markdown("""
# This app processes documents to extract and edit key-value pairs using:
# - **Tesseract OCR** for text extraction
# - **Google Gemini** for key-value pair extraction
# - **OpenCV** for image processing
# - **PIL** for text rendering
# """)


##### working code

# import sys
# import os

# # ✅ Ensure local form_data_augmentation is prioritized
# sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))
# # Add the project folder to sys.path FIRST!
# sys.path.append(r"C:\Users\KTHRMFST\Documents\Insurance_framework")

# print("✅ CWD:", os.getcwd())
# print("✅ sys.path:", sys.path)
# print("✅ Files:", os.listdir())

# from form_data_augmentation.basic_transform import (
#     blur, contrast_and_brighten, gamma_saturation,
#     lcd_overlay, noise, rotate, scanner_like, shadow,
#     watermark, wrinkles
# )
# from form_data_augmentation.affine_transform import rotation

# from form_data_augmentation.distortion import (
#     distort, perspective, stretch
# )


# from form_data_augmentation.basic_transform import (
#     rotate, shadow, watermark, wrinkles,
#     lcd_overlay, gamma_saturation, contrast_and_brighten,
#     scanner_like, blur
# )

# from form_data_augmentation.distortion import (
#     distort, perspective, stretch
# )



# import streamlit as st
# import os
# import tempfile
# import io
# import json
# import numpy as np
# from PIL import Image, ImageDraw, ImageFont
# import cv2
# import pytesseract
# from pytesseract import Output
# import cairosvg
# from pdfminer.high_level import extract_text as pdfminer_extract_text
# from pdf2image import convert_from_path
# import google.generativeai as genai

# # -------------------------------
# # ✅ Page config
# # -------------------------------
# st.set_page_config(page_title="📄 Document Processing App", layout="wide")
# st.title("📄 Document Processing App")
# st.markdown("Upload a document, extract key-value pairs, draw bounding boxes, and edit them visually!")

# # -------------------------------
# # ✅ Sidebar config
# # -------------------------------
# st.sidebar.header("Configuration")
# tesseract_path = st.sidebar.text_input("Tesseract Path", value=r"C:\Program Files\Tesseract-OCR\tesseract.exe")
# poppler_path = st.sidebar.text_input("Poppler Path", value=r"C:\Users\KTHRMFST\Downloads\Release-24.07.0-0\poppler-24.07.0\Library\bin")
# gemini_api_key = st.sidebar.text_input("Gemini API Key", type="password", value="AIzaSyAjp9fxh8rz68VPxNoLO9EXkw9_XKJ4RoA")

# pytesseract.pytesseract.tesseract_cmd = tesseract_path
# genai.configure(api_key=gemini_api_key)



# import os
# import streamlit as st  # if not already imported

# # st.write("✅ Current working dir:", os.getcwd())
# # st.write("✅ sys.path:", sys.path)
# # st.write("✅ Files here:", os.listdir())

# # -------------------------------
# # ✅ Session state init
# # -------------------------------
# if 'processed_image' not in st.session_state:
#     st.session_state.processed_image = None
# if 'kv_pairs' not in st.session_state:
#     st.session_state.kv_pairs = []
# if 'selected_pairs' not in st.session_state:
#     st.session_state.selected_pairs = []
# if 'bbox_image' not in st.session_state:
#     st.session_state.bbox_image = None
# if 'final_image' not in st.session_state:
#     st.session_state.final_image = None

# # -------------------------------
# # ✅ Helpers
# # -------------------------------
# def extract_text_from_file(file_path, file_type):
#     """Extract text using pdfminer or OCR fallback"""
#     text = ""
#     if file_type == "pdf":
#         text = pdfminer_extract_text(file_path)
#         if not text.strip():
#             images = convert_from_path(file_path, poppler_path=poppler_path)
#             for img in images:
#                 text += pytesseract.image_to_string(img)
#     elif file_type in ["jpg", "jpeg", "png"]:
#         img = Image.open(file_path)
#         text = pytesseract.image_to_string(img)
#     elif file_type == "svg":
#         png_path = file_path + ".png"
#         cairosvg.svg2png(url=file_path, write_to=png_path)
#         img = Image.open(png_path)
#         text = pytesseract.image_to_string(img)
#         os.remove(png_path)
#     else:
#         st.error("Unsupported file type!")
#     return text

# def convert_to_png(uploaded_file, file_type):
#     """Convert uploaded file to PNG numpy array"""
#     if file_type == "pdf":
#         with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp_file:
#             tmp_file.write(uploaded_file.getvalue())
#             tmp_path = tmp_file.name
#         pages = convert_from_path(tmp_path, poppler_path=poppler_path)
#         os.unlink(tmp_path)
#         if pages:
#             return np.array(pages[0])
#     elif file_type in ["jpg", "jpeg", "png"]:
#         img = Image.open(uploaded_file)
#         return np.array(img)
#     elif file_type == "svg":
#         with tempfile.NamedTemporaryFile(delete=False, suffix=".svg") as tmp_file:
#             tmp_file.write(uploaded_file.getvalue())
#             tmp_path = tmp_file.name
#         png_path = tmp_path + ".png"
#         cairosvg.svg2png(url=tmp_path, write_to=png_path)
#         img = Image.open(png_path)
#         img_array = np.array(img)
#         os.unlink(tmp_path)
#         os.unlink(png_path)
#         return img_array
#     return None

# def get_key_value_pairs(text):
#     """Extract key-value pairs using Gemini"""
#     prompt = (
#         "Extract all key-value pairs clearly from this insurance text. "
#         "Format the output as a JSON array with keys: 'key' and 'value'.\n\n"
#         f"{text}"
#     )
#     with st.spinner("Extracting key-value pairs with Gemini..."):
#         try:
#             model = genai.GenerativeModel("gemini-1.5-flash-latest")
#             response = model.generate_content(prompt)
#             raw_output = response.text.strip()
#             cleaned = raw_output
#             if cleaned.startswith("```json"):
#                 cleaned = cleaned[len("```json"):].strip()
#             if cleaned.endswith("```"):
#                 cleaned = cleaned[:-3].strip()
#             data = json.loads(cleaned)
#             for idx, pair in enumerate(data, 1):
#                 pair['id'] = idx
#             st.success(f"Extracted {len(data)} key-value pairs")
#             return data
#         except Exception as e:
#             st.error(f"Gemini extraction failed: {e}")
#             return []

# def draw_bboxes_on_image(image_array, selected_pairs):
#     """Draw red bounding boxes on image using OCR"""
#     img = cv2.cvtColor(image_array, cv2.COLOR_RGB2BGR)
#     final_img = img.copy()
#     ocr_data = pytesseract.image_to_data(img, output_type=Output.DICT)
#     n_boxes = len(ocr_data['text'])
#     for pair in selected_pairs:
#         key = pair['key'].strip().lower()
#         value = pair['value'].strip().lower()
#         found = False
#         for block_num in set(ocr_data['block_num']):
#             for line_num in set(ocr_data['line_num']):
#                 line_words = [
#                     (ocr_data['text'][i].strip().lower(), i)
#                     for i in range(n_boxes)
#                     if ocr_data['block_num'][i] == block_num and ocr_data['line_num'][i] == line_num and ocr_data['text'][i].strip()
#                 ]
#                 if not line_words:
#                     continue
#                 line_text = " ".join([w for w, _ in line_words])
#                 if key in line_text and value in line_text:
#                     for word, idx in line_words:
#                         if word in value:
#                             x, y, w, h = ocr_data['left'][idx], ocr_data['top'][idx], ocr_data['width'][idx], ocr_data['height'][idx]
#                             x2, y2 = x + w, y + h
#                             cv2.rectangle(final_img, (x, y), (x2, y2), (0, 0, 255), 2)  # 🔴 Red box
#                             cv2.putText(final_img, f"ID {pair['id']}", (x, y-5),
#                                         cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1)  # 🔴 Red text
#                             pair['bbox'] = [x, y, x2, y2]
#                             found = True
#         if not found:
#             st.warning(f"❌ Value not found for ID {pair['id']}")
#     return cv2.cvtColor(final_img, cv2.COLOR_BGR2RGB)


# def replace_bboxes(image_array, pairs_with_bboxes, replacement_values):
#     img = cv2.cvtColor(image_array, cv2.COLOR_RGB2BGR)
#     mask = np.zeros(img.shape[:2], dtype=np.uint8)
#     for pair in pairs_with_bboxes:
#         bbox = pair.get("bbox")
#         if bbox:
#             x1, y1, x2, y2 = bbox
#             mask[y1:y2, x1:x2] = 255
#     img_inpainted = cv2.inpaint(img, mask, 3, cv2.INPAINT_TELEA)
#     img_pil = Image.fromarray(cv2.cvtColor(img_inpainted, cv2.COLOR_BGR2RGB))
#     draw = ImageDraw.Draw(img_pil)
#     for pair in pairs_with_bboxes:
#         bbox = pair.get("bbox")
#         if bbox:
#             x1, y1, x2, y2 = bbox
#             pair_id = pair['id']
#             new_text = replacement_values.get(pair_id, pair['value'])
#             pair["new_value"] = new_text
#             try:
#                 font = ImageFont.truetype("arial.ttf", 14)
#             except:
#                 font = ImageFont.load_default()
#             bbox_text = draw.textbbox((0, 0), new_text, font=font)
#             text_w = bbox_text[2] - bbox_text[0]
#             text_h = bbox_text[3] - bbox_text[1]
#             text_x = x1 + ((x2 - x1 - text_w) // 2)
#             text_y = y1 + ((y2 - y1 - text_h) // 2)
#             draw.rectangle([x1, y1, x2, y2], fill=(255, 255, 255))
#             draw.text((text_x, text_y), new_text, font=font, fill=(0, 0, 0))
#     return np.array(img_pil)

# # -------------------------------
# # ✅ Main Flow
# # -------------------------------
# uploaded_file = st.file_uploader("Upload file", type=["pdf", "jpg", "jpeg", "png", "svg"])
# if uploaded_file:
#     file_type = uploaded_file.name.split('.')[-1].lower()
#     col1, col2 = st.columns(2)
#     with col1:
#         st.write(f"**Filename:** {uploaded_file.name}")
#         st.write(f"**Type:** {file_type.upper()}")
#     if st.button("🔄 Convert to Image"):
#         img_array = convert_to_png(uploaded_file, file_type)
#         if img_array is not None:
#             st.session_state.processed_image = img_array
#             st.success("✅ Converted!")
#         else:
#             st.error("❌ Failed to convert.")
#     if st.session_state.processed_image is not None:
#         with col2:
#             st.image(st.session_state.processed_image, caption="Processed Document", use_column_width=True)
#         if st.button("📝 Extract Text & Pairs"):
#             with tempfile.NamedTemporaryFile(delete=False, suffix=f".{file_type}") as tmp_file:
#                 tmp_file.write(uploaded_file.getvalue())
#                 tmp_path = tmp_file.name
#             text = extract_text_from_file(tmp_path, file_type)
#             os.unlink(tmp_path)
#             if text.strip():
#                 st.text_area("Extracted Text", text, height=200)
#                 kv_pairs = get_key_value_pairs(text)
#                 st.session_state.kv_pairs = kv_pairs
#             else:
#                 st.warning("No text found.")
#     if st.session_state.kv_pairs:
#         st.subheader("✅ Select Pairs to Process")
        
#         options = ['All'] + [pair['id'] for pair in st.session_state.kv_pairs]
        
#         selected_ids = st.multiselect(
#             "Choose pairs to draw bounding boxes for:",
#             options=options,
#             format_func=lambda x: (
#                 "🔴 ALL"
#                 if x == 'All'
#                 else f"ID {x}: {next(p['key'] for p in st.session_state.kv_pairs if p['id'] == x)} → {next(p['value'] for p in st.session_state.kv_pairs if p['id'] == x)}"
#             )
#         )

#         # If 'All' is selected, use every pair ID
#         if 'All' in selected_ids:
#             selected_ids = [pair['id'] for pair in st.session_state.kv_pairs]

#         if selected_ids and st.button("📦 Draw Bounding Boxes"):
#             selected_pairs = [pair for pair in st.session_state.kv_pairs if pair['id'] in selected_ids]
#             st.session_state.selected_pairs = selected_pairs
#             bbox_img = draw_bboxes_on_image(st.session_state.processed_image, selected_pairs)
#             st.session_state.bbox_image = bbox_img
#             st.image(bbox_img, caption="Bounding Boxes", use_column_width=True)

#     if st.session_state.selected_pairs:
#         st.subheader("✏️ Replace Text")
#         replacement_values = {}
#         for pair in st.session_state.selected_pairs:
#             if pair.get('bbox'):
#                 new_val = st.text_input(f"New value for ID {pair['id']} ({pair['key']})", value=pair['value'])
#                 replacement_values[pair['id']] = new_val
#         if st.button("🔄 Apply Replacements"):
#             final_img = replace_bboxes(st.session_state.processed_image, st.session_state.selected_pairs, replacement_values)
#             st.session_state.final_image = final_img
#             st.image(final_img, caption="Final Image", use_column_width=True)
#             buf = io.BytesIO()
#             Image.fromarray(final_img).save(buf, format="PNG")
#             st.download_button("📥 Download", data=buf.getvalue(), file_name="final_image.png", mime="image/png")



# def apply_selected_augmentations(image_array, selected_augs):
#     """
#     Apply a list of augmentations to the image in order.
#     """
#     img_bgr = cv2.cvtColor(image_array, cv2.COLOR_RGB2BGR)
#     aug_img = img_bgr.copy()

#     for aug in selected_augs:
#         aug_img = aug(aug_img)

#     aug_img_rgb = cv2.cvtColor(aug_img, cv2.COLOR_BGR2RGB)
#     return aug_img_rgb

# # ----------------------------------------
# # ✅ UI: Let user pick augmentations
# # ----------------------------------------
# if st.session_state.final_image is not None:
#     st.subheader("✨ Add Form Data Augmentation")

#     st.markdown("Select which augmentations to apply:")

#     augmentations = {
#         "Rotate": rotate,
#         "Shadow": shadow,
#         "Watermark": watermark,
#         "Wrinkles": wrinkles,
#         "LCD Overlay": lcd_overlay,
#         "Gamma Saturation": gamma_saturation,
#         "Contrast & Brighten": contrast_and_brighten,
#         "Scanner-like": scanner_like,
#         "Distort": distort,
#         "Perspective": perspective,
#         "Stretch": stretch,
#         "Blur": blur,
#         "Noise": noise,
#     }

#     selected_aug_funcs = []
#     for aug_name, aug_func in augmentations.items():
#         if st.checkbox(f"✅ {aug_name}"):
#             selected_aug_funcs.append(aug_func)

#     if selected_aug_funcs and st.button("⚡ Apply Selected Augmentations"):
#         with st.spinner("Applying selected augmentations..."):
#             aug_img = apply_selected_augmentations(st.session_state.final_image, selected_aug_funcs)
#             st.session_state.augmented_image = aug_img

#         st.image(st.session_state.augmented_image, caption="Augmented Image", use_column_width=True)

#         # ✅ Option to download final augmented image
#         buf = io.BytesIO()
#         Image.fromarray(st.session_state.augmented_image).save(buf, format="PNG")
#         st.download_button(
#             "📥 Download Augmented Image",
#             data=buf.getvalue(),
#             file_name="augmented_image.png",
#             mime="image/png"
#         )
# # -------------------------------
# # ✅ Sidebar Instructions
# # -------------------------------
# st.sidebar.markdown("---")
# st.sidebar.subheader("How to use:")
# st.sidebar.markdown("""
# 1. Upload a PDF, Image, or SVG.
# 2. Click **Convert to Image**.
# 3. Extract text & key-value pairs.
# 4. Select pairs, draw boxes.
# 5. Edit & replace text.
# 6. Download final image.
# """)



# import sys
# import os
# import tempfile
# import io
# import json
# import numpy as np
# from PIL import Image, ImageDraw, ImageFont
# import cv2
# import pytesseract
# from pytesseract import Output
# import cairosvg
# from pdfminer.high_level import extract_text as pdfminer_extract_text
# from pdf2image import convert_from_path
# import google.generativeai as genai
# import streamlit as st

# # ✅ Ensure local form_data_augmentation is prioritized
# sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))
# sys.path.append(r"C:\Users\KTHRMFST\Documents\Insurance_framework")

# # Import augmentation functions
# from form_data_augmentation.basic_transform import (
#     blur, contrast_and_brighten, gamma_saturation,
#     lcd_overlay, noise, rotate, scanner_like, shadow,
#     watermark, wrinkles
# )
# from form_data_augmentation.affine_transform import rotation
# from form_data_augmentation.distortion import (
#     distort, perspective, stretch
# )

# # ===================================
# # PAGE CONFIGURATION
# # ===================================
# st.set_page_config(page_title="📄 Document Processing App", layout="wide")
# st.title("📄 Document Processing App")
# st.markdown("Upload a document, extract key-value pairs, draw bounding boxes, and edit them visually!")

# # ===================================
# # SIDEBAR CONFIGURATION
# # ===================================
# st.sidebar.header("Configuration")
# tesseract_path = st.sidebar.text_input(
#     "Tesseract Path", 
#     value=r"C:\Program Files\Tesseract-OCR\tesseract.exe"
# )
# poppler_path = st.sidebar.text_input(
#     "Poppler Path", 
#     value=r"C:\Users\KTHRMFST\Downloads\Release-24.07.0-0\poppler-24.07.0\Library\bin"
# )
# gemini_api_key = st.sidebar.text_input(
#     "Gemini API Key", 
#     type="password", 
#     value="AIzaSyA1RHCSoYf1WtX6PFNMK_Y8pb3UZw1dzNc"
# )

# # Configure external tools
# pytesseract.pytesseract.tesseract_cmd = tesseract_path
# genai.configure(api_key=gemini_api_key)

# # ===================================
# # SESSION STATE INITIALIZATION
# # ===================================
# def init_session_state():
#     """Initialize all session state variables"""
#     session_vars = {
#         'processed_image': None,
#         'kv_pairs': [],
#         'selected_pairs': [],
#         'bbox_image': None,
#         'final_image': None,
#         'augmented_image': None
#     }
    
#     for var, default_value in session_vars.items():
#         if var not in st.session_state:
#             st.session_state[var] = default_value

# init_session_state()

# # ===================================
# # HELPER FUNCTIONS
# # ===================================
# def extract_text_from_file(file_path, file_type):
#     """Extract text from various file types using OCR or direct extraction"""
#     text = ""
    
#     try:
#         if file_type == "pdf":
#             text = pdfminer_extract_text(file_path)
#             if not text.strip():
#                 images = convert_from_path(file_path, poppler_path=poppler_path)
#                 for img in images:
#                     text += pytesseract.image_to_string(img)
                    
#         elif file_type in ["jpg", "jpeg", "png"]:
#             img = Image.open(file_path)
#             text = pytesseract.image_to_string(img)
            
#         elif file_type == "svg":
#             png_path = file_path + ".png"
#             cairosvg.svg2png(url=file_path, write_to=png_path)
#             img = Image.open(png_path)
#             text = pytesseract.image_to_string(img)
#             os.remove(png_path)
            
#         else:
#             st.error("Unsupported file type!")
            
#     except Exception as e:
#         st.error(f"Error extracting text: {e}")
        
#     return text

# def convert_to_png(uploaded_file, file_type):
#     """Convert uploaded file to PNG numpy array"""
#     try:
#         if file_type == "pdf":
#             with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp_file:
#                 tmp_file.write(uploaded_file.getvalue())
#                 tmp_path = tmp_file.name
            
#             pages = convert_from_path(tmp_path, poppler_path=poppler_path)
#             os.unlink(tmp_path)
            
#             if pages:
#                 return np.array(pages[0])
                
#         elif file_type in ["jpg", "jpeg", "png"]:
#             img = Image.open(uploaded_file)
#             return np.array(img)
            
#         elif file_type == "svg":
#             with tempfile.NamedTemporaryFile(delete=False, suffix=".svg") as tmp_file:
#                 tmp_file.write(uploaded_file.getvalue())
#                 tmp_path = tmp_file.name
            
#             png_path = tmp_path + ".png"
#             cairosvg.svg2png(url=tmp_path, write_to=png_path)
#             img = Image.open(png_path)
#             img_array = np.array(img)
            
#             os.unlink(tmp_path)
#             os.unlink(png_path)
#             return img_array
            
#     except Exception as e:
#         st.error(f"Error converting file: {e}")
        
#     return None

# def get_key_value_pairs(text):
#     """Extract key-value pairs using Gemini AI"""
#     prompt = (
#         "Extract all key-value pairs clearly from this insurance text. "
#         "Format the output as a JSON array with keys: 'key' and 'value'.\n\n"
#         f"{text}"
#     )
    
#     with st.spinner("Extracting key-value pairs with Gemini..."):
#         try:
#             model = genai.GenerativeModel("gemini-1.5-flash-latest")
#             response = model.generate_content(prompt)
#             raw_output = response.text.strip()
            
#             # Clean the response
#             cleaned = raw_output
#             if cleaned.startswith("```json"):
#                 cleaned = cleaned[len("```json"):].strip()
#             if cleaned.endswith("```"):
#                 cleaned = cleaned[:-3].strip()
            
#             data = json.loads(cleaned)
            
#             # Add IDs to pairs
#             for idx, pair in enumerate(data, 1):
#                 pair['id'] = idx
                
#             st.success(f"Extracted {len(data)} key-value pairs")
#             return data
            
#         except Exception as e:
#             st.error(f"Gemini extraction failed: {e}")
#             return []

# def draw_bboxes_on_image(image_array, selected_pairs):
#     """Draw red bounding boxes around selected key-value pairs"""
#     img = cv2.cvtColor(image_array, cv2.COLOR_RGB2BGR)
#     final_img = img.copy()
#     ocr_data = pytesseract.image_to_data(img, output_type=Output.DICT)
#     n_boxes = len(ocr_data['text'])
    
#     for pair in selected_pairs:
#         key = pair['key'].strip().lower()
#         value = pair['value'].strip().lower()
#         found = False
        
#         for block_num in set(ocr_data['block_num']):
#             for line_num in set(ocr_data['line_num']):
#                 line_words = [
#                     (ocr_data['text'][i].strip().lower(), i)
#                     for i in range(n_boxes)
#                     if (ocr_data['block_num'][i] == block_num and 
#                         ocr_data['line_num'][i] == line_num and 
#                         ocr_data['text'][i].strip())
#                 ]
                
#                 if not line_words:
#                     continue
                    
#                 line_text = " ".join([w for w, _ in line_words])
                
#                 if key in line_text and value in line_text:
#                     for word, idx in line_words:
#                         if word in value:
#                             x, y, w, h = (ocr_data['left'][idx], ocr_data['top'][idx], 
#                                         ocr_data['width'][idx], ocr_data['height'][idx])
#                             x2, y2 = x + w, y + h
                            
#                             # Draw red bounding box
#                             cv2.rectangle(final_img, (x, y), (x2, y2), (0, 0, 255), 2)
#                             cv2.putText(final_img, f"ID {pair['id']}", (x, y-5),
#                                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1)
                            
#                             pair['bbox'] = [x, y, x2, y2]
#                             found = True
                            
#         if not found:
#             st.warning(f"❌ Value not found for ID {pair['id']}")
            
#     return cv2.cvtColor(final_img, cv2.COLOR_BGR2RGB)

# def replace_bboxes(image_array, pairs_with_bboxes, replacement_values):
#     """Replace text in bounding boxes with new values"""
#     img = cv2.cvtColor(image_array, cv2.COLOR_RGB2BGR)
#     mask = np.zeros(img.shape[:2], dtype=np.uint8)
    
#     # Create mask for inpainting
#     for pair in pairs_with_bboxes:
#         bbox = pair.get("bbox")
#         if bbox:
#             x1, y1, x2, y2 = bbox
#             mask[y1:y2, x1:x2] = 255
    
#     # Inpaint to remove original text
#     img_inpainted = cv2.inpaint(img, mask, 3, cv2.INPAINT_TELEA)
#     img_pil = Image.fromarray(cv2.cvtColor(img_inpainted, cv2.COLOR_BGR2RGB))
#     draw = ImageDraw.Draw(img_pil)
    
#     # Add new text
#     for pair in pairs_with_bboxes:
#         bbox = pair.get("bbox")
#         if bbox:
#             x1, y1, x2, y2 = bbox
#             pair_id = pair['id']
#             new_text = replacement_values.get(pair_id, pair['value'])
#             pair["new_value"] = new_text
            
#             # Load font
#             try:
#                 font = ImageFont.truetype("arial.ttf", 14)
#             except:
#                 font = ImageFont.load_default()
            
#             # Calculate text position
#             bbox_text = draw.textbbox((0, 0), new_text, font=font)
#             text_w = bbox_text[2] - bbox_text[0]
#             text_h = bbox_text[3] - bbox_text[1]
#             text_x = x1 + ((x2 - x1 - text_w) // 2)
#             text_y = y1 + ((y2 - y1 - text_h) // 2)
            
#             # Draw white background and black text
#             draw.rectangle([x1, y1, x2, y2], fill=(255, 255, 255))
#             draw.text((text_x, text_y), new_text, font=font, fill=(0, 0, 0))
    
#     return np.array(img_pil)

# def safe_noise_wrapper(img):
#     """Safe wrapper for noise function to handle bounds issues"""
#     try:
#         # Ensure image is in correct format
#         if len(img.shape) == 3 and img.shape[2] == 3:
#             return noise(img)
#         else:
#             st.warning("Image format not suitable for noise augmentation, skipping...")
#             return img
#     except IndexError as e:
#         st.warning(f"Noise augmentation failed due to index error: {e}. Skipping noise.")
#         return img
#     except Exception as e:
#         st.warning(f"Noise augmentation failed: {e}. Skipping noise.")
#         return img

# def apply_selected_augmentations(image_array, selected_augs):
#     """Apply selected augmentations to the image with error handling"""
#     img_bgr = cv2.cvtColor(image_array, cv2.COLOR_RGB2BGR)
#     aug_img = img_bgr.copy()
    
#     for i, aug in enumerate(selected_augs):
#         try:
#             # Special handling for noise function
#             if hasattr(aug, '__name__') and aug.__name__ == 'noise':
#                 result = safe_noise_wrapper(aug_img)
#             else:
#                 result = aug(aug_img)
            
#             # Validate the result
#             if result is not None and result.shape == aug_img.shape:
#                 aug_img = result
#             else:
#                 st.warning(f"Augmentation {i+1} returned invalid result, skipping...")
#                 continue
                
#         except Exception as e:
#             aug_name = getattr(aug, '__name__', f'Augmentation {i+1}')
#             st.warning(f"Error applying {aug_name}: {str(e)}. Skipping this augmentation.")
#             continue
    
#     return cv2.cvtColor(aug_img, cv2.COLOR_BGR2RGB)

# # ===================================
# # MAIN APPLICATION FLOW
# # ===================================
# def main():
#     """Main application flow"""
    
#     # File upload
#     uploaded_file = st.file_uploader(
#         "Upload file", 
#         type=["pdf", "jpg", "jpeg", "png", "svg"]
#     )
    
#     if uploaded_file:
#         file_type = uploaded_file.name.split('.')[-1].lower()
        
#         col1, col2 = st.columns(2)
#         with col1:
#             st.write(f"**Filename:** {uploaded_file.name}")
#             st.write(f"**Type:** {file_type.upper()}")
        
#         # Convert to image
#         if st.button("🔄 Convert to Image"):
#             img_array = convert_to_png(uploaded_file, file_type)
#             if img_array is not None:
#                 st.session_state.processed_image = img_array
#                 st.success("✅ Converted!")
#             else:
#                 st.error("❌ Failed to convert.")
        
#         # Display processed image
#         if st.session_state.processed_image is not None:
#             with col2:
#                 st.image(
#                     st.session_state.processed_image, 
#                     caption="Processed Document", 
#                     use_column_width=True
#                 )
            
#             # Extract text and key-value pairs
#             if st.button("📝 Extract Text & Pairs"):
#                 with tempfile.NamedTemporaryFile(delete=False, suffix=f".{file_type}") as tmp_file:
#                     tmp_file.write(uploaded_file.getvalue())
#                     tmp_path = tmp_file.name
                
#                 text = extract_text_from_file(tmp_path, file_type)
#                 os.unlink(tmp_path)
                
#                 if text.strip():
#                     st.text_area("Extracted Text", text, height=200)
#                     kv_pairs = get_key_value_pairs(text)
#                     st.session_state.kv_pairs = kv_pairs
#                 else:
#                     st.warning("No text found.")
    
#     # Select pairs and draw bounding boxes
#     if st.session_state.kv_pairs:
#         st.subheader("✅ Select Pairs to Process")
        
#         options = ['All'] + [pair['id'] for pair in st.session_state.kv_pairs]
        
#         selected_ids = st.multiselect(
#             "Choose pairs to draw bounding boxes for:",
#             options=options,
#             format_func=lambda x: (
#                 "🔴 ALL" if x == 'All' else
#                 f"ID {x}: {next(p['key'] for p in st.session_state.kv_pairs if p['id'] == x)} → "
#                 f"{next(p['value'] for p in st.session_state.kv_pairs if p['id'] == x)}"
#             )
#         )
        
#         # Handle "All" selection
#         if 'All' in selected_ids:
#             selected_ids = [pair['id'] for pair in st.session_state.kv_pairs]
        
#         if selected_ids and st.button("📦 Draw Bounding Boxes"):
#             selected_pairs = [pair for pair in st.session_state.kv_pairs if pair['id'] in selected_ids]
#             st.session_state.selected_pairs = selected_pairs
#             bbox_img = draw_bboxes_on_image(st.session_state.processed_image, selected_pairs)
#             st.session_state.bbox_image = bbox_img
#             st.image(bbox_img, caption="Bounding Boxes", use_column_width=True)
    
#     # Replace text
#     if st.session_state.selected_pairs:
#         st.subheader("✏️ Replace Text")
#         replacement_values = {}
        
#         for pair in st.session_state.selected_pairs:
#             if pair.get('bbox'):
#                 new_val = st.text_input(
#                     f"New value for ID {pair['id']} ({pair['key']})", 
#                     value=pair['value']
#                 )
#                 replacement_values[pair['id']] = new_val
        
#         if st.button("🔄 Apply Replacements"):
#             final_img = replace_bboxes(
#                 st.session_state.processed_image, 
#                 st.session_state.selected_pairs, 
#                 replacement_values
#             )
#             st.session_state.final_image = final_img
#             st.image(final_img, caption="Final Image", use_column_width=True)
            
#             # Download button
#             buf = io.BytesIO()
#             Image.fromarray(final_img).save(buf, format="PNG")
#             st.download_button(
#                 "📥 Download", 
#                 data=buf.getvalue(), 
#                 file_name="final_image.png", 
#                 mime="image/png"
#             )
    
#     # Augmentation section
#     if st.session_state.final_image is not None:
#         st.subheader("✨ Add Form Data Augmentation")
#         st.markdown("Select which augmentations to apply:")
        
#         augmentations = {
#             "Rotate": rotate,
#             "Shadow": shadow,
#             "Watermark": watermark,
#             "Wrinkles": wrinkles,
#             "LCD Overlay": lcd_overlay,
#             "Gamma Saturation": gamma_saturation,
#             "Contrast & Brighten": contrast_and_brighten,
#             "Scanner-like": scanner_like,
#             "Distort": distort,
#             "Perspective": perspective,
#             "Stretch": stretch,
#             "Blur": blur,
#             "Noise": noise,
#         }
        
#         # Add "All" checkbox
#         apply_all = st.checkbox("🔴 Apply All Augmentations")
        
#         selected_aug_funcs = []
#         selected_aug_names = []
        
#         if apply_all:
#             # If "All" is selected, add all augmentation functions
#             selected_aug_funcs = list(augmentations.values())
#             selected_aug_names = list(augmentations.keys())
#             # Display all augmentations as selected (disabled checkboxes)
#             st.markdown("**All augmentations selected:**")
#             for aug_name in augmentations.keys():
#                 st.checkbox(f"✅ {aug_name}", value=True, disabled=True, key=f"disabled_{aug_name}")
#         else:
#             # Individual selection
#             for aug_name, aug_func in augmentations.items():
#                 if st.checkbox(f"✅ {aug_name}"):
#                     selected_aug_funcs.append(aug_func)
#                     selected_aug_names.append(aug_name)
        
#         if selected_aug_funcs and st.button("⚡ Apply Selected Augmentations"):
#             with st.spinner("Applying selected augmentations..."):
#                 if apply_all:
#                     # Show each augmentation step by step
#                     st.markdown("### 📸 Augmentation Steps:")
                    
#                     img_bgr = cv2.cvtColor(st.session_state.final_image, cv2.COLOR_RGB2BGR)
#                     current_img = img_bgr.copy()
                    
#                     # Create columns for displaying images
#                     cols = st.columns(3)  # 3 columns for better layout
#                     col_index = 0
                    
#                     for i, (aug_name, aug_func) in enumerate(zip(selected_aug_names, selected_aug_funcs)):
#                         try:
#                             # Apply single augmentation
#                             if hasattr(aug_func, '__name__') and aug_func.__name__ == 'noise':
#                                 result = safe_noise_wrapper(current_img)
#                             else:
#                                 result = aug_func(current_img)
                            
#                             if result is not None and result.shape == current_img.shape:
#                                 current_img = result
#                                 # Convert to RGB for display
#                                 display_img = cv2.cvtColor(current_img, cv2.COLOR_BGR2RGB)
                                
#                                 # Display in columns
#                                 with cols[col_index % 3]:
#                                     st.image(
#                                         display_img, 
#                                         caption=f"{i+1}. {aug_name}", 
#                                         use_column_width=True
#                                     )
#                                 col_index += 1
#                             else:
#                                 st.warning(f"❌ {aug_name} failed, skipping...")
                                
#                         except Exception as e:
#                             st.warning(f"❌ Error applying {aug_name}: {str(e)}")
#                             continue
                    
#                     # Final result
#                     final_aug_img = cv2.cvtColor(current_img, cv2.COLOR_BGR2RGB)
#                     st.session_state.augmented_image = final_aug_img
                    
#                     st.markdown("### 🎯 Final Result:")
#                     st.image(final_aug_img, caption="All Augmentations Applied", use_column_width=True)
                    
#                 else:
#                     # Regular processing for individual selections
#                     aug_img = apply_selected_augmentations(
#                         st.session_state.final_image, 
#                         selected_aug_funcs
#                     )
#                     st.session_state.augmented_image = aug_img
#                     st.image(aug_img, caption="Augmented Image", use_column_width=True)
            
#             # Download augmented image
#             if 'augmented_image' in st.session_state and st.session_state.augmented_image is not None:
#                 buf = io.BytesIO()
#                 Image.fromarray(st.session_state.augmented_image).save(buf, format="PNG")
#                 st.download_button(
#                     "📥 Download Augmented Image",
#                     data=buf.getvalue(),
#                     file_name="augmented_image.png",
#                     mime="image/png"
#                 )

# # ===================================
# # SIDEBAR INSTRUCTIONS
# # ===================================
# def add_sidebar_instructions():
#     """Add usage instructions to sidebar"""
#     st.sidebar.markdown("---")
#     st.sidebar.subheader("How to use:")
#     st.sidebar.markdown("""
#     1. Upload a PDF, Image, or SVG.
#     2. Click **Convert to Image**.
#     3. Extract text & key-value pairs.
#     4. Select pairs, draw boxes.
#     5. Edit & replace text.
#     6. Download final image.
#     7. (Optional) Apply augmentations.
#     """)

# # ===================================
# # RUN APPLICATION
# # ===================================
# if __name__ == "__main__":
#     main()
#     add_sidebar_instructions()


### all augemnation with diff cat

import sys
import os
import tempfile
import io
import json
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import cv2
import pytesseract
from pytesseract import Output
import cairosvg
from pdfminer.high_level import extract_text as pdfminer_extract_text
from pdf2image import convert_from_path
import google.generativeai as genai
import streamlit as st

# ✅ Ensure local form_data_augmentation is prioritized
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))
sys.path.append(r"C:\Users\KTHRMFST\Documents\Insurance_framework")

# Import augmentation functions
from form_data_augmentation.basic_transform import (
    blur, contrast_and_brighten, gamma_saturation,
    lcd_overlay, noise, rotate, scanner_like, shadow,
    watermark, wrinkles
)
from form_data_augmentation.affine_transform import rotation
from form_data_augmentation.distortion import (
    distort, perspective, stretch
)

# ===================================
# PAGE CONFIGURATION
# ===================================
st.set_page_config(page_title="📄 Document Processing App", layout="wide")
st.title("📄 Document Processing App")
st.markdown("Upload a document, extract key-value pairs, draw bounding boxes, and edit them visually!")

# ===================================
# SIDEBAR CONFIGURATION
# ===================================
st.sidebar.header("Configuration")
tesseract_path = st.sidebar.text_input(
    "Tesseract Path", 
    value=r"C:\Program Files\Tesseract-OCR\tesseract.exe"
)
poppler_path = st.sidebar.text_input(
    "Poppler Path", 
    value=r"C:\Users\KTHRMFST\Downloads\Release-24.07.0-0\poppler-24.07.0\Library\bin"
)
gemini_api_key = st.sidebar.text_input(
    "Gemini API Key", 
    type="password", 
    value="AIzaSyC9QMq5oap-wkDyU3YEOTDVez8wO2kMBBw"
)

# Configure external tools
pytesseract.pytesseract.tesseract_cmd = tesseract_path
genai.configure(api_key=gemini_api_key)

# ===================================
# SESSION STATE INITIALIZATION
# ===================================
def init_session_state():
    """Initialize all session state variables"""
    session_vars = {
        'processed_image': None,
        'kv_pairs': [],
        'selected_pairs': [],
        'bbox_image': None,
        'final_image': None,
        'augmented_image': None,
        'augmented_images_dict': {}
    }
    
    for var, default_value in session_vars.items():
        if var not in st.session_state:
            st.session_state[var] = default_value

init_session_state()

# ===================================
# HELPER FUNCTIONS
# ===================================
def extract_text_from_file(file_path, file_type):
    """Extract text from various file types using OCR or direct extraction"""
    text = ""
    
    try:
        if file_type == "pdf":
            text = pdfminer_extract_text(file_path)
            if not text.strip():
                images = convert_from_path(file_path, poppler_path=poppler_path)
                for img in images:
                    text += pytesseract.image_to_string(img)
                    
        elif file_type in ["jpg", "jpeg", "png"]:
            img = Image.open(file_path)
            text = pytesseract.image_to_string(img)
            
        elif file_type == "svg":
            png_path = file_path + ".png"
            cairosvg.svg2png(url=file_path, write_to=png_path)
            img = Image.open(png_path)
            text = pytesseract.image_to_string(img)
            os.remove(png_path)
            
        else:
            st.error("Unsupported file type!")
            
    except Exception as e:
        st.error(f"Error extracting text: {e}")
        
    return text

def convert_to_png(uploaded_file, file_type):
    """Convert uploaded file to PNG numpy array"""
    try:
        if file_type == "pdf":
            with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp_file:
                tmp_file.write(uploaded_file.getvalue())
                tmp_path = tmp_file.name
            
            pages = convert_from_path(tmp_path, poppler_path=poppler_path)
            os.unlink(tmp_path)
            
            if pages:
                return np.array(pages[0])
                
        elif file_type in ["jpg", "jpeg", "png"]:
            img = Image.open(uploaded_file)
            return np.array(img)
            
        elif file_type == "svg":
            with tempfile.NamedTemporaryFile(delete=False, suffix=".svg") as tmp_file:
                tmp_file.write(uploaded_file.getvalue())
                tmp_path = tmp_file.name
            
            png_path = tmp_path + ".png"
            cairosvg.svg2png(url=tmp_path, write_to=png_path)
            img = Image.open(png_path)
            img_array = np.array(img)
            
            os.unlink(tmp_path)
            os.unlink(png_path)
            return img_array
            
    except Exception as e:
        st.error(f"Error converting file: {e}")
        
    return None

def get_key_value_pairs(text):
    """Extract key-value pairs using Gemini AI"""
    prompt = (
        "Extract all key-value pairs clearly from this insurance text. "
        "Format the output as a JSON array with keys: 'key' and 'value'.\n\n"
        f"{text}"
    )
    
    with st.spinner("Extracting key-value pairs with Gemini..."):
        try:
            model = genai.GenerativeModel("gemini-1.5-flash-latest")
            response = model.generate_content(prompt)
            raw_output = response.text.strip()
            
            # Clean the response
            cleaned = raw_output
            if cleaned.startswith("```json"):
                cleaned = cleaned[len("```json"):].strip()
            if cleaned.endswith("```"):
                cleaned = cleaned[:-3].strip()
            
            data = json.loads(cleaned)
            
            # Add IDs to pairs
            for idx, pair in enumerate(data, 1):
                pair['id'] = idx
                
            st.success(f"Extracted {len(data)} key-value pairs")
            return data
            
        except Exception as e:
            st.error(f"Gemini extraction failed: {e}")
            return []

def draw_bboxes_on_image(image_array, selected_pairs):
    """Draw red bounding boxes around selected key-value pairs"""
    img = cv2.cvtColor(image_array, cv2.COLOR_RGB2BGR)
    final_img = img.copy()
    ocr_data = pytesseract.image_to_data(img, output_type=Output.DICT)
    n_boxes = len(ocr_data['text'])
    
    for pair in selected_pairs:
        key = pair['key'].strip().lower()
        value = pair['value'].strip().lower()
        found = False
        
        for block_num in set(ocr_data['block_num']):
            for line_num in set(ocr_data['line_num']):
                line_words = [
                    (ocr_data['text'][i].strip().lower(), i)
                    for i in range(n_boxes)
                    if (ocr_data['block_num'][i] == block_num and 
                        ocr_data['line_num'][i] == line_num and 
                        ocr_data['text'][i].strip())
                ]
                
                if not line_words:
                    continue
                    
                line_text = " ".join([w for w, _ in line_words])
                
                if key in line_text and value in line_text:
                    for word, idx in line_words:
                        if word in value:
                            x, y, w, h = (ocr_data['left'][idx], ocr_data['top'][idx], 
                                        ocr_data['width'][idx], ocr_data['height'][idx])
                            x2, y2 = x + w, y + h
                            
                            # Draw red bounding box
                            cv2.rectangle(final_img, (x, y), (x2, y2), (0, 0, 255), 2)
                            cv2.putText(final_img, f"ID {pair['id']}", (x, y-5),
                                      cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1)
                            
                            pair['bbox'] = [x, y, x2, y2]
                            found = True
                            
        if not found:
            st.warning(f"❌ Value not found for ID {pair['id']}")
            
    return cv2.cvtColor(final_img, cv2.COLOR_BGR2RGB)

def replace_bboxes(image_array, pairs_with_bboxes, replacement_values):
    """Replace text in bounding boxes with new values"""
    img = cv2.cvtColor(image_array, cv2.COLOR_RGB2BGR)
    mask = np.zeros(img.shape[:2], dtype=np.uint8)
    
    # Create mask for inpainting
    for pair in pairs_with_bboxes:
        bbox = pair.get("bbox")
        if bbox:
            x1, y1, x2, y2 = bbox
            mask[y1:y2, x1:x2] = 255
    
    # Inpaint to remove original text
    img_inpainted = cv2.inpaint(img, mask, 3, cv2.INPAINT_TELEA)
    img_pil = Image.fromarray(cv2.cvtColor(img_inpainted, cv2.COLOR_BGR2RGB))
    draw = ImageDraw.Draw(img_pil)
    
    # Add new text
    for pair in pairs_with_bboxes:
        bbox = pair.get("bbox")
        if bbox:
            x1, y1, x2, y2 = bbox
            pair_id = pair['id']
            new_text = replacement_values.get(pair_id, pair['value'])
            pair["new_value"] = new_text
            
            # Load font
            try:
                font = ImageFont.truetype("arial.ttf", 14)
            except:
                font = ImageFont.load_default()
            
            # Calculate text position
            bbox_text = draw.textbbox((0, 0), new_text, font=font)
            text_w = bbox_text[2] - bbox_text[0]
            text_h = bbox_text[3] - bbox_text[1]
            text_x = x1 + ((x2 - x1 - text_w) // 2)
            text_y = y1 + ((y2 - y1 - text_h) // 2)
            
            # Draw white background and black text
            draw.rectangle([x1, y1, x2, y2], fill=(255, 255, 255))
            draw.text((text_x, text_y), new_text, font=font, fill=(0, 0, 0))
    
    return np.array(img_pil)

def safe_noise_wrapper(img):
    """Safe wrapper for noise function to handle bounds issues"""
    try:
        # Ensure image is in correct format
        if len(img.shape) == 3 and img.shape[2] == 3:
            return noise(img)
        else:
            st.warning("Image format not suitable for noise augmentation, skipping...")
            return img
    except IndexError as e:
        st.warning(f"Noise augmentation failed due to index error: {e}. Skipping noise.")
        return img
    except Exception as e:
        st.warning(f"Noise augmentation failed: {e}. Skipping noise.")
        return img

def apply_single_augmentation(image_array, aug_func):
    """Apply a single augmentation to the original image"""
    img_bgr = cv2.cvtColor(image_array, cv2.COLOR_RGB2BGR)
    
    try:
        # Special handling for noise function
        if hasattr(aug_func, '__name__') and aug_func.__name__ == 'noise':
            result = safe_noise_wrapper(img_bgr)
        else:
            result = aug_func(img_bgr)
        
        # Validate the result
        if result is not None and result.shape == img_bgr.shape:
            return cv2.cvtColor(result, cv2.COLOR_BGR2RGB)
        else:
            st.warning(f"Augmentation returned invalid result")
            return image_array
            
    except Exception as e:
        aug_name = getattr(aug_func, '__name__', 'Unknown')
        st.warning(f"Error applying {aug_name}: {str(e)}")
        return image_array

def apply_selected_augmentations(image_array, selected_augs):
    """Apply selected augmentations to the image with error handling"""
    img_bgr = cv2.cvtColor(image_array, cv2.COLOR_RGB2BGR)
    aug_img = img_bgr.copy()
    
    for i, aug in enumerate(selected_augs):
        try:
            # Special handling for noise function
            if hasattr(aug, '__name__') and aug.__name__ == 'noise':
                result = safe_noise_wrapper(aug_img)
            else:
                result = aug(aug_img)
            
            # Validate the result
            if result is not None and result.shape == aug_img.shape:
                aug_img = result
            else:
                st.warning(f"Augmentation {i+1} returned invalid result, skipping...")
                continue
                
        except Exception as e:
            aug_name = getattr(aug, '__name__', f'Augmentation {i+1}')
            st.warning(f"Error applying {aug_name}: {str(e)}. Skipping this augmentation.")
            continue
    
    return cv2.cvtColor(aug_img, cv2.COLOR_BGR2RGB)

# ===================================
# MAIN APPLICATION FLOW
# ===================================
def main():
    """Main application flow"""
    
    # File upload
    uploaded_file = st.file_uploader(
        "Upload file", 
        type=["pdf", "jpg", "jpeg", "png", "svg"]
    )
    
    if uploaded_file:
        file_type = uploaded_file.name.split('.')[-1].lower()
        
        col1, col2 = st.columns(2)
        with col1:
            st.write(f"**Filename:** {uploaded_file.name}")
            st.write(f"**Type:** {file_type.upper()}")
        
        # Convert to image
        if st.button("🔄 Convert to Image"):
            img_array = convert_to_png(uploaded_file, file_type)
            if img_array is not None:
                st.session_state.processed_image = img_array
                st.success("✅ Converted!")
            else:
                st.error("❌ Failed to convert.")
        
        # Display processed image
        if st.session_state.processed_image is not None:
            with col2:
                st.image(
                    st.session_state.processed_image, 
                    caption="Processed Document", 
                    use_column_width=True
                )
            
            # Extract text and key-value pairs
            if st.button("📝 Extract Text & Pairs"):
                with tempfile.NamedTemporaryFile(delete=False, suffix=f".{file_type}") as tmp_file:
                    tmp_file.write(uploaded_file.getvalue())
                    tmp_path = tmp_file.name
                
                text = extract_text_from_file(tmp_path, file_type)
                os.unlink(tmp_path)
                
                if text.strip():
                    st.text_area("Extracted Text", text, height=200)
                    kv_pairs = get_key_value_pairs(text)
                    st.session_state.kv_pairs = kv_pairs
                else:
                    st.warning("No text found.")
    
    # Select pairs and draw bounding boxes
    if st.session_state.kv_pairs:
        st.subheader("✅ Select Pairs to Process")
        
        options = ['All'] + [pair['id'] for pair in st.session_state.kv_pairs]
        
        selected_ids = st.multiselect(
            "Choose pairs to draw bounding boxes for:",
            options=options,
            format_func=lambda x: (
                "🔴 ALL" if x == 'All' else
                f"ID {x}: {next(p['key'] for p in st.session_state.kv_pairs if p['id'] == x)} → "
                f"{next(p['value'] for p in st.session_state.kv_pairs if p['id'] == x)}"
            )
        )
        
        # Handle "All" selection
        if 'All' in selected_ids:
            selected_ids = [pair['id'] for pair in st.session_state.kv_pairs]
        
        if selected_ids and st.button("📦 Draw Bounding Boxes"):
            selected_pairs = [pair for pair in st.session_state.kv_pairs if pair['id'] in selected_ids]
            st.session_state.selected_pairs = selected_pairs
            bbox_img = draw_bboxes_on_image(st.session_state.processed_image, selected_pairs)
            st.session_state.bbox_image = bbox_img
            st.image(bbox_img, caption="Bounding Boxes", use_column_width=True)
    
    # Replace text
    if st.session_state.selected_pairs:
        st.subheader("✏️ Replace Text")
        replacement_values = {}
        
        for pair in st.session_state.selected_pairs:
            if pair.get('bbox'):
                new_val = st.text_input(
                    f"New value for ID {pair['id']} ({pair['key']})", 
                    value=pair['value']
                )
                replacement_values[pair['id']] = new_val
        
        if st.button("🔄 Apply Replacements"):
            final_img = replace_bboxes(
                st.session_state.processed_image, 
                st.session_state.selected_pairs, 
                replacement_values
            )
            st.session_state.final_image = final_img
            st.image(final_img, caption="Final Image", use_column_width=True)
            
            # Download button
            buf = io.BytesIO()
            Image.fromarray(final_img).save(buf, format="PNG")
            st.download_button(
                "📥 Download", 
                data=buf.getvalue(), 
                file_name="final_image.png", 
                mime="image/png"
            )
    
    # Augmentation section
    if st.session_state.final_image is not None:
        st.subheader("Add Form Data Augmentation")
        st.markdown("Select which augmentations to apply:")
        
        # Categorized augmentations
        augmentation_categories = {
            "Basic Transforms": {
                "Rotate": rotate,
                "Blur": blur,
                "Contrast & Brighten": contrast_and_brighten,
                "Gamma Saturation": gamma_saturation,
                "Scanner-like": scanner_like,
                "Noise": noise,
            },
            "Visual Effects": {
                "Shadow": shadow,
                "Watermark": watermark,
                "Wrinkles": wrinkles,
                "LCD Overlay": lcd_overlay,
            },
            "Geometric Distortions": {
                "Distort": distort,
                "Perspective": perspective,
                "Stretch": stretch,
            }
        }
        
        # Add "All" checkbox
        apply_all = st.checkbox("🔴 Apply All Augmentations")
        
        selected_aug_funcs = []
        selected_aug_names = []
        
        if apply_all:
            # If "All" is selected, add all augmentation functions
            for category_augs in augmentation_categories.values():
                selected_aug_funcs.extend(category_augs.values())
                selected_aug_names.extend(category_augs.keys())
            
            # Display all augmentations as selected (disabled checkboxes)
            st.markdown("**All augmentations selected:**")
            for category_name, category_augs in augmentation_categories.items():
                st.markdown(f"**{category_name}:**")
                for aug_name in category_augs.keys():
                    st.checkbox(f"✅ {aug_name}", value=True, disabled=True, key=f"disabled_{aug_name}")
        else:
            # Individual selection by category
            for category_name, category_augs in augmentation_categories.items():
                st.markdown(f"**{category_name}:**")
                for aug_name, aug_func in category_augs.items():
                    if st.checkbox(f"✅ {aug_name}", key=f"select_{aug_name}"):
                        selected_aug_funcs.append(aug_func)
                        selected_aug_names.append(aug_name)
        
        if selected_aug_funcs and st.button("⚡ Apply Selected Augmentations"):
            with st.spinner("Applying selected augmentations..."):
                if apply_all:
                    # Show each augmentation applied to original image in pairs
                    st.markdown("### 📸 Original Image → Augmented Images")
                    
                    # Store all augmented images
                    st.session_state.augmented_images_dict = {}
                    
                    # Flatten all augmentations into a single list
                    all_augmentations = []
                    for category_augs in augmentation_categories.values():
                        all_augmentations.extend(category_augs.items())
                    
                    # Display images in pairs (2 columns per row)
                    for i in range(0, len(all_augmentations), 2):
                        cols = st.columns(2)
                        
                        # First augmentation in the pair
                        aug_name1, aug_func1 = all_augmentations[i]
                        try:
                            aug_img1 = apply_single_augmentation(st.session_state.final_image, aug_func1)
                            st.session_state.augmented_images_dict[aug_name1] = aug_img1
                            
                            with cols[0]:
                                st.markdown(f"**{aug_name1} Image**")
                                st.image(aug_img1, use_column_width=True)
                                
                                # Download button
                                buf = io.BytesIO()
                                Image.fromarray(aug_img1).save(buf, format="PNG")
                                st.download_button(
                                    f"📥 Download {aug_name1}",
                                    data=buf.getvalue(),
                                    file_name=f"{aug_name1.lower().replace(' ', '_')}_augmented.png",
                                    mime="image/png",
                                    key=f"download_{aug_name1}"
                                )
                        except Exception as e:
                            with cols[0]:
                                st.error(f"❌ Error applying {aug_name1}: {str(e)}")
                        
                        # Second augmentation in the pair (if exists)
                        if i + 1 < len(all_augmentations):
                            aug_name2, aug_func2 = all_augmentations[i + 1]
                            try:
                                aug_img2 = apply_single_augmentation(st.session_state.final_image, aug_func2)
                                st.session_state.augmented_images_dict[aug_name2] = aug_img2
                                
                                with cols[1]:
                                    st.markdown(f"**Original Image → {aug_name2}**")
                                    st.image(aug_img2, use_column_width=True)
                                    
                                    # Download button
                                    buf = io.BytesIO()
                                    Image.fromarray(aug_img2).save(buf, format="PNG")
                                    st.download_button(
                                        f"📥 Download {aug_name2}",
                                        data=buf.getvalue(),
                                        file_name=f"{aug_name2.lower().replace(' ', '_')}_augmented.png",
                                        mime="image/png",
                                        key=f"download_{aug_name2}"
                                    )
                            except Exception as e:
                                with cols[1]:
                                    st.error(f"❌ Error applying {aug_name2}: {str(e)}")
                        
                        # Add some spacing between rows
                        st.markdown("---")
                    
                    # Add a download all button
                    st.markdown("### 📦 Download All Augmented Images")
                    if st.button("📥 Download All as ZIP"):
                        import zipfile
                        zip_buffer = io.BytesIO()
                        
                        with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
                            for aug_name, aug_img in st.session_state.augmented_images_dict.items():
                                img_buffer = io.BytesIO()
                                Image.fromarray(aug_img).save(img_buffer, format="PNG")
                                zip_file.writestr(
                                    f"{aug_name.lower().replace(' ', '_')}_augmented.png",
                                    img_buffer.getvalue()
                                )
                        
                        st.download_button(
                            "📥 Download ZIP",
                            data=zip_buffer.getvalue(),
                            file_name="all_augmented_images.zip",
                            mime="application/zip"
                        )
                    
                else:
                    # Regular processing for individual selections
                    aug_img = apply_selected_augmentations(
                        st.session_state.final_image, 
                        selected_aug_funcs
                    )
                    st.session_state.augmented_image = aug_img
                    st.image(aug_img, caption="Augmented Image", use_column_width=True)
                    
                    # Download augmented image
                    buf = io.BytesIO()
                    Image.fromarray(aug_img).save(buf, format="PNG")
                    st.download_button(
                        "📥 Download Augmented Image",
                        data=buf.getvalue(),
                        file_name="augmented_image.png",
                        mime="image/png"
                    )

# ===================================
# SIDEBAR INSTRUCTIONS
# ===================================
def add_sidebar_instructions():
    """Add usage instructions to sidebar"""
    st.sidebar.markdown("---")
    st.sidebar.subheader("How to use:")
    st.sidebar.markdown("""
    1. Upload a PDF, Image, or SVG.
    2. Click **Convert to Image**.
    3. Extract text & key-value pairs.
    4. Select pairs, draw boxes.
    5. Edit & replace text.
    6. Download final image.
    7. (Optional) Apply augmentations.
    """)
    
    st.sidebar.markdown("---")
    st.sidebar.subheader("Augmentation Features:")
    st.sidebar.markdown("""
    - **Individual Selection**: Choose specific augmentations
    - **Apply All**: Shows each augmentation applied to original image
    - **Categories**: Organized by transform type
    - **Download Options**: Individual or ZIP download
    """)

# ===================================
# RUN APPLICATION
# ===================================
if __name__ == "__main__":
    main()
    add_sidebar_instructions()