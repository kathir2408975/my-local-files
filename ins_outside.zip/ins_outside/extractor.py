import os
from pdfminer.high_level import extract_text
from PIL import Image
import pytesseract
from pdf2image import convert_from_path
import cairosvg

from config import TESSERACT_PATH, POPPLER_PATH

pytesseract.pytesseract.tesseract_cmd = TESSERACT_PATH

def extract_text_from_file(file_path):
    ext = os.path.splitext(file_path)[1].lower()
    text = ""

    if ext == ".pdf":
        text = extract_text(file_path)
        if not text.strip():
            print("No text found with pdfminer. Using OCR fallback...")
            images = convert_from_path(file_path, poppler_path=POPPLER_PATH)
            for img in images:
                text += pytesseract.image_to_string(img)
    elif ext in [".jpg", ".jpeg", ".png"]:
        img = Image.open(file_path)
        text = pytesseract.image_to_string(img)
    elif ext == ".svg":
        png_path = file_path + ".png"
        cairosvg.svg2png(url=file_path, write_to=png_path)
        img = Image.open(png_path)
        text = pytesseract.image_to_string(img)
        os.remove(png_path)
    else:
        raise ValueError("Unsupported file type!")

    return text


def convert_to_png(file_path, output_path="input.png"):
    ext = os.path.splitext(file_path)[1].lower()

    if ext == ".pdf":
        pages = convert_from_path(file_path, poppler_path=POPPLER_PATH)
        if pages:
            pages[0].save(output_path)
            print(f"✅ Saved first PDF page to {output_path}")
    elif ext in [".jpg", ".jpeg", ".png"]:
        img = Image.open(file_path)
        img.save(output_path)
        print(f"✅ Saved image as {output_path}")
    elif ext == ".svg":
        cairosvg.svg2png(url=file_path, write_to=output_path)
        print(f"✅ Converted SVG to {output_path}")
    else:
        raise ValueError(f"Unsupported file type for image conversion: {ext}")

    return output_path