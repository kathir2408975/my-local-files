import google.generativeai as genai
import json
import os
from config import GEMINI_API_KEY

genai.configure(api_key=GEMINI_API_KEY)

def get_key_value_pairs(text):
    prompt = (
        "Extract all key-value pairs clearly from this insurance text. "
        "Format the output as a JSON array with keys: 'key' and 'value'.\n\n"
        f"{text}"
    )

    model = genai.GenerativeModel("gemini-1.5-flash-latest")
    response = model.generate_content(prompt)
    raw_output = response.text.strip()

    print("\n--- Raw Gemini Output ---")
    print(raw_output)

    os.makedirs("output", exist_ok=True)

    # Save raw output first
    with open("output/raw_output.json", "w", encoding="utf-8") as f:
        f.write(raw_output)

    # Clean raw output: remove ```json and ```
    cleaned_output = raw_output
    if cleaned_output.startswith("```json"):
        cleaned_output = cleaned_output[len("```json"):].strip()
    if cleaned_output.endswith("```"):
        cleaned_output = cleaned_output[:-3].strip()

    # Save cleaned output back
    with open("output/raw_output.json", "w", encoding="utf-8") as f:
        f.write(cleaned_output)

    # Load cleaned output
    try:
        data = json.loads(cleaned_output)
    except Exception as e:
        print(f"Failed to parse cleaned LLM output: {e}")
        return []

    # Add numbering
    for idx, pair in enumerate(data, 1):
        pair["id"] = idx

    # Save numbered pairs
    with open("output/kv_pairs.json", "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

    print("\nSaved numbered pairs to: output/kv_pairs.json")
    print(json.dumps(data, indent=2, ensure_ascii=False))

    return data
