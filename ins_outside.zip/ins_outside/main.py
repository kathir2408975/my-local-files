import os
import json
from extractor import extract_text_from_file, convert_to_png
from llm_client import get_key_value_pairs
from bbox_utils import draw_value_bbox_near_key
from replacer import replace_bboxes

def get_selected_pairs():
    kv_json = "output/kv_pairs.json"
    if not os.path.exists(kv_json):
        print(f"❌ kv_pairs.json not found: {kv_json}")
        return []

    with open(kv_json, "r", encoding="utf-8") as f:
        kv_pairs = json.load(f)

    if not kv_pairs:
        print("❌ kv_pairs.json is empty!")
        return []

    print("\nAvailable pairs:")
    for pair in kv_pairs:
        print(f"ID {pair['id']}: {pair['key']} => {pair['value']}")

    selection = input("\nEnter numbers of the pairs you want to draw bbox for (comma separated):\n> ").strip()
    try:
        ids = [int(x.strip()) for x in selection.split(",") if x.strip()]
    except ValueError:
        print("❌ Invalid input! Use only numbers separated by commas.")
        return []

    selected_results = []
    for selection_id in ids:
        result = next((item for item in kv_pairs if item["id"] == selection_id), None)
        if result:
            print(f"✅ Found for ID {selection_id}: {result}")
            selected_results.append(result)
        else:
            print(f"⚠️ No data found with ID {selection_id}")

    return selected_results


def main():
    input_folder = "./input"
    files = os.listdir(input_folder)
    if not files:
        print("❌ No files found in input folder.")
        return

    print("\nAvailable files:")
    for idx, fname in enumerate(files, 1):
        print(f"{idx}. {fname}")

    choice = input("\nEnter file number to process: ").strip()
    try:
        idx = int(choice) - 1
        file_name = files[idx]
    except (ValueError, IndexError):
        print("❌ Invalid selection.")
        return

    file_path = os.path.join(input_folder, file_name)

    png_path = convert_to_png(file_path, output_path="input/input.png")

    if not os.path.exists(png_path):
        print(f"❌ Converted PNG not found: {png_path}")
        return

    text = extract_text_from_file(file_path)
    kv_pairs = get_key_value_pairs(text)
    if not kv_pairs:
        print("❌ No key-value pairs found. Exiting.")
        return

    os.makedirs("output", exist_ok=True)

    with open("output/kv_pairs.json", "w", encoding="utf-8") as f:
        json.dump(kv_pairs, f, indent=2)

    selected_pairs = get_selected_pairs()
    if not selected_pairs:
        print("❌ No valid pairs selected. Exiting.")
        return

    draw_value_bbox_near_key("input/input.png", selected_pairs)

    with open("output/selected_pairs_with_bbox.json", "w", encoding="utf-8") as f:
        json.dump(selected_pairs, f, indent=2)

    with open("output/selected_pairs_with_bbox.json", "r") as f:
        pairs_with_bboxes = json.load(f)

    replace_bboxes("input/input.png", pairs_with_bboxes)


if __name__ == "__main__":
    main()


# ######

