# Tesseract path
TESSERACT_PATH = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

# Poppler path for pdf2image
POPPLER_PATH = r"C:\Users\KTHRMFST\Downloads\Release-24.07.0-0\poppler-24.07.0\Library\bin"

# Input & Output folders
INPUT_FOLDER = r"./input"
OUTPUT_FOLDER = r"./output"

# Gemini / OpenAI API keys (if using later)
GEMINI_API_KEY = "AIzaSyAjp9fxh8rz68VPxNoLO9EXkw9_XKJ4RoA"
