# import cv2
# import numpy as np
# from PIL import Image, ImageDraw, ImageFont

# def replace_bboxes(image_path, pairs_with_bboxes):
#     # Load original color image
#     img = cv2.imread(image_path)
#     if img is None:
#         print(f"❌ Could not load image: {image_path}")
#         return

#     # Create mask for inpainting
#     mask = np.zeros(img.shape[:2], dtype=np.uint8)

#     for pair in pairs_with_bboxes:
#         bbox = pair.get("bbox")
#         if not bbox:
#             print(f"⚠️ Skipping ID {pair['id']} — no bbox.")
#             continue
#         x1, y1, x2, y2 = bbox
#         mask[y1:y2, x1:x2] = 255

#     # Inpaint to remove text
#     img_inpainted = cv2.inpaint(img, mask, 3, cv2.INPAINT_TELEA)

#     # Use PIL for text drawing
#     img_pil = Image.fromarray(cv2.cvtColor(img_inpainted, cv2.COLOR_BGR2RGB))
#     draw = ImageDraw.Draw(img_pil)

#     for pair in pairs_with_bboxes:
#         bbox = pair.get("bbox")
#         if not bbox:
#             continue

#         x1, y1, x2, y2 = bbox
#         print(f"\nOriginal: {pair['value']}")
#         new_text = input(f"New value for ID {pair['id']} ({pair['key']}): ").strip()
#         if not new_text:
#             new_text = pair['value']

#         pair["new_value"] = new_text

#         # Path to .ttf font
#         font_path = "arial.ttf"  # ⚠️ Put your font here

#         # Find best font size
#         font_size = 20
#         while True:
#             font = ImageFont.truetype(font_path, font_size)
#             bbox_text = draw.textbbox((0,0), new_text, font=font)
#             text_w = bbox_text[2] - bbox_text[0]
#             text_h = bbox_text[3] - bbox_text[1]
#             if text_w < (x2 - x1 - 2) and text_h < (y2 - y1 - 2):
#                 font_size += 1
#             else:
#                 font_size -= 1
#                 break

#         final_font = ImageFont.truetype(font_path, font_size)
#         bbox_text = draw.textbbox((0,0), new_text, font=final_font)
#         text_w = bbox_text[2] - bbox_text[0]
#         text_h = bbox_text[3] - bbox_text[1]
#         text_x = x1 + ((x2 - x1 - text_w) // 2)
#         text_y = y1 + ((y2 - y1 - text_h) // 2)

#         draw.text((text_x, text_y), new_text, font=final_font, fill=(0, 0, 0))

#     # Back to OpenCV + save
#     final_img = cv2.cvtColor(np.array(img_pil), cv2.COLOR_RGB2BGR)
#     cv2.imwrite("output/final_replaced_image.png", final_img)
#     print(f"✅ Saved final image: output/final_replaced_image.png")
#     return pairs_with_bboxes



import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

def replace_bboxes(image_path, pairs_with_bboxes):
    img = cv2.imread(image_path)
    if img is None:
        print(f"❌ Could not load image: {image_path}")
        return None

    mask = np.zeros(img.shape[:2], dtype=np.uint8)

    for pair in pairs_with_bboxes:
        bbox = pair.get("bbox")
        if not bbox:
            continue
        x1, y1, x2, y2 = bbox
        mask[y1:y2, x1:x2] = 255

    img_inpainted = cv2.inpaint(img, mask, 3, cv2.INPAINT_TELEA)

    img_pil = Image.fromarray(cv2.cvtColor(img_inpainted, cv2.COLOR_BGR2RGB))
    draw = ImageDraw.Draw(img_pil)

    for pair in pairs_with_bboxes:
        bbox = pair.get("bbox")
        if not bbox:
            continue

        x1, y1, x2, y2 = bbox
        new_text = pair.get("value", pair.get("new_value", ""))

        font_path = "arial.ttf"  # ✅ Your font here!
        font_size = 20
        while True:
            font = ImageFont.truetype(font_path, font_size)
            bbox_text = draw.textbbox((0, 0), new_text, font=font)
            text_w = bbox_text[2] - bbox_text[0]
            text_h = bbox_text[3] - bbox_text[1]
            if text_w < (x2 - x1 - 2) and text_h < (y2 - y1 - 2):
                font_size += 1
            else:
                font_size -= 1
                break

        final_font = ImageFont.truetype(font_path, font_size)
        bbox_text = draw.textbbox((0, 0), new_text, font=final_font)
        text_w = bbox_text[2] - bbox_text[0]
        text_h = bbox_text[3] - bbox_text[1]
        text_x = x1 + ((x2 - x1 - text_w) // 2)
        text_y = y1 + ((y2 - y1 - text_h) // 2)

        draw.text((text_x, text_y), new_text, font=final_font, fill=(0, 0, 0))

    final_img = cv2.cvtColor(np.array(img_pil), cv2.COLOR_RGB2BGR)
    cv2.imwrite("output/final_replaced_image.png", final_img)

    return final_img
