import os
import json
import sys
from pathlib import Path
from datetime import datetime
from dotenv import load_dotenv

# Add the src directory to sys.path for absolute imports
sys.path.insert(0, str(Path(__file__).parent.parent))
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

# ------------------------------------------------------------
# Load Galileo environment variables
# ------------------------------------------------------------
load_dotenv(Path(__file__).parent / "galileo_keys.env")

# ------------------------------------------------------------
# Galileo Logging (LANGCHAIN CALLBACK INTEGRATION)
# ------------------------------------------------------------
from galileo.handlers.langchain import GalileoCallback
from galileo import galileo_context
from galileo.schema.metrics import GalileoScorers
from galileo.log_streams import enable_metrics

# Initialize Galileo context
galileo_context.init(
    project=os.environ["GALILEO_PROJECT"],
    log_stream=os.environ["GALILEO_LOG_STREAM"]
)

# ------------------------------------------------------------
# Enable Galileo metrics globally so traces are evaluated
# (evaluations are computed when traces are concluded/flushed)
# Choose whichever scorers you need; `context_adherence` is common.
enable_metrics(metrics=["Correctness - Copy"])

# Create a callback instance for LangChain/LangGraph
galileo_callback = GalileoCallback()

# ------------------------------------------------------------
# Application imports (UNCHANGED)
# ------------------------------------------------------------
from common_layers.llm_layer.llm_manager import LLMManager
from healthcare.workflows.healthcare_workflow import create_health_graph
from common_utilities.logger import log_trace

print("🚀 === HEALTHCARE CLAIMS PROCESSING SYSTEM STARTED ===")
print(f"⏰ Start Time: {datetime.now().isoformat()}")
print("🔧 Galileo Observe tracing enabled")


# ============================================================
# Healthcare Executor (with Galileo LangChain Callback)
# ============================================================
def run_healthcare_executor(claim_input: dict):
    """
    Execute healthcare workflow with Galileo tracing via LangChain callback.
    The callback automatically traces all LangChain/LangGraph operations.
    """
    
    try:
        # -----------------------------
        # Phase 0: Input Analysis
        # -----------------------------
        input_summary = {
            "identifier": claim_input.get("identifier"),
            "policy_id": claim_input["policy_id"],
            "domain": claim_input["domain"],
            "claim_amount": claim_input["claim_record"]["claim_amount"],
            "notes_count": len(claim_input["claim_record"]["notes"]),
            "policy_start": claim_input["claim_record"]["policy_start"],
            "policy_end": claim_input["claim_record"]["policy_end"],
            "accident_date": claim_input["claim_record"]["accident_date"],
        }

        log_trace(
            claim_id=claim_input["policy_id"],
            step="healthcare_executor_start",
            output=input_summary,
        )

        # -----------------------------
        # Phase 1: Workflow Creation
        # -----------------------------
        workflow = create_health_graph(claim_input)

        log_trace(
            claim_id=claim_input["policy_id"],
            step="healthcare_executor_workflow_creation",
            output={"workflow_created": True},
        )

        # -----------------------------
        # Phase 2: Workflow Invoke with Galileo Callback
        # -----------------------------
        # CRITICAL: Pass the Galileo callback to the workflow
        # This will automatically trace all LangChain/LangGraph operations
        from langchain_core.runnables import RunnableConfig
        
        config = RunnableConfig(
            callbacks=[galileo_callback],
            tags=[
                claim_input.get("identifier", "unknown"),
                claim_input["policy_id"],
                "healthcare_workflow"
            ]
        )
        
        result = workflow.invoke(claim_input, config=config)
        actual_path = result.get("__path__", [])

        log_trace(
            claim_id=claim_input["policy_id"],
            step="healthcare_executor_workflow_invoke",
            output={"actual_path": actual_path},
        )

        # -----------------------------
        # Phase 3: Result Processing
        # -----------------------------
        decision = result.get("decision", "N/A")
        reason = result.get("reason", "Document Verification Flow Incomplete")
        summary = result.get("summary", "Summary not available.")
        policy_id = result.get("policy_id", "unknown")

        log_trace(
            claim_id=policy_id,
            step="healthcare_executor_workflow_result",
            output={"decision": decision},
        )

        # -----------------------------
        # Phase 4: Completion
        # -----------------------------
        completion = {
            "executor_completed": True,
            "final_decision": decision,
            "policy_id": policy_id,
            "end_time": datetime.now().isoformat(),
            "processing_successful": True,
        }

        log_trace(
            claim_id=policy_id,
            step="healthcare_executor_complete",
            output=completion,
        )

        return {
            "final_decision": decision,
            "policy_id": policy_id,
            "summary": summary,
            "reason": reason,
            "raw_result": result,
        }

    except Exception as e:
        print(f"❌ Error in healthcare executor: {str(e)}")
        raise
    finally:
        # CRITICAL: Flush traces to Galileo
        galileo_context.flush()
        print("✅ Traces flushed to Galileo")


# ============================================================
# Main Execution (ALL SCENARIOS PRESERVED)
# ============================================================
if __name__ == "__main__":

    output_dir = Path("output")
    output_dir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------
    # Claim Rejected / Not Approved (WITH NOTES)
    # ------------------------------------------------------------
    claim_input_not_approved_with_notes = {
        "identifier": "TD_001",
        "policy_id": "HLT-2002",
        "domain": "Health Insurance (Major Medical Plan)",
        "claim_record": {
            "name": "Valid Medical",
            "policy_id": "HLT-2002",
            "policy_start": "2025-01-01",
            "policy_end": "2025-12-31",
            "claim_type": "Health Insurance (Major Medical Plan)",
            "accident_date": "2025-05-15",
            "claim_amount": 12000,
            "notes": [
                "document_verification_agent - submitted_documents_completeness: All required documents have likely been provided.",
                "document_verification_agent - authenticity_check: Submitted documents are invalid and likely fraudulent.",
                "document_verification_agent - duplicate_document_check: Fraudulent bills detected.",
                "document_verification_agent - provider_details_verification: Provider verified.",
                "document_verification_agent - service_date_verification: Dates align with claim.",
            ],
        },
    }

    # ------------------------------------------------------------
    # Claim Rejected / Not Approved (NO NOTES)
    # ------------------------------------------------------------
    claim_input_not_approved = {
        "identifier": "TD_002",
        "policy_id": "HLT-4009",
        "domain": "Major Medical Health Plan",
        "claim_record": {
            "name": "Springfield Medical Center",
            "policy_id": "HLT-4009",
            "policy_start": "2025-01-01",
            "policy_end": "2025-12-31",
            "claim_type": "Health Insurance",
            "accident_date": "2025-05-15",
            "claim_amount": 6700,
            "notes": [],
        },
    }

    # ------------------------------------------------------------
    # Claim Requires Human Review
    # ------------------------------------------------------------
    claim_input_human_review = {
        "identifier": "TD_003",
        "policy_id": "HLT-2002",
        "domain": "Health Insurance (Major Medical Plan)",
        "claim_record": {
            "name": "Valid Medical",
            "policy_id": "HLT-2002",
            "policy_start": "2025-01-01",
            "policy_end": "2025-12-31",
            "claim_type": "Health Insurance (Major Medical Plan)",
            "accident_date": "2025-05-15",
            "claim_amount": 12000,
            "notes": [
                "authenticity_check – anomalies detected",
                "duplicate_document_check – possible duplicates",
                "provider_details_verification – verified",
                "service_date_verification – within coverage",
            ],
        },
    }

    # ------------------------------------------------------------
    # Claim Approved
    # ------------------------------------------------------------
    claim_input_approved = {
        "identifier": "TD_004",
        "policy_id": "HLT-3005",
        "domain": "Major Medical Health Plan",
        "claim_record": {
            "name": "Springfield Medical Center",
            "policy_id": "HLT-3005",
            "policy_start": "2025-01-01",
            "policy_end": "2025-12-31",
            "claim_type": "Health Insurance",
            "accident_date": "2025-05-15",
            "claim_amount": 6700,
            "notes": [
                "claim_amount_verification passed",
                "policy_status_verification passed",
                "billing_validation passed",
                "documentation_authenticity_verification passed",
            ],
        },
    }

    # ------------------------------------------------------------
    # SELECT SCENARIO TO RUN
    # ------------------------------------------------------------
    claim_input = claim_input_not_approved

    print("\n📋 === CLAIM INPUT ANALYSIS ===")
    print(f"🆔 Policy ID: {claim_input['policy_id']}")
    print(f"🏥 Domain: {claim_input['domain']}")
    print(f"💰 Claim Amount: ${claim_input['claim_record']['claim_amount']:,}")
    print(f"📝 Notes Count: {len(claim_input['claim_record']['notes'])}")

    result_bundle = run_healthcare_executor(claim_input)

    print("\n✅ Executor result:")
    print(json.dumps(result_bundle, indent=2))
    
    # Final flush to ensure all traces are uploaded
    print("\n🔄 Final flush to Galileo...")
    galileo_context.flush()
    print("✅ All traces uploaded to Galileo successfully!")