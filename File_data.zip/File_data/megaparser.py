# import os
# from PyPDF2 import PdfReader, PdfWriter
# from megaparse import MegaParse

# input_pdf_path = "Program Appraisal Document.pdf"

# # Temporary folder for single-page PDFs
# pagewise_pdf_folder = "temp_pagewise_pdfs"
# os.makedirs(pagewise_pdf_folder, exist_ok=True)

# # Output single text file for all pages
# output_text_file = "all_pages_extracted.txt"

# reader = PdfReader(input_pdf_path)
# num_pages = len(reader.pages)

# all_pages_text = []

# for i in range(num_pages):
#     writer = PdfWriter()
#     writer.add_page(reader.pages[i])

#     # Save single-page PDF temporarily
#     single_page_pdf_path = os.path.join(pagewise_pdf_folder, f"page_{i+1}.pdf")
#     with open(single_page_pdf_path, "wb") as f:
#         writer.write(f)

#     # Parse with MegaParse
#     megaparse = MegaParse(single_page_pdf_path)
#     response = megaparse.load()

#     # Collect with page header
#     all_pages_text.append(f"\n--- Page {i+1} ---\n{response}\n")

# # Write all pages to one text file
# with open(output_text_file, "w", encoding="utf-8") as f:
#     f.writelines(all_pages_text)

# print(f"✅ All page-wise extracted data saved in {output_text_file}")


# from megaparse import MegaParse

# file_path = "tableData_Program Appraisal Document.pdf"  # Use forward slashes or raw string
# megaparse = MegaParse(file_path)
# response = megaparse.load()
# print(response)


# from megaparse import MegaParse

# file_path = "Program Appraisal Document.pdf"  # Use forward slashes or raw string
# megaparse = MegaParse(file_path)
# response = megaparse.load()

# # Save to a text file
# output_file = "Program Appraisal Document_parsed_output.txt"
# with open(output_file, "w", encoding="utf-8") as f:
#     f.write(str(response))




# import fitz  # PyMuPDF
# import csv

# doc = fitz.open("tableData_Program_Appraisal_Document_1.pdf")

# # Create/open a CSV file to write the data
# with open('fitz_extracted_tables.csv', 'w', newline='', encoding='utf-8') as csvfile:
#     csvwriter = csv.writer(csvfile)
    
#     # Write a header row to separate tables
#     csvwriter.writerow(['--- New Table ---'])
    
#     for page_num, page in enumerate(doc):
#         table_finder = page.find_tables()
#         tables = table_finder.tables
#         print(f"Found {len(tables)} table(s) on page {page_num + 1}")
        
#         for table_num, table in enumerate(tables):
#             print(f"Processing table {table_num + 1}")
#             data = table.extract()
            
#             # Write a separator with page and table information
#             csvwriter.writerow([f'Page {page_num + 1}, Table {table_num + 1}'])
            
#             # Write the table data
#             for row in data:
#                 csvwriter.writerow(row)
            
#             # Add a blank row between tables
#             csvwriter.writerow([])

# print("✅ Tables have been extracted and saved to 'extracted_tables.csv'")





# # Simple one-liner usage:
# # extract_tables_to_csv('your_file.pdf')

# ###### tesseract code


# # # Import necessary libraries
# # import os
# # import PyPDF2
# # from pdfminer.high_level import extract_pages, extract_text
# # from pdfminer.layout import LTTextContainer, LTFigure, LTRect, LTChar
# # import pdfplumber
# # from pdf2image import convert_from_path
# # from PIL import Image
# # import pytesseract

# # # Set up Tesseract executable path for Windows
# # pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

# # # Define function to extract text from PDF elements
# # def text_extraction(element):
# #     line_text = element.get_text()
# #     line_formats = []
# #     for text_line in element:
# #         if isinstance(text_line, LTTextContainer):
# #             for character in text_line:
# #                 if isinstance(character, LTChar):
# #                     line_formats.append(character.fontname)
# #                     line_formats.append(character.size)
# #     format_per_line = list(set(line_formats))
# #     return (line_text, format_per_line)

# # # Define function to crop image from PDF
# # def crop_image(element, pageObj):
# #     image_left, image_top, image_right, image_bottom = element.x0, element.y0, element.x1, element.y1
# #     pageObj.mediabox.lower_left = (image_left, image_bottom)
# #     pageObj.mediabox.upper_right = (image_right, image_top)
# #     cropped_pdf_writer = PyPDF2.PdfWriter()
# #     cropped_pdf_writer.add_page(pageObj)
# #     with open('cropped_image.pdf', 'wb') as cropped_pdf_file:
# #         cropped_pdf_writer.write(cropped_pdf_file)

# # # Define function to convert PDF to images
# # def convert_to_images(input_file):
# #     images = convert_from_path(input_file)
# #     image = images[0]
# #     output_file = "PDF_image.png"
# #     image.save(output_file, "PNG")

# # # Define function to extract text from images using OCR
# # def image_to_text(image_path):
# #     img = Image.open(image_path)
# #     text = pytesseract.image_to_string(img)
# #     return text

# # # Define function to extract table from PDF
# # def extract_table(pdf_path, page_num, table_num):
# #     with pdfplumber.open(pdf_path) as pdf:
# #         table_page = pdf.pages[page_num]
# #         table = table_page.extract_tables()[table_num]
# #         return table

# # # Define function to convert table to string
# # def table_converter(table):
# #     table_string = ''
# #     for row_num in range(len(table)):
# #         row = table[row_num]
# #         cleaned_row = [item.replace('\n', ' ') if item is not None and '\n' in item else 'None' if item is None else item for item in row]
# #         table_string += ('|' + '|'.join(cleaned_row) + '|' + '\n')
# #     table_string = table_string[:-1]
# #     return table_string

# # # Main code to extract text and tables from PDF
# # pdf_path = 'tableData_Program_Appraisal_Document_1.pdf'  # Replace with your PDF path

# # # Create a PDF file object
# # pdfFileObj = open(pdf_path, 'rb')
# # pdfReader = PyPDF2.PdfReader(pdfFileObj)

# # text_per_page = {}

# # for pagenum, page in enumerate(extract_pages(pdf_path)):
# #     pageObj = pdfReader.pages[pagenum]
# #     page_text = []
# #     line_format = []
# #     text_from_images = []
# #     text_from_tables = []
# #     page_content = []
# #     table_num = 0
# #     first_element = True
# #     table_extraction_flag = False

# #     with pdfplumber.open(pdf_path) as pdf:
# #         page_tables = pdf.pages[pagenum]
# #         tables = page_tables.find_tables()

# #     page_elements = [(element.y1, element) for element in page._objs]
# #     page_elements.sort(key=lambda a: a[0], reverse=True)

# #     for i, component in enumerate(page_elements):
# #         pos, element = component[0], component[1]

# #         if isinstance(element, LTTextContainer):
# #             if not table_extraction_flag:
# #                 (line_text, format_per_line) = text_extraction(element)
# #                 page_text.append(line_text)
# #                 line_format.append(format_per_line)
# #                 page_content.append(line_text)
# #             else:
# #                 pass

# #         if isinstance(element, LTFigure):
# #             crop_image(element, pageObj)
# #             convert_to_images('cropped_image.pdf')
# #             image_text = image_to_text('PDF_image.png')
# #             text_from_images.append(image_text)
# #             page_content.append(image_text)
# #             page_text.append('image')
# #             line_format.append('image')

# #         if isinstance(element, LTRect):
# #             if first_element and (table_num + 1) <= len(tables):
# #                 lower_side = page.bbox[3] - tables[table_num].bbox[3]
# #                 upper_side = element.y1
# #                 table = extract_table(pdf_path, pagenum, table_num)
# #                 table_string = table_converter(table)
# #                 text_from_tables.append(table_string)
# #                 page_content.append(table_string)
# #                 table_extraction_flag = True
# #                 first_element = False
# #                 page_text.append('table')
# #                 line_format.append('table')

# #             if element.y0 >= lower_side and element.y1 <= upper_side:
# #                 pass
# #             elif not isinstance(page_elements[i + 1][1], LTRect):
# #                 table_extraction_flag = False
# #                 first_element = True
# #                 table_num += 1

# #     dctkey = 'Page_' + str(pagenum)
# #     text_per_page[dctkey] = [page_text, line_format, text_from_images, text_from_tables, page_content]

# # # Close the PDF file object
# # pdfFileObj.close()

# # # Delete additional files created during the process
# # if os.path.exists('cropped_image.pdf'):
# #     os.remove('cropped_image.pdf')
# # if os.path.exists('PDF_image.png'):
# #     os.remove('PDF_image.png')

# # # Save all data to a single text file
# # output_file = 'extracted_data_next.txt'
# # with open(output_file, 'w', encoding='utf-8') as f:
# #     for pagenum in range(len(text_per_page)):
# #         page_key = f'Page_{pagenum}'
# #         if page_key in text_per_page:
# #             page_data = text_per_page[page_key]
# #             f.write(f'=== Page {pagenum} ===\n')
            
# #             # Write text from text containers
# #             f.write('Text from Text Containers:\n')
# #             for text in page_data[0]:
# #                 f.write(text + '\n')
# #             f.write('\n')
            
# #             # Write text formats
# #             f.write('Text Formats:\n')
# #             for fmt in page_data[1]:
# #                 f.write(str(fmt) + '\n')
# #             f.write('\n')
            
# #             # Write text from images
# #             f.write('Text from Images:\n')
# #             for img_text in page_data[2]:
# #                 f.write(img_text + '\n')
# #             f.write('\n')
            
# #             # Write text from tables
# #             f.write('Text from Tables:\n')
# #             for table_text in page_data[3]:
# #                 f.write(table_text + '\n')
# #             f.write('\n')
            
# #             # Write complete page content
# #             f.write('Complete Page Content:\n')
# #             f.write(''.join(page_data[4]) + '\n\n')

# # print(f'All data has been saved to {output_file}')