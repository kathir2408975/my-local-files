from docling.document_converter import DocumentConverter

source = "tableData_Program_Appraisal_Document_1.pdf"

converter = DocumentConverter()
result = converter.convert(source)
final = result.document.export_to_dict()
# tables = result.document.tables
# # Print tables list (will show TableItem references)
# print(tables)

# # Loop over each table
for idx, table in enumerate(result.document.tables):
    print(f"\n📄 Table {idx + 1}")
    
    # Each table has a list of ProvenanceItem(s), each with a page_no and bbox
    for prov in table.prov:
        print(f"Page No: {prov.page_no}")
        bbox = prov.bbox
        print(f"BBox: left={bbox.l}, top={bbox.t}, right={bbox.r}, bottom={bbox.b}")
        





# with open("docling_output_full_file.txt", "w", encoding='utf-8') as f:
#     f.write("# Docling Output\n\n")
#     f.write(result.document.export_to_markdown())






# from extract_thinker.document_loader.document_loader_pdfplumber import DocumentLoaderPdfPlumber

# pdf_path = "tableData_Program_Appraisal_Document_1.pdf"
# loader = DocumentLoaderPdfPlumber()
# pages = loader.load(pdf_path)

# # Check keys in first page dictionary
# print(pages[0].keys())

# # Then print the actual text content
# for page in pages:
#     print(page.get("text") or page.get("content") or page)


# import logging
# import time
# from pathlib import Path
# import pandas as pd
# import json
# from docling.document_converter import DocumentConverter

# # Set up logging
# _log = logging.getLogger(__name__)

# def main():
#     logging.basicConfig(level=logging.INFO)

#     input_doc_path = Path("tableData_Program_Appraisal_Document_1.pdf")  # PDF file
#     output_dir = Path("scratch")  # Output folder
#     output_dir.mkdir(parents=True, exist_ok=True)

#     doc_converter = DocumentConverter()
#     start_time = time.time()

#     # Convert document
#     conv_res = doc_converter.convert(input_doc_path)
#     doc_filename = conv_res.input.file.stem

#     # Store DataFrames in a list
#     all_tables_df = []

#     for table_ix, table in enumerate(conv_res.document.tables):
#         df = table.export_to_dataframe()
#         bbox = getattr(table, "bbox", None)

#         print(f"## Table {table_ix + 1}")
#         print(f"Bounding Box: {bbox}")
#         print(df)

#         # Append to list as a dictionary
#         all_tables_df.append({
#             "table_index": table_ix + 1,
#             "bbox": bbox,
#             "dataframe": df  # Storing the actual DataFrame
#         })

#     # ✅ Convert all DataFrames to JSON (records format)
#     json_ready_data = []
#     for entry in all_tables_df:
#         json_ready_data.append({
#             "table_index": entry["table_index"],
#             "bbox": entry["bbox"],
#             "table_data": entry["dataframe"].to_dict(orient="records")  # Convert DF to JSON
#         })

#     # ✅ Save to JSON file
#     json_file = output_dir / f"{doc_filename}-all-tables.json"
#     with json_file.open("w", encoding="utf-8") as fp:
#         json.dump({"tables": json_ready_data}, fp, indent=2)

#     _log.info(f"Saved all table data to {json_file}")
#     _log.info(f"Completed in {time.time() - start_time:.2f} seconds.")

# if __name__ == "__main__":
#     main()



### re to markdown find


import re

def extract_markdown_tables(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()

    tables = []
    table = []
    in_table = False

    for line in lines:
        stripped = line.strip()
        if '|' in stripped:
            table.append(stripped)
            # Check for the separator row (e.g., |----|----|----|)
            if re.match(r'^\s*\|?(?:\s*-+\s*\|)+\s*$', stripped):
                in_table = True
        elif in_table:
            # End of table
            if table:
                tables.append(table)
                table = []
            in_table = False

    # Capture last table if file ends with a table
    if table:
        tables.append(table)

    return tables

def save_tables_to_file(tables, output_path):
    with open(output_path, 'w', encoding='utf-8') as f:
        for idx, table in enumerate(tables):
            f.write(f"Table {idx+1}:\n")
            for row in table:
                f.write(row + '\n')
            f.write('\n')  # Add space between tables

# === Replace this with your input text file path ===
input_path = 'docling_output_full_file.txt'

# === Replace this with your desired output text file path ===
output_path = 'extracted_tables_from_markdown.txt'

tables = extract_markdown_tables(input_path)
save_tables_to_file(tables, output_path)

print(f"✅ {len(tables)} tables extracted and saved to {output_path}")