"""
Convergence Evaluation Module
Evaluates whether the agent's execution steps converge on the optimal path.
"""

import os
import json
from typing import List, Any, Dict, Tuple, Set
from datetime import datetime
from langsmith import Client
from utils import get_or_create_workbook, get_or_create_sheet

# ============================================================
# REFERENCE TRAJECTORY (OPTIMAL PATH)
# ============================================================
# ============================================================
# REFERENCE TRAJECTORY — loaded from Excel at runtime
# ============================================================
def load_reference_sequence_for_query(query: str, excel_path: str = "Test_Scenarios_Trajectory.xlsx") -> List[str]:
    from openpyxl import load_workbook

    wb    = load_workbook(excel_path, read_only=True, data_only=True)
    sheet = wb.active

    headers = [cell.value for cell in next(sheet.iter_rows(min_row=1, max_row=1))]

    try:
        query_col      = headers.index("Query")
        trajectory_col = headers.index("Trajectory")
    except ValueError as e:
        raise ValueError(f"Missing required column in Test_Scenarios_Trajectory.xlsx: {e}")

    query_normalized = query.strip().lower()

    for row in sheet.iter_rows(min_row=2, values_only=True):
        cell_query = row[query_col]
        if cell_query and str(cell_query).strip().lower() == query_normalized:
            raw = row[trajectory_col]
            if not raw:
                raise ValueError(f"Trajectory cell is empty for query: '{query}'")

            raw = str(raw).strip()

            # ── Try JSON array first ──────────────────────────────
            try:
                parsed = json.loads(raw)
                if isinstance(parsed, list):
                    return [str(item).strip().strip('"') for item in parsed]
            except json.JSONDecodeError:
                pass

            # ── Fallback: plain comma-separated string ────────────
            # Handles: Supervisor, Supervisor Process, ContextBuilder
            if "[" not in raw:
                return [item.strip().strip('"') for item in raw.split(",") if item.strip()]

            # ── Last resort: extract array portion only ───────────
            # Handles trailing text after the closing bracket
            start = raw.index("[")
            end   = raw.rindex("]") + 1
            return [str(item).strip().strip('"') for item in json.loads(raw[start:end])]

    raise ValueError(f"No trajectory found in Excel for query: '{query}'")

# ============================================================
# TRAJECTORY FORMATTING
# ============================================================
def format_trajectory_with_arrows(agents: List[str]) -> str:
    """Format agent trajectory with arrows between each pair of agents.
    
    Example: ["Agent1", "Agent2", "Agent3"] -> "Agent1 -> Agent2 -> Agent3"
    """
    if not agents:
        return ""
    return " -> ".join(agents)

# ============================================================
# FILTERING
# ============================================================

IGNORE_PREFIXES = ("Runnable", "Pydantic", "Chat")
IGNORE_EXACT = {"model", "tools", "LangGraph"}
IGNORE_SUFFIXES = ("LLM",)

def is_ignored(name: str) -> bool:
    """Check if a span name should be ignored."""
    if name in IGNORE_EXACT:
        return True
    if name.startswith(IGNORE_PREFIXES):
        return True
    if name.endswith(IGNORE_SUFFIXES):
        return True
    return False

# ============================================================
# TRACE EXTRACTION
# ============================================================

def fetch_spans(trace_id: str) -> List[Any]:
    """Fetch all spans for a given trace ID."""
    client = Client(api_key=os.environ["LANGSMITH_API_KEY"])
    spans = list(client.list_runs(trace_id=trace_id))
    if not spans:
        raise ValueError("No spans found for trace.")
    return sorted(spans, key=lambda r: r.start_time or 0)

# ============================================================
# ACTUAL OUTPUTS EXTRACTION
# ============================================================

def extract_actual_outputs(trace_id: str, reference_sequence: List[str]) -> List[str]:
    runs   = fetch_spans(trace_id)
    ref_set = {name.strip() for name in reference_sequence}   # ← normalize reference into a set
    actual = []
    for run in runs:
        name = run.name
        if not name:
            continue
        name = name.strip()                                    # ← normalize span name
        if is_ignored(name):
            continue
        if name in ref_set:                                    # ← now matches correctly
            actual.append(name)
    return actual

# ============================================================
# CONVERGENCE SCORING
# ============================================================

def compute_convergence_score(reference: List[str], actual: List[str]) -> float:
    optimal_steps = len(reference)
    actual_steps  = len(actual)

    if actual_steps == 0:
        return 0.0

    # If agent took fewer steps than optimal, it skipped steps — penalise it
    if actual_steps < optimal_steps:
        return round(actual_steps / optimal_steps, 3)

    # If agent took more steps than optimal, score degrades
    return round(min(optimal_steps / actual_steps, 1.0), 3)

# ============================================================
# ALIGNMENT ANALYSIS
# ============================================================

def compute_alignment(
    reference: List[str],
    actual: List[str],
    score: float
) -> Tuple[str, str, List[str], List[str]]:

    optimal_steps = len(reference)
    actual_steps  = len(actual)
    extra_count   = max(actual_steps - optimal_steps, 0)

    ref_set: Set[str] = set(reference)
    act_set: Set[str] = set(actual)

    missing_steps = sorted(ref_set - act_set)
    extra_steps   = sorted(act_set - ref_set)

    # ── Under-execution: fewer steps than optimal ──────────────
    if actual_steps < optimal_steps:
        missing_count = optimal_steps - actual_steps
        status    = "Not_Aligned"
        reasoning = (
            f"The agent under-executed, completing only {actual_steps} of the expected "
            f"{optimal_steps} steps ({missing_count} step(s) skipped). "
            f"Convergence score is {score:.1%} — required steps were not reached."
        )

    # ── Perfect match ──────────────────────────────────────────
    elif score == 1.0:
        status    = "Aligned"
        reasoning = (
            f"The agent completed the task in exactly {actual_steps} steps, "
            f"matching the optimal path perfectly. No unnecessary steps were detected."
        )

    # ── Minor over-execution ───────────────────────────────────
    elif score >= 0.75:
        status    = "Partially_Aligned"
        reasoning = (
            f"The agent took {actual_steps} steps versus the optimal {optimal_steps}, "
            f"introducing {extra_count} extra step(s). "
            f"Efficiency is acceptable but there is minor wandering ({score:.1%} convergence)."
        )

    # ── Moderate over-execution ────────────────────────────────
    elif score >= 0.50:
        status    = "Partially_Aligned"
        reasoning = (
            f"The agent took {actual_steps} steps versus the optimal {optimal_steps}, "
            f"with {extra_count} unnecessary step(s). "
            f"Noticeable inefficiency detected — convergence score is {score:.1%}."
        )

    # ── Severe over-execution ──────────────────────────────────
    else:
        status    = "Not_Aligned"
        reasoning = (
            f"The agent significantly over-executed, taking {actual_steps} steps "
            f"against an optimal path of {optimal_steps} steps ({extra_count} extra). "
            f"Convergence score of {score:.1%} indicates excessive wandering."
        )

    return status, reasoning, missing_steps, extra_steps

# ============================================================
# FULL PIPELINE
# ============================================================

def run_convergence_eval(trace_id: str, scenario: str) -> Dict[str, Any]:
    """Full convergence evaluation pipeline."""
    try:
        # Extract actual outputs from trace
        reference_outputs = load_reference_sequence_for_query(scenario)
        actual_outputs    = extract_actual_outputs(trace_id, reference_outputs)

        # ── Temporary diagnostic — remove after confirming ──
        all_raw = [r.name for r in fetch_spans(trace_id) if r.name]
        print(f"[DEBUG] Reference sample : {reference_outputs[:5]}")
        print(f"[DEBUG] Raw LangSmith    : {all_raw[:10]}")
        print(f"[DEBUG] Actual filtered  : {actual_outputs[:5]}")
        convergence_score = compute_convergence_score(reference_outputs, actual_outputs)
        alignment_status, reasoning, missing_steps, extra_steps = compute_alignment(
            reference_outputs,
            actual_outputs,
            convergence_score
        )
        
        return {
            "eval_name": "convergence",
            "trace_id": trace_id,
            "scenario": scenario,
            "eval_inputs": {
                "reference_outputs": reference_outputs,
                "actual_outputs": actual_outputs
            },
            "eval_output": {
                "optimal_steps": len(reference_outputs),
                "actual_steps": len(actual_outputs),
                "extra_steps_count": max(len(actual_outputs) - len(reference_outputs), 0),
                "missing_steps": missing_steps,
                "extra_steps": extra_steps,
                "alignment_status": alignment_status,
                "reasoning": reasoning
            },
            "metadata": {
                "model": "python_rule_based",
                "timestamp": datetime.utcnow().isoformat()
            },
            "status": "completed",
            "score": convergence_score
        }
    except Exception as e:
        return {
            "eval_name": "convergence",
            "trace_id": trace_id,
            "scenario": scenario,
            "eval_inputs": {},
            "eval_output": {},
            "metadata": {
                "model": "python_rule_based",
                "timestamp": datetime.utcnow().isoformat()
            },
            "status": "failed",
            "error": str(e),
            "score": 0.0
        }

# ============================================================
# EXCEL OUTPUT
# ============================================================

def dump_convergence_eval_to_excel(
    *,
    trace_id: str,
    query: str,
    eval_result: dict,
    excel_path: str = "final_eval_results.xlsx",
):
    """Save convergence evaluation results to Excel."""
    
    SHEET_NAME = "Convergence"
    HEADERS = [
        "Query",
        "Reference_Output",
        "Actual_Output",
        "Expected_Steps",
        "Actual_Steps",
        "Extra_Steps_Count",
        "Missing_Steps",
        "Extra_Steps",
        "Alignment_Status",
        "Overall_Score",
        "Overall_Reason",

    ]
    
    wb = get_or_create_workbook(excel_path)
    sheet = get_or_create_sheet(wb, SHEET_NAME, HEADERS)
    
    eval_inputs = eval_result.get("eval_inputs", {})
    eval_output = eval_result.get("eval_output", {})
    score = eval_result.get("score", "")
    
    if eval_result.get("status") == "failed":
        sheet.append([
            query,
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            eval_result.get("error", "Unknown error")
        ])
    else:
        reference_outputs = format_trajectory_with_arrows(eval_inputs.get("reference_outputs", []))
        actual_outputs = format_trajectory_with_arrows(eval_inputs.get("actual_outputs", []))
        missing_steps = json.dumps(eval_output.get("missing_steps", []))
        extra_steps = json.dumps(eval_output.get("extra_steps", []))
        
        sheet.append([
            query,
            reference_outputs,
            actual_outputs,
            eval_output.get("optimal_steps", ""),
            eval_output.get("actual_steps", ""),
            eval_output.get("extra_steps_count", ""),
            missing_steps,
            extra_steps,
            eval_output.get("alignment_status", ""),
            score,
            eval_output.get("reasoning", "")
        ])
    
    wb.save(excel_path)
