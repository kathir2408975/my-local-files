"""
Universal Critique Judge Evaluation Module
===========================================

Purpose:
  Meta-evaluation that audits PRIMARY EVALUATORS' adherence to their own evaluation prompts.
  Acts as a procedural compliance checker without re-evaluating the underlying AI system.

Evaluation Logic:
  1. For each primary evaluation result, extract: eval_prompt, eval_inputs, eval_output
  2. Build critique prompt that verifies procedural compliance
  3. Run LLM-based critique (temperature=1, creative reasoning)
  4. Classify violations into canonical error types
  5. Score: pass/fail with specific error categorization
  6. Per-eval critique + overall aggregation (% pass rate)

Span Target:
  Meta-evaluation (no specific spans, processes primary eval results)

Temperature Strategy:
  temperature=1 (creative reasoning for critique analysis)
"""

import json
from typing import Dict, Any, List
from datetime import datetime
from langchain_openai import AzureChatOpenAI


# ============================================================
# ERROR TYPE CANONICAL SET
# ============================================================

ERROR_TYPES = {
    "none",
    "Hallucinated_Content",
    "Omitted_Required_Element",
    "Misinterpretation_of_Input",
    "Verdict_Reasoning_Misalignment",
    "Internal_System_Error"
}


# ============================================================
# CRITIQUE PROMPT BUILDER
# ============================================================

def build_critique_prompt(eval_record: Dict[str, Any]) -> str:
    """
    Build comprehensive critique prompt for a single primary evaluation.
    
    Verifies that the primary evaluator:
    1. Applied all mandatory rules from its prompt
    2. Grounded all claims in provided inputs only
    3. Produced verdicts that logically follow from its reasoning
    """
    return f"""**Situation**
You are auditing a PRIMARY EVALUATOR's adherence to its own evaluation prompt. The PRIMARY EVALUATOR has been given an evaluation prompt, evaluation inputs extracted from LangSmith trace data, and has produced an evaluation output. Your role is to verify procedural compliance—not to re-evaluate the underlying AI system or introduce new criteria.

**Task**
The assistant should:
1. Verify that the PRIMARY EVALUATOR applied all mandatory rules explicitly stated in its evaluation prompt.
2. Confirm that all reasoning claims in the evaluation output are grounded strictly in the provided evaluation inputs.
3. Ensure the final verdict logically follows from the evaluator's own reasoning.
4. Classify any procedural violation into exactly one error category from the predefined list.
5. Return structured JSON output with no additional commentary.

**Objective**
Ensure strict procedural compliance of the PRIMARY EVALUATOR against its own rulebook. If the evaluator followed its own rules consistently, the evaluation is correct—even if the verdict seems wrong. If a violation exists, identify it precisely and demonstrate the error using only real content from the provided inputs, outputs, and prompts.

**Knowledge**
The assistant must NOT:
- Re-evaluate the AI system or decide what the correct task answer should have been.
- Introduce new criteria, strengthen or weaken the rubric, or apply outside knowledge.
- Penalize formatting unless explicitly required in the evaluation prompt.
- Generate error demonstrations using hypothetical, fabricated, or invented examples.
- Create artificial scenarios or missing evidence.

The assistant MUST:
- Quote exact fragments from EVALUATION INPUTS, EVALUATION OUTPUT, and EVALUATION PROMPT when demonstrating errors.
- Treat the EVALUATION PROMPT as the authoritative rulebook and EVALUATION INPUTS as the only allowed evidence.
- Determine if the evaluator ignored required criteria, applied unauthorized criteria, or produced a verdict that doesn't logically follow from its reasoning.

**Error Categories (Select Exactly One)**
- **none**: The evaluator fully followed its own rules. No error demonstration should be generated.
- **Hallucinated_Content**: The evaluator introduced claims not grounded in inputs or not defined in its prompt.
- **Omitted_Required_Element**: The evaluator failed to apply or analyze a mandatory rule from its prompt.
- **Misinterpretation_of_Input**: The evaluator incorrectly interpreted or misread the evaluation inputs.
- **Verdict_Reasoning_Misalignment**: The evaluator's verdict does not logically follow from its own reasoning.
- **Internal_System_Error**: The evaluator returned malformed or unparseable output.

============================================================
EVALUATION NAME
============================================================
{eval_record.get("eval_name", "")}

============================================================
EVALUATION TYPE
============================================================
{eval_record.get("eval_type", "")}

============================================================
EVALUATION PROMPT (RULEBOOK)
============================================================
{eval_record.get("eval_prompt", "")}

============================================================
EVALUATION INPUTS (ONLY SOURCE OF TRUTH)
============================================================
{json.dumps(eval_record.get("eval_inputs", {}), indent=2, default=str)}

============================================================
EVALUATION OUTPUT (PRIMARY EVALUATOR OUTPUT)
============================================================
{json.dumps(eval_record.get("eval_output", {}), indent=2, default=str)}

------------------------------------------------------------
OUTPUT FORMAT
------------------------------------------------------------

If no error is found:

{{
  "error_status": "pass",
  "error_type": "none",
  "reason": "Concise explanation referencing evaluator rule compliance"
}}

If an error is identified:

{{
  "error_status": "fail",
  "error_type": "[one category only]",
  "reason": "Concise explanation referencing exact quoted violations",
  "few_shot_example": {{
    "positive_scenario": "If structured error → JSON example showing correct rule application using exact required fields or rule text. If reasoning error → statement example quoting exact rule and showing correct alignment.",
    "negative_scenario": "JSON example (for format errors) OR quoted evaluator statement (for reasoning errors) demonstrating the actual violation using real fragments."
  }}
}}

------------------------------------------------------------
SAMPLE FEW-SHOT EXAMPLES (FORMAT REFERENCE ONLY)
------------------------------------------------------------

Example 1 — JSON Type Error (Omitted_Required_Element)

{{
  "error_status": "fail",
  "error_type": "Omitted_Required_Element",
  "reason": "The evaluator failed to include the required 'confidence_score' field explicitly mandated in the evaluation prompt.",
  "few_shot_example": {{
    "positive_scenario": {{
      "expected_structure": {{
        "verdict": "pass",
        "confidence_score": "0.92"
      }}
    }},
    "negative_scenario": {{
      "actual_output": {{
        "verdict": "pass"
      }},
      "violation": "The 'confidence_score' field required by the prompt is missing."
    }}
  }}
}}

------------------------------------------------------------

Example 2 — Hallucinated_Content (Statement Type)

{{
  "error_status": "fail",
  "error_type": "Hallucinated_Content",
  "reason": "The evaluator referenced criteria not defined in the evaluation prompt.",
  "few_shot_example": {{
    "positive_scenario": "Evaluator restricts reasoning strictly to rules stated in: 'The response must include at least one direct quote from the input.'",
    "negative_scenario": "Evaluator states: 'The tone was unprofessional,' although tone assessment is not mentioned anywhere in the evaluation prompt."
  }}
}}

------------------------------------------------------------

Example 3 — Verdict_Reasoning_Misalignment (Statement Type)

{{
  "error_status": "fail",
  "error_type": "Verdict_Reasoning_Misalignment",
  "reason": "The evaluator concluded 'pass' despite explicitly stating a required rule was violated.",
  "few_shot_example": {{
    "positive_scenario": "Evaluator states: 'The response does not contain the required citation.' → Final verdict: 'fail'.",
    "negative_scenario": "Evaluator states: 'The response does not contain the required citation.' → Final verdict: 'pass'."
  }}
}}

------------------------------------------------------------

Example 4 — Misinterpretation_of_Input (Format Robustness Case)


Context:
The evaluator incorrectly relied on label position instead of explicit rule instructions.

{{
  "error_status": "fail",
  "error_type": "Misinterpretation_of_Input",
  "reason": "The evaluator inferred sentiment based on label placement rather than applying the explicit rule defined in the evaluation prompt.",
  "few_shot_example": {{
    "positive_scenario": "Evaluator follows the rule: 'Classify sentiment based strictly on textual meaning, regardless of formatting or label position.' For input: 'Positive This is awesome!' → The evaluator analyzes the phrase 'This is awesome!' and determines sentiment from content.",
    "negative_scenario": "Evaluator states: 'The label appears before the sentence, so the sentiment is Positive,' instead of analyzing the actual sentence content."
  }}
}}

------------------------------------------------------------
Example 5 — Hallucinated_Content (Pattern Assumption Case)

{{
  "error_status": "fail",
  "error_type": "Hallucinated_Content",
  "reason": "The evaluator assumed structural consistency based on previous examples, which is not defined as a rule in the evaluation prompt.",
  "few_shot_example": {{
    "positive_scenario": "Evaluator explicitly references the rule: 'Do not infer structure unless explicitly stated in the evaluation prompt.'",
    "negative_scenario": "Evaluator states: 'Since earlier examples followed a consistent format, this output must also follow that pattern,' even though no such rule exists in the prompt."
  }}
}}

------------------------------------------------------------
Return JSON only. No markdown, commentary, or explanation.
"""


# ============================================================
# JSON SAFE PARSER
# ============================================================

def safe_json_load(raw: str):
    """
    Parse JSON from raw LLM output with markdown cleanup.
    
    Handles:
    - Markdown code blocks (```json ... ```)
    - Nested JSON extraction
    """
    raw = raw.strip()
    if not raw:
        raise ValueError("Empty LLM output")

    if raw.startswith("```"):
        raw = raw.strip("`").strip()
        if raw.lower().startswith("json"):
            raw = raw[4:].strip()

    decoder = json.JSONDecoder()
    obj, _ = decoder.raw_decode(raw)
    return obj


# ============================================================
# SINGLE CRITIQUE EXECUTION
# ============================================================

def run_critique_judge(eval_record: Dict[str, Any], llm_client) -> Dict[str, Any]:
    """
    Run critique judgment on a single primary evaluation.
    
    Args:
        eval_record: dict with eval_name, eval_type, eval_prompt, eval_inputs, eval_output
        llm_client: Azure OpenAI client (temperature=1)
    
    Returns:
        dict with eval_name, trace_id, scenario, critique (error_status, error_type, reason, few_shot_example)
    """
    try:
        prompt = build_critique_prompt(eval_record)

        response = llm_client.invoke(prompt)
        raw = response.content if hasattr(response, "content") else str(response)

        try:
            critique = safe_json_load(raw)
        except Exception as e:
            critique = {
                "error_status": "fail",
                "error_type": "Internal_System_Error",
                "reason": f"Critique judge returned invalid JSON: {str(e)}"
            }

        # Safety clamp: enforce valid error_type
        if critique.get("error_type") not in ERROR_TYPES:
            critique["error_type"] = "Internal_System_Error"
            critique["error_status"] = "fail"
            critique["reason"] = critique.get("reason", "") + " (Invalid error_type returned by critique judge.)"

        return {
            "eval_name": eval_record.get("eval_name"),
            "trace_id": eval_record.get("trace_id"),
            "scenario": eval_record.get("scenario"),
            "critique": critique,
            "status": "completed"
        }

    except Exception as e:
        return {
            "eval_name": eval_record.get("eval_name"),
            "trace_id": eval_record.get("trace_id"),
            "scenario": eval_record.get("scenario"),
            "status": "failed",
            "error": str(e)
        }


# ============================================================
# BATCH CRITIQUE RUNNER
# ============================================================

def run_universal_critique_judge(eval_records: List[Dict[str, Any]], llm_client) -> Dict[str, Any]:
    """
    Run critique on all primary evaluations from a single trace.
    
    Args:
        eval_records: list of evaluation result dicts (one per evaluation type)
        llm_client: Azure OpenAI client (temperature=1)
    
    Returns:
        dict with:
        - status: "completed" | "failed"
        - trace_id, scenario
        - critiques: list of per-eval critique results
        - total_evals, passed_evals, failed_evals, overall_score
        - timestamp
    """
    if not eval_records:
        return {
            "status": "failed",
            "error": "No evaluation records provided",
        }

    # Extract trace_id and scenario from first record
    trace_id = eval_records[0].get("trace_id")
    scenario = eval_records[0].get("scenario")

    critiques = []
    passed_count = 0
    failed_count = 0

    for eval_record in eval_records:
        critique_result = run_critique_judge(eval_record, llm_client)

        if critique_result.get("status") == "completed":
            critiques.append(critique_result)
            
            if critique_result.get("critique", {}).get("error_status") == "pass":
                passed_count += 1
            else:
                failed_count += 1
        else:
            # Failed to critique this evaluation
            failed_count += 1
            critiques.append(critique_result)

    total_evals = passed_count + failed_count
    overall_score = round(passed_count / total_evals, 4) if total_evals > 0 else 0.0

    return {
        "status": "completed",
        "trace_id": trace_id,
        "scenario": scenario,
        "critiques": critiques,
        "total_evals": total_evals,
        "passed_evals": passed_count,
        "failed_evals": failed_count,
        "overall_score": overall_score,
        "model": "gpt-5",
        "temperature": 1,
        "timestamp": datetime.utcnow().isoformat(),
    }


# ============================================================
# EXCEL DUMP FUNCTION
# ============================================================

def dump_universal_critique_judge_to_excel(eval_result, output_excel, utils):
    """
    Dump universal critique judge results to Excel sheet.
    
    Args:
        eval_result: dict from run_universal_critique_judge()
        output_excel: path to Excel file
        utils: utils module with get_or_create_workbook, get_or_create_sheet
    """
    try:
        sheet_name = "Universal Critique Judge"

        wb = utils.get_or_create_workbook(output_excel)
        sheet = utils.get_or_create_sheet(
            wb,
            sheet_name,
            headers=[

                "Query",
                "Eval_Name",
                "Error_Status",
                "Error_Type",
                "Reason",
                "Few_Shot_Example",
            ]
        )

    
        scenario = eval_result.get("scenario")
        status = eval_result.get("status")
        error = eval_result.get("error", "")

        if status == "failed":
            sheet.append([
                scenario,
                "",
                status,
                error,
                "",
                "",
            ])
        else:
            critiques = eval_result.get("critiques", [])
            total_evals = eval_result.get("total_evals")
            passed_evals = eval_result.get("passed_evals")
            failed_evals = eval_result.get("failed_evals")
            overall_score = eval_result.get("overall_score")

            if critiques:
                for critique_result in critiques:
                    eval_name = critique_result.get("eval_name", "")
                    critique = critique_result.get("critique", {})
                    
                    error_status = critique.get("error_status", "")
                    error_type = critique.get("error_type", "")
                    reason = critique.get("reason", "")

                    few_shot_block = ""
                    if error_type != "none" and "few_shot_example" in critique:
                        try:
                            few_shot_block = json.dumps(
                                critique.get("few_shot_example", {}),
                                indent=2,
                                default=str
                            )
                        except Exception:
                            few_shot_block = str(critique.get("few_shot_example", ""))

                    sheet.append([
                       
                        scenario,
                        eval_name,
                        error_status,
                        error_type,
                        reason,
                        few_shot_block,
                    
                    ])
            else:
                sheet.append([
                   
                    scenario,
                    "",
                    "",
                    "",
                    "",
                    "",
                ])

        wb.save(output_excel)

    except Exception as e:
        print(f"❌ Error dumping Universal Critique Judge to Excel: {e}")
