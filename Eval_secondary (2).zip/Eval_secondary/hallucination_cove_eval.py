"""
Hallucination CoVe Evaluation Module
Evaluates whether the final summary is factually grounded in execution context.

Status labels: supported | grounded_mismatch | unsupported_claim
"""

import os
import json
import re
from datetime import datetime
from typing import List, Any, Dict
from langsmith import Client
from langchain_openai import AzureChatOpenAI
from openpyxl import Workbook, load_workbook
from token_tracker import track_tokens_used, count_tokens
from pathlib import Path


# ============================================================
# TRACE EXTRACTION
# ============================================================
def fetch_spans(trace_id: str) -> List[Any]:
    """Fetch all spans for a given trace ID."""
    client = Client(api_key=os.environ["LANGSMITH_API_KEY"])
    spans  = list(client.list_runs(trace_id=trace_id))
    if not spans:
        raise ValueError("No spans found for trace.")
    return sorted(spans, key=lambda r: r.start_time or 0)


# ============================================================
# SPAN FINDERS
# ============================================================
def find_execute_span(spans: List[Any]) -> Any:
    """Find the Execute span."""
    for s in spans:
        if s.name == "Execute":
            return s
    raise ValueError("Execute span not found")


def find_execute_plan_summary_llm(spans: List[Any]) -> Any:
    """Find the Execute Plan Summary LLM span."""
    for s in spans:
        if s.name == "Execute Plan Summary LLM":
            return s
    raise ValueError("Execute Plan Summary LLM span not found")


# ============================================================
# DATA EXTRACTION
# ============================================================
def extract_execute_context(execute_span: Any) -> Dict[str, Any]:
    """Context = Execute.inputs (entire input object)."""
    if not execute_span.inputs:
        raise ValueError("Execute span has no inputs")
    return execute_span.inputs


def extract_execute_plan_summary(summary_span: Any) -> str:
    """Summary = outputs.generations[0][0].text"""
    try:
        return summary_span.outputs["generations"][0][0]["text"]
    except Exception as e:
        raise ValueError(f"Could not extract summary text: {e}")


# ============================================================
# NUMERIC NORMALIZATION
# ============================================================
def extract_numbers(text: str) -> List[float]:
    """Extract all numbers from text."""
    nums = []
    for m in re.findall(r"\$?\d[\d,]*\.?\d*", text):
        try:
            nums.append(float(m.replace("$", "").replace(",", "")))
        except Exception:
            pass
    return nums


def numerically_equivalent(a: List[float], b: List[float], tol: float = 1.0) -> bool:
    """Check if two lists of numbers are numerically equivalent within tolerance."""
    return all(any(abs(x - y) <= tol for y in b) for x in a)


# ============================================================
# HALLUCINATION CoVe EVALUATION
# ============================================================
def evaluate_hallucination_cove(
    *,
    execution_context: Dict[str, Any],
    actual_answer: str,
    llm_client: AzureChatOpenAI,
) -> tuple:
    """Evaluate hallucination by verifying claims against execution context.
    Returns (cove_result, eval_prompt).
    """

    eval_prompt = f"""
Role:
You are a factual consistency evaluator.

Your responsibility is to check whether factual claims stated
inside actual_answer align with execution_context.

This is a verification task.
Do not rewrite text or generate suggestions.


INPUTS

execution_context:
{json.dumps(execution_context, indent=2)}

actual_answer:
{actual_answer}


DEFINITIONS

execution_context:
Structured ground-truth data derived from system execution.

actual_answer:
A generated summary that may contain factual statements.

Verification Question:
A neutral factual question derived from a claim visible
inside actual_answer.


OBJECTIVE

Identify factual claims in actual_answer and evaluate whether
each claim is grounded in execution_context.

Questions should originate from actual_answer.


GUIDELINES

- Use information visible in the inputs.
- Avoid outside knowledge or assumptions.
- Each question should focus on one factual attribute.
- Keep evaluation neutral and factual.


CLAIM EXTRACTION

Step 1:
Read actual_answer.

Step 2:
Identify up to eight explicit factual claims.

Typical examples include:
- plan identifiers
- vendors
- dates
- numeric values
- execution outcomes
- routing or cost details

Avoid:
- conversational language
- stylistic text
- speculative statements

Step 3:
Create between one and eight verification questions.
Each question should be objective and map to a single claim.


ANSWER GENERATION

For each question:

1. Extract the answer from execution_context.
2. Extract the answer from actual_answer.
3. Compare both answers.


STATUS DEFINITIONS

supported:
The claim exists in execution_context and aligns with it.

grounded_mismatch:
The claim refers to an attribute present in execution_context,
but the value or detail differs.

unsupported_claim:
The claim introduces information that does not appear anywhere
in execution_context.

Numeric formatting differences such as rounding or commas may
still be treated as supported if values are equivalent.


OUTPUT FORMAT (JSON)

{{
  "generated_questions": ["string"],
  "evaluations": [
    {{
      "question": "string",
      "expected_answer_response": "string",
      "actual_answer_response": "string",
      "status": "supported | grounded_mismatch | unsupported_claim",
      "reasoning": "string"
    }}
  ]
}}


FEW SHOT EXAMPLES

Example 1 — supported

execution_context:
{{"plan_id":"PLAN_1","estimated_date":"2026-10-02"}}

actual_answer:
"PLAN_1 arrives on 2026-10-02."

Output:
{{
  "generated_questions":[
    "What is the plan ID?",
    "What is the estimated arrival date?"
  ],
  "evaluations":[
    {{
      "question":"What is the plan ID?",
      "expected_answer_response":"PLAN_1",
      "actual_answer_response":"PLAN_1",
      "status":"supported",
      "reasoning":"Plan identifier matches execution_context."
    }},
    {{
      "question":"What is the estimated arrival date?",
      "expected_answer_response":"2026-10-02",
      "actual_answer_response":"2026-10-02",
      "status":"supported",
      "reasoning":"Date value aligns with execution_context."
    }}
  ]
}}

------------------------------------------------------------

Example 2 — grounded_mismatch

execution_context:
{{"total_estimated_cost":"381188.5"}}

actual_answer:
"Total estimated cost is 400000."

Output:
{{
  "generated_questions":[
    "What is the total estimated cost?"
  ],
  "evaluations":[
    {{
      "question":"What is the total estimated cost?",
      "expected_answer_response":"381188.5",
      "actual_answer_response":"400000",
      "status":"grounded_mismatch",
      "reasoning":"Cost exists in execution_context but value differs."
    }}
  ]
}}

------------------------------------------------------------

Example 3 — unsupported_claim

execution_context:
{{"vendor_id_1":"7001"}}

actual_answer:
"Vendor Seattle Pacific Express operates via airways."

Output:
{{
  "generated_questions":[
    "What vendor name is mentioned?",
    "What transport mode is mentioned?"
  ],
  "evaluations":[
    {{
      "question":"What vendor name is mentioned?",
      "expected_answer_response":"",
      "actual_answer_response":"Seattle Pacific Express",
      "status":"unsupported_claim",
      "reasoning":"Vendor name does not exist in execution_context."
    }},
    {{
      "question":"What transport mode is mentioned?",
      "expected_answer_response":"",
      "actual_answer_response":"airways",
      "status":"unsupported_claim",
      "reasoning":"Transport mode is not present in execution_context."
    }}
  ]
}}
""".strip()

    response = llm_client.invoke(eval_prompt)
    tokens = count_tokens(response.content)
    track_tokens_used(tokens, eval_name="hallucination_cove")
    raw = response.content.strip()

    try:
        return json.loads(raw), eval_prompt
    except Exception:
        m = re.search(r"(\{.*\})", raw, re.DOTALL)
        if not m:
            raise RuntimeError(f"Unparseable CoVe output:\n{raw}")
        return json.loads(m.group(1)), eval_prompt


# ============================================================
# SCORING — 3-class
# ============================================================
def score_hallucination_cove(status: str) -> float:
    """Score individual verification question statuses."""
    return {
        "supported":         1.0,
        "grounded_mismatch": 0.5,
        "unsupported_claim": 0.0,
    }.get(status, 0.0)


# ============================================================
# FULL PIPELINE
# ============================================================
def run_hallucination_cove_eval(
    trace_id: str,
    scenario: str,
    llm_client: AzureChatOpenAI,
) -> Dict[str, Any]:
    """
    Full hallucination CoVe evaluation pipeline.

    Args:
        trace_id:   LangSmith trace ID
        scenario:   Query/scenario text
        llm_client: Azure OpenAI client

    Returns:
        Evaluation result dictionary compatible with main.py
    """
    try:
        spans        = fetch_spans(trace_id)
        execute_span = find_execute_span(spans)
        summary_span = find_execute_plan_summary_llm(spans)

        context       = extract_execute_context(execute_span)
        actual_answer = extract_execute_plan_summary(summary_span)

        cove_result, eval_prompt = evaluate_hallucination_cove(
            execution_context=context,
            actual_answer=actual_answer,
            llm_client=llm_client,
        )

        if not cove_result.get("evaluations"):
            raise RuntimeError(
                "CoVe returned zero evaluations. Prompt failed to generate questions."
            )

        # Numeric tolerance override: grounded_mismatch → supported
        for ev in cove_result.get("evaluations", []):
            if ev.get("status") == "grounded_mismatch":
                ctx_nums = extract_numbers(json.dumps(context))
                act_nums = extract_numbers(actual_answer)
                if ctx_nums and act_nums and numerically_equivalent(ctx_nums, act_nums):
                    ev["status"]    = "supported"
                    ev["reasoning"] += " | Reclassified as supported due to numeric tolerance."

        statuses = [ev["status"] for ev in cove_result.get("evaluations", [])]
        score    = (
            round(sum(score_hallucination_cove(s) for s in statuses) / len(statuses), 2)
            if statuses else 1.0
        )

        total_q       = len(statuses)
        correct_q     = sum(1 for s in statuses if s == "supported")
        mismatch_q    = sum(1 for s in statuses if s == "grounded_mismatch")
        unsupported_q = sum(1 for s in statuses if s == "unsupported_claim")

        overall_reason = (
            f"{correct_q} out of {total_q} generated questions are supported. "
            f"{mismatch_q} grounded mismatches, "
            f"{unsupported_q} unsupported claims."
        )

        return {
            "eval_name":  "hallucination_cove",
            "eval_type":  "llm",
            "trace_id":   trace_id,
            "scenario":   scenario,
            # FIX 1: was "completed" — main.py summary stats use ok_status="success"
            "status":     "success",
            "error":      None,
            "eval_prompt": eval_prompt,
            "eval_inputs": {
                "execution_context": context,
                "actual_answer":     actual_answer,
                # FIX 2: notebook logger reads eval_inputs.expected_answer
                # for "Expected Output" column — was missing entirely
                "expected_answer": json.dumps(context, ensure_ascii=False),
            },
            "eval_output": {
                **cove_result,
                "score":          score,
                "overall_reason": overall_reason,
                "actual_output":  actual_answer,
            },
            "metadata": {
                "model":     "gpt-5",
                "timestamp": datetime.utcnow().isoformat(),
            },
        }

    except Exception as e:
        return {
            "eval_name":  "hallucination_cove",
            "eval_type":  "llm",
            "trace_id":   trace_id,
            "scenario":   scenario,
            "status":     "failed",
            "error":      str(e),
            "eval_inputs":  {},
            "eval_output":  {},
            "metadata": {
                "model":     "gpt-5",
                "timestamp": datetime.utcnow().isoformat(),
            },
        }


# ============================================================
# EXCEL OUTPUT — aligned with notebook logger
# ============================================================

# ----------------------------------
# CONFIG
# ----------------------------------
SHEET_NAME_COVE = "Hallucination CoVe"

COVE_HEADERS = [
    "Query",
    "Context",
    "Actual Output",
    "Verification Question Generated",
    "Answer Fetched from Context",
    "Answer Fetched from Actual Output",
    "Status",
    "Reason",
    "Overall Score",
    "Overall Reason",
]

# ----------------------------------
# WORKBOOK HELPERS
# ----------------------------------
def get_or_create_workbook_cove(path: str):
    if Path(path).exists():
        wb = load_workbook(path)
    else:
        wb = Workbook()
        wb.remove(wb.active)
    return wb


def get_or_create_sheet_HC(wb, sheet_name: str, headers: list):
    if sheet_name in wb.sheetnames:
        sheet = wb[sheet_name]
    else:
        sheet = wb.create_sheet(sheet_name)
        sheet.append(headers)
    return sheet


# ----------------------------------
# MAIN DUMP FUNCTION (UPDATED)
# ----------------------------------
def dump_hallucination_cove_eval_to_excel(
    *,
    trace_id: str,
    query: str,
    eval_result: dict,
    excel_path: str = "final_eval_results.xlsx",
):
    wb = get_or_create_workbook_cove(excel_path)
    sheet = get_or_create_sheet_HC(
        wb,
        SHEET_NAME_COVE,
        COVE_HEADERS
    )

    eval_inputs = eval_result.get("eval_inputs", {})
    eval_output = eval_result.get("eval_output", {})

    expected_answer = eval_inputs.get("expected_answer", "")
    actual_answer = eval_inputs.get("actual_answer", "")
    overall_score = eval_output.get("score")
    overall_reason = eval_output.get("overall_reason", "")

    evaluations = eval_output.get("evaluations", [])

    # ----------------------------------
    # SAFE FALLBACK — NO QUESTIONS GENERATED
    # ----------------------------------
    if not evaluations:
        sheet.append([
            query,
            expected_answer,
            actual_answer,
            None,
            None,
            None,
            None,
            None,
            overall_score,
            overall_reason,
        ])
        wb.save(excel_path)
        return

    # ----------------------------------
    # ONE ROW PER VERIFICATION QUESTION
    # ----------------------------------
    for ev in evaluations:
        sheet.append([
            query,
            expected_answer,
            actual_answer,
            ev.get("question"),
            ev.get("expected_answer_response"),
            ev.get("actual_answer_response"),
            ev.get("status"),
            ev.get("reasoning"),
            overall_score,
            overall_reason,
        ])

    wb.save(excel_path)