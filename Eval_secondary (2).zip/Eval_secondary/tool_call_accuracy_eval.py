import os
import json
import ast
from datetime import datetime
from typing import List, Dict, Any
from langsmith import Client
from langchain_openai import AzureChatOpenAI
from token_tracker import track_tokens_used, count_tokens

# ============================================================
# CONFIG — EXPECTED TOOLS
# ============================================================

EXPECTED_TOOLS = {
    "analytics_vendors_count": {
        "allowed_parameters": {
            "base_location": "string",
            "mode": "string"
        },
        "parameter_policy": "any_subset",
        "strict": False
    },
    "analytics_confirmed_order_lookup": {
        "allowed_parameters": {
            "order_id": "string"
        },
        "parameter_policy": "exact",
        "strict": False
    },
    "analytics_purchase_history": {
        "allowed_parameters": {
            "delivery_type": "string",
            "limit": "int",
            "vendor_id": "string"
        },
        "parameter_policy": "any_subset",
        "strict": False
    },
    "analytics_get_unique_locations": {
        "allowed_parameters": {},
        "parameter_policy": "exact",
        "strict": False
    },

    "Fetch Vendors Tool": {
        "allowed_parameters": {
            "base_location": "string"
        },
        "parameter_policy": "exact",
        "strict": True
    },
    "Fetch Performance History": {
        "allowed_parameters": {
            "base_location": "string"
        },
        "parameter_policy": "exact",
        "strict": True
    },
    "Web Search Tool": {
        "allowed_parameters": {
            "query": "string"
        },
        "parameter_policy": "exact",
        "strict": True
    },

    "Calculate Extra Charges Tool": {
        "allowed_parameters": {
            "event_cost": "int",
            "weather_cost": "int"
        },
        "parameter_policy": "exact",
        "strict": True
    },
    "Calculate Delivery Cost Tool": {
        "allowed_parameters": {
            "extra_charges": "string",
            "vendor_id_1": "string",
            "vendor_id_2": "string/empty"
        },
        "parameter_policy": "exact",
        "strict": True
    },
    "Calculate Delivery Time Tool": {
        "allowed_parameters": {
            "vendor_id_1": "string",
            "vendor_id_2": "string/empty"
        },
        "parameter_policy": "exact",
        "strict": True
    },
    "Calculate Forecast Confidence Tool": {
        "allowed_parameters": {
            "estimated_date_1": "string",
            "estimated_date_2": "string/empty",
            "extra_charges": "string",
            "total_estimated_cost": "string",
            "vendor_id_1": "string",
            "vendor_id_2": "string/empty"
        },
        "parameter_policy": "any_subset",
        "strict": True
    },

    "Load Optimization Data Tool": {
        "allowed_parameters": {},
        "parameter_policy": "exact",
        "strict": True
    },
    "Compute Vendor Performance Tool": {
        "allowed_parameters": {
            "order_history": "list"
        },
        "parameter_policy": "exact",
        "strict": True
    },
    "Score Candidates Tool": {
        "allowed_parameters": {
            "order": "dict",
            "context": "dict",
            "vendor_performance": "dict",
            "critique_candidates": "list"
        },
        "parameter_policy": "exact",
        "strict": True
    },

    "Load Compliance Data Tool": {
        "allowed_parameters": {},
        "parameter_policy": "exact",
        "strict": True
    },
    "Check Holiday Event Tool": {
        "allowed_parameters": {
            "base_location": "string",
            "target_location": "string",
            "delivery_date": "string"
        },
        "parameter_policy": "exact",
        "strict": True
    },
    "Evaluate Compliance Tool": {
        "allowed_parameters": {
            "order": "dict",
            "context": "dict",
            "optimisation_output": "dict",
            "holiday_info": "dict",
            "sla_min_normal": "float",
            "sla_min_high_risk": "float",
            "vendor_min_reliab_normal": "float",
            "vendor_min_reliab_high_risk": "float"
        },
        "parameter_policy": "exact",
        "strict": True
    },

    "Get Plan Information Tool": {
        "allowed_parameters": {
            "planid": "string"
        },
        "parameter_policy": "exact",
        "strict": True
    },
    "Save Confirmed Order Tool": {
        "allowed_parameters": {
            "plan_id": "string",
            "user_email": "string"
        },
        "parameter_policy": "exact",
        "strict": True
    },

    "Routing Combinator": {
        "allowed_parameters": {},
        "parameter_policy": "exact",
        "strict": True
    },
    "get_routing_combinations":{
        "allowed_parameters":{},
        "parameter_policy":"exact",
        "strict":True
    },
    "count_plans": {
        "allowed_parameters": {
            "min_conf": "float",
            "routes": "list"
        },
        "parameter_policy": "exact",
        "strict": True
    },
}

IGNORED_TOOLS = {
    "Searching Internet...",
    "Send Mail Tool",
    "Compute Vendor Performance Tool",
    "Score Candidates Tool",
    "Evaluate Compliance Tool",
}

# ============================================================
# STEP 1: EXTRACT ACTUAL TOOL CALLS
# ============================================================

def extract_tool_calls_from_trace(trace_id: str) -> List[Dict[str, Any]]:
    client = Client(api_key=os.environ["LANGSMITH_API_KEY"])
    runs = list(client.list_runs(trace_id=trace_id))

    calls = []

    for run in runs:
        if run.run_type != "tool":
            continue
        if run.name in IGNORED_TOOLS:
            continue

        raw_input = run.inputs.get("input", {})

        if isinstance(raw_input, str):
            try:
                raw_input = ast.literal_eval(raw_input)
            except Exception:
                raw_input = {"raw": raw_input}

        calls.append({
            "tool_name": run.name,
            "parameters": raw_input
        })

    return calls


# ============================================================
# STEP 2: LLM DIAGNOSTICS
# ============================================================

def evaluate_tool_calls(expected_tools, actual_tool_calls, llm):

    system_prompt = """
    Role:
You are an AUTOMATED TOOL CALL VERIFICATION ENGINE.
You are a STRICT, MECHANICAL AUDITOR.
You are NOT a planner, assistant, or problem solver.
Your ONLY responsibility is to verify whether tool calls that were ACTUALLY EXECUTED conform exactly to their authoritative specifications.
You must behave deterministically.
You must not infer, repair, or reinterpret behavior.

Inputs:
{EXPECTED_TOOLS}: Authoritative specification of valid tools. Defines valid tool names, allowed parameter names per tool, parameter_policy ("exact" or "any_subset"), whether parameter format checking is enforced via "strict", and parameter formats (if defined).
{ACTUAL_TOOL_CALLS}: The complete set of tool calls that were executed. Defines the ONLY evaluation universe.

Instructions:
Evaluation Scope (Critical):
Evaluate ONLY tools listed in ACTUAL_TOOL_CALLS.
Do NOT invent, infer, or mention tools that were not called.
Do NOT penalize missing tool calls.
Do NOT apply external or domain knowledge.

Evaluation Order (Strict and Mandatory):
You MUST apply checks in the following order, with NO deviation:
1. Tool Name Check
2. Tool Parameter Check
3. Parameter Format Check

Gating Rules (Mandatory Control Flow):
If Tool Name Check = incorrect:
- Tool Parameter Check → skipped
- Parameter Format Check → skipped

If Tool Parameter Check = incorrect:
- Parameter Format Check → skipped

Check Definitions:

1. Tool Name Check
correct:
- tool_name exists as a key in EXPECTED_TOOLS
incorrect:
- tool_name does NOT exist in EXPECTED_TOOLS

2. Tool Parameter Check
Validation depends on parameter_policy defined in EXPECTED_TOOLS.

parameter_policy = "exact":
- Provided parameter keys MUST match EXACTLY
- No missing parameters
- No extra parameters

parameter_policy = "any_subset":
- Provided parameter keys MUST be a subset of allowed_parameters
- Any extra parameter NOT listed is INVALID

If Tool Name Check is incorrect, this check MUST be skipped.

3. Parameter Format Check
Validate ONLY parameter VALUE formats.
Parameter formats are defined INSIDE EXPECTED_TOOLS.
Do NOT infer or assume formats.
If no format is defined for a parameter, do NOT validate it.

If Tool Parameter Check is incorrect, this check MUST be skipped.

Allowed Judgment Values:
You MUST use ONLY:
"pass"
"fail"

Rules:
- Any skipped check MUST be marked as "fail".
- Do NOT output "skipped".


Reason Construction Rules (STRICT):

The reason field MUST include the expected schema formats
for ALL provided arguments.

Format requirements:

- Use the word "arguments" (never parameters).
- When argument format check passes, append the expected formats
  in brackets using this pattern:

  expected_formats: arg1(type), arg2(type)

Example:
"Tool recognized; provided arguments comply with exact policy; argument value types align with schema expectations; expected_formats: vendor_id_1(string), vendor_id_2(string)."

Rules:

- expected_formats MUST come from EXPECTED_TOOLS.allowed_parameters.
- Include ONLY arguments that were provided in the ACTUAL_TOOL_CALL.
- Maintain professional audit tone.
- Do NOT add recommendations or suggestions.


Output Format:
Return ONLY a JSON object with the following structure:
{
  "tools": [
    {
      "tool_name": "string",
      "tool_name_check": "correct | incorrect",
      "tool_parameter_check": "correct | incorrect | skipped",
      "parameter_format_check": "correct | incorrect | skipped",
      "reason": "short, precise justification"
    }
  ],
  "overall_reason": "High-level assessment of tool-call correctness"
}

Few Shot Examples:

Example 1 — Fully Correct Tool Call

EXPECTED_TOOLS:
{
  "analytics_vendors_find": {
    "allowed_parameters": ["base_location", "limit"],
    "parameter_policy": "any_subset",
    "strict": false
  }
}

ACTUAL_TOOL_CALLS:
[
  {
    "tool_name": "analytics_vendors_find",
    "parameters": {
      "base_location": "BOSTON"
    }
  }
]

Output:
{
  "tools": [
    {
      "tool_name": "analytics_vendors_find",
      "tool_name_check": "pass",
      "tool_parameter_check": "pass",
      "parameter_format_check": "pass",
      "reason": "Tool recognized; provided arguments comply with subset policy; argument value types align with schema expectations; expected_formats: base_location(string)."
    }
  ],
  "overall_reason": "All executed tools conform to their specifications."
}

Example 2 — Incorrect Tool Name

EXPECTED_TOOLS:
{
  "analytics_vendors_find": { }
}

ACTUAL_TOOL_CALLS:
[
  {
    "tool_name": "analytics_vendor_search",
    "parameters": {
      "base_location": "BOSTON"
    }
  }
]

Output:
{
  "tools": [
    {
      "tool_name": "analytics_vendor_search",
      "tool_name_check": "fail",
      "tool_parameter_check": "fail",
      "parameter_format_check": "fail",
      "reason": "Tool not recognized; executed tool is not present in EXPECTED_TOOLS, therefore argument validation and format evaluation cannot be performed."
    }
  ],
  "overall_reason": "At least one executed tool is not defined in EXPECTED_TOOLS."
}

Example 3 — Argument Mismatch (Exact Policy)

EXPECTED_TOOLS:
{
  "analytics_confirmed_order_lookup": {
    "allowed_parameters": ["order_id"],
    "parameter_policy": "exact",
    "strict": false
  }
}

ACTUAL_TOOL_CALLS:
[
  {
    "tool_name": "analytics_confirmed_order_lookup",
    "parameters": {
      "order_id": "123",
      "status": "confirmed"
    }
  }
]

Output:
{
  "tools": [
    {
      "tool_name": "analytics_confirmed_order_lookup",
      "tool_name_check": "pass",
      "tool_parameter_check": "fail",
      "parameter_format_check": "fail",
      "reason": "Tool recognized; provided arguments violate exact policy due to unexpected argument 'status'; expected_formats: order_id(string)."
    }
  ],
  "overall_reason": "One or more executed tools violate argument policy constraints."
}
    """

    user_prompt = f"""
EXPECTED TOOLS:
{json.dumps(expected_tools, indent=2)}

ACTUAL TOOL CALLS:
{json.dumps(actual_tool_calls, indent=2)}
"""

    response = llm.invoke([
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt}
    ])
    
    tokens = count_tokens(response.content)
    track_tokens_used(tokens, eval_name="tool_call_accuracy")

    return json.loads(response.content)





# ============================================================
# STEP 3: PARAMETER FORMAT VALIDATION
# ============================================================

TYPE_CHECKERS = {
    "string": lambda v: isinstance(v, str) and v.strip() != "",
    "int": lambda v: isinstance(v, int),
    "float": lambda v: isinstance(v, float),
    "bool": lambda v: isinstance(v, bool),
    "list": lambda v: isinstance(v, list),
    "dict": lambda v: isinstance(v, dict),
    "null": lambda v: v is None,
    "any": lambda v: True,
    "empty": lambda v: v == "",
}


def build_tool_traceback(tool_name, parameters, tool_spec):

    # --------------------------------------------------
    # 🟢 NEW — UNKNOWN TOOL HANDLING
    # --------------------------------------------------
    tool_unknown = tool_name not in EXPECTED_TOOLS

    allowed = tool_spec.get("allowed_parameters", {})
    structured_params = {}

    for k, v in parameters.items():

        # If tool is unknown → expected format MUST be N/A
        if tool_unknown:
            expected_fmt = "N/A"
        else:
            expected_fmt = allowed.get(k, "any")

        structured_params[k] = {
            "value": v,
            "expected_format": expected_fmt,
        }

    return {
        "tool_name": tool_name,
        "parameters": structured_params,
    }


def validate_parameter_formats(tool_name, parameters, tool_spec):

    expected_formats = tool_spec["allowed_parameters"]

    for param, value in parameters.items():

        expected_type_spec = expected_formats.get(param)
        if not expected_type_spec:
            continue

        allowed_types = expected_type_spec.split("/")

        matched = False

        for t in allowed_types:
            checker = TYPE_CHECKERS.get(t)
            if checker and checker(value):
                matched = True
                break

        if not matched:
            return "fail"

    return "pass"


def attach_format_checks(diagnostics, actual_tool_calls):

    call_map = {c["tool_name"]: c for c in actual_tool_calls}

    for tool_diag in diagnostics["tools"]:

        name = tool_diag["tool_name"]

        # --------------------------------------------------
        # UNKNOWN TOOL → mark N/A
        # --------------------------------------------------
        if name not in EXPECTED_TOOLS:
            tool_diag["tool_parameter_check"] = "N/A"
            tool_diag["parameter_format_check"] = "N/A"
            continue

        # --------------------------------------------------
        # Parameter check failed → skip format check
        # --------------------------------------------------
        if tool_diag.get("tool_parameter_check") != "pass":
            tool_diag["parameter_format_check"] = "N/A"
            continue

        params = call_map.get(name, {}).get("parameters", {})
        spec = EXPECTED_TOOLS.get(name)

        tool_diag["parameter_format_check"] = validate_parameter_formats(
            name,
            params,
            spec,
        )

    return diagnostics


# ============================================================
# STEP 4: NORMALIZATION
# ============================================================

def normalize_pass_fail(diagnostics):

    for tool in diagnostics["tools"]:

        # Unknown tools already N/A
        if tool.get("tool_parameter_check") == "N/A":
            continue

        tool["tool_parameter_check"] = tool.get("tool_parameter_check")
        tool["parameter_format_check"] = tool.get("parameter_format_check")

    return diagnostics


# ============================================================
# STEP 5: SCORING
# ============================================================

def compute_tool_call_score(expected_tools, diagnostics):

    tools = diagnostics.get("tools", [])

    if not tools:
        return 1.0

    passed = 0
    total = len(tools)

    for diag in tools:

        name = diag["tool_name"]
        spec = expected_tools.get(name)

        # Unknown tool = automatic failure
        if not spec:
            continue

        if diag.get("tool_parameter_check") != "pass":
            continue

        if spec["strict"] and diag.get("parameter_format_check") != "pass":
            continue

        passed += 1

    return round(passed / total, 2)


# ============================================================
# ENTRYPOINT
# ============================================================

def run_tool_call_accuracy_eval(trace_id: str, scenario: str, llm: AzureChatOpenAI) -> Dict[str, Any]:

    actual_tool_calls = extract_tool_calls_from_trace(trace_id)

    diagnostics = evaluate_tool_calls(
        EXPECTED_TOOLS,
        actual_tool_calls,
        llm,
    )

    diagnostics = attach_format_checks(diagnostics, actual_tool_calls)
    diagnostics = normalize_pass_fail(diagnostics)

    score = compute_tool_call_score(EXPECTED_TOOLS, diagnostics)

    call_map = {c["tool_name"]: c for c in actual_tool_calls}

    for tool in diagnostics["tools"]:
        name = tool["tool_name"]
        params = call_map.get(name, {}).get("parameters", {})
        spec = EXPECTED_TOOLS.get(name, {})

        # --------------------------------------------
        # BUILD BASE TRACEBACK
        # --------------------------------------------
        tb = build_tool_traceback(
            name,
            params,
            spec,
        )

        # --------------------------------------------
        # 🟢 NEW — ATTACH ACCURACY SIGNALS
        # --------------------------------------------
        tb["tool_name_accuracy"] = tool.get("tool_name_check")
        tb["tool_schema_parameter_accuracy"] = tool.get("tool_parameter_check")
        tb["tool_schema_format_accuracy"] = tool.get("parameter_format_check")
        tb["reason"] = tool.get("reason")

        tool["traceback"] = tb

    return {
        "eval_name": "tool_call_accuracy",
        "eval_type": "hybrid",
        "trace_id": trace_id,
        "scenario": scenario,
        "status": "success",
        "score": score,
        "overall_reason": diagnostics.get("overall_reason", ""),
        "eval_inputs": {
            "expected_tools": EXPECTED_TOOLS,
            "actual_tool_calls": actual_tool_calls,
        },
        "eval_output": diagnostics,
        "metadata": {
            "model": "gpt-5",
            "temperature": 1,
            "timestamp": datetime.utcnow().isoformat(),
        },
    }


# ============================================================
# EXCEL DUMP
# ============================================================

def dump_tool_call_eval_to_excel(
    *,
    trace_id: str,
    query: str,
    eval_result: Dict[str, Any],
    excel_path: str = "final_eval_results.xlsx",
):
    """
    Save tool call accuracy results to Excel.

    Sheet : "Tool Call Accuracy"
    Headers:
        Query | Tool Name | Tool Name accuracy |
        Tool Schema-Parameter Accuracy | Tool Schema-Format Accuracy |
        Reason | Overall Score | Overall Reason | Tracebacks
    """
    from openpyxl import Workbook, load_workbook
    from pathlib import Path

    SHEET_NAME = "Tool Call Accuracy"
    HEADERS = [
        "Query",
        "Tool Name",
        "Tool Name accuracy",
        "Tool Schema-Parameter Accuracy",
        "Tool Schema-Format Accuracy",
        "Reason",
        "Overall Score",
        "Overall Reason",
        "Tracebacks",
    ]

    # Open or create workbook
    if Path(excel_path).exists():
        wb = load_workbook(excel_path)
    else:
        wb = Workbook()
        wb.remove(wb.active)

    # Find or create sheet (case-insensitive match)
    target  = SHEET_NAME.strip().lower()
    matched = next((s for s in wb.sheetnames if s.strip().lower() == target), None)
    if matched is None:
        ws = wb.create_sheet(SHEET_NAME)
        ws.append(HEADERS)
    else:
        ws = wb[matched]

    eval_output    = eval_result.get("eval_output", {})
    tools          = eval_output.get("tools", [])

    overall_score  = eval_result.get("score")
    overall_reason = eval_output.get("overall_reason", "")

    # ---------------------------------
    # If no tools executed
    # ---------------------------------
    if not tools:
        ws.append([
            query,
            None,
            "fail",
            "fail",
            "fail",
            None,
            overall_score,
            overall_reason,
            None,
        ])
        wb.save(excel_path)
        return

    # ---------------------------------
    # One row per tool call
    # ---------------------------------
    for tool in tools:
        ws.append([
            query,
            tool.get("tool_name"),
            tool.get("tool_name_check"),        # pass / fail
            tool.get("tool_parameter_check"),   # pass / fail
            tool.get("parameter_format_check"), # pass / fail
            tool.get("reason"),
            overall_score,
            overall_reason,
            json.dumps(tool.get("traceback"), ensure_ascii=False)
        ])

    wb.save(excel_path)
