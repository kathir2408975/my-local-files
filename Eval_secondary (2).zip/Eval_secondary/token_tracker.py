"""
Token tracking utility for eval modules.
Tracks tokens consumed by LLM calls using tiktoken.
"""

import tiktoken
import threading

# Global token tracking
_total_tokens = 0
_tokens_lock = threading.Lock()
_tokens_per_query = {}
_tokens_per_eval = {}


def count_tokens(text: str) -> int:
    """Count tokens in text using tiktoken (gpt-3.5-turbo encoding)."""
    try:
        encoding = tiktoken.get_encoding("cl100k_base")
        return len(encoding.encode(text))
    except Exception:
        return 0


def track_tokens_used(token_count: int, query: str = None, eval_name: str = None):
    """Track token usage globally, per-query, and per-eval."""
    global _total_tokens
    with _tokens_lock:
        _total_tokens += token_count
        if query:
            if query not in _tokens_per_query:
                _tokens_per_query[query] = 0
            _tokens_per_query[query] += token_count
        if eval_name:
            if eval_name not in _tokens_per_eval:
                _tokens_per_eval[eval_name] = 0
            _tokens_per_eval[eval_name] += token_count


def get_token_stats():
    """Get all token statistics."""
    with _tokens_lock:
        return {
            "total": _total_tokens,
            "per_query": dict(_tokens_per_query),
            "per_eval": dict(_tokens_per_eval),
        }
