"""
Agent Goal Accomplishment + Strict RCA + Root Loop Detection Evaluation Module

This module evaluates:
1. Agent Goal Accomplishment - whether agents fulfilled their responsibilities
2. Root Cause Analysis (RCA) - detailed analysis of failures
3. Loop Detection - identification of retry/oscillation patterns
4. Propagation Chain - tracking how failures propagate downstream

Integration: Called from main.py via orchestration loop with proper Excel logging
"""

import os
import json
from pprint import pprint
from concurrent.futures import ThreadPoolExecutor, as_completed
from langsmith import Client
from langchain_openai import AzureChatOpenAI
from openpyxl import Workbook, load_workbook
from pathlib import Path
from datetime import datetime

# ============================================================
# AGENT SPECIFICATIONS
# ============================================================

AGENT_SPECS = [
    {
        "agent_name": "Supervisor Process",
        "responsibilities": [
            "Route correctly between agents based on workflow phases",
            "Act strictly as orchestration router and never as logistics planner",
            "Collect and validate all mandatory shipment fields from user conversation",
            "Enforce confirmation gate before moving to ContextBuilder",
            "Maintain HumanConversation state whenever waiting for user input",
            "Trigger Analytics workflow for analytical queries and handle clarifications",
            "Reinvoke ContextBuilder when distance or weather context is missing or invalid",
            "Pass complete shipment schema to TaskPlanner after context validation",
            "Reconcile Compliance and Optimization outputs and present plans persuasively",
            "Allow user selection of rejected or non-compliant plans without blocking",
            "Handle execution phase including reconfirmation, email validation, and Execute routing",
            "Normalize conversational flow without exposing internal orchestration details"
        ],
        "input_contract": {
            "state.messages": "Full ordered conversation history including prior agent outputs",
            "last_agent_output": "Latest message from ContextBuilder, TaskPlanner, Compliance, Optimization, Analytics, or Execute",
            "user_intent": "Natural language shipping or analytics request",
            "mandatory_fields": ["item_name", "item_type", "weight", "number_of_boxes", "box_height", "box_width", "box_length", "delivery_date", "base_location", "target_location"]
        },
        "output_contract": {
            "allowed_output_shapes": [
                {
                    "next": "One of HumanConversation, Analytics, ContextBuilder, TaskPlanner, Execute, FINISH",
                    "reply_to_user": "Natural conversational response aligned with workflow phase",
                    "note_for_agent": "Single concise internal instruction containing structured task context (optional)",
                    "reason": "Detailed justification describing routing decision logic"
                },
                {
                    "output": {
                        "next": "One of HumanConversation, Analytics, ContextBuilder, TaskPlanner, Execute, FINISH",
                        "reply_to_user": "Natural conversational response aligned with workflow phase",
                        "note_for_agent": "Single concise internal instruction (optional)",
                        "reason": "Detailed justification describing routing decision logic"
                    }
                }
            ],
            "execution_note": "Supervisor responses MAY be wrapped inside a top-level 'output' object."
        },
        "assumptions": [
            "Supervisor does not possess planning, pricing, or vendor knowledge",
            "Downstream agents follow their own contracts and schemas",
            "Conversation memory is reliable and ordered",
            "User intent remains authoritative and should not be altered",
            "Non-compliant plans can still be executed if selected by user",
            "HumanConversation represents waiting state rather than processing state"
        ],
        "forbidden_actions": [
            "Generating shipping plans, vendor lists, or cost estimates",
            "Skipping confirmation gate when mandatory fields are present",
            "Blocking user-selected rejected plans",
            "Exposing internal orchestration or routing logic to the user",
            "Proceeding to ContextBuilder before explicit user confirmation",
            "Ignoring missing or invalid context returned from ContextBuilder"
        ]
    },
    {
        "agent_name": "Context Builder Agent",
        "responsibilities": [
            "Fetch vendor information for the provided base_location using Fetch Vendors Tool",
            "Fetch vendor order history for the provided base_location using Fetch Performance History tool",
            "Retrieve distance between base_location and target_location using Web Search Tool",
            "Retrieve weather information for the shipping route using Web Search Tool",
            "Identify events or holidays affecting delivery_date using Web Search Tool",
            "Aggregate all retrieved information into a one-line JSON summary"
        ],
        "input_contract": {
            "base_location": "string provided by Supervisor",
            "target_location": "string provided by Supervisor",
            "delivery_date": "date string provided by Supervisor"
        },
        "output_contract": {
            "summary_json": "One-line proper JSON containing vendors, order_history, distance, weather, and event information"
        },
        "assumptions": [
            "Supervisor provides valid base_location, target_location, and delivery_date",
            "Tools return usable structured or textual information",
            "Web search queries must follow exact phrasing defined in the prompt",
            "Agent may call multiple tools sequentially to gather context"
        ],
        "forbidden_actions": [
            "Calling Web Search Tool more than 15 times",
            "Calling Fetch Vendors Tool more than twice",
            "Calling Fetch Performance History tool more than twice"
        ]
    },
    {
        "agent_name": "Context Builder Summarization Process",
        "responsibilities": [
            "Extract distance information between base and target location from provided message",
            "Extract overall route weather condition from the provided information",
            "Identify any shipping-impacting event or holiday relevant to the delivery date",
            "Ignore vendor details and order history while summarizing context",
            "Normalize extracted values into the required structured JSON schema",
            "Return only distance, weather, and event fields in strict schema format"
        ],
        "input_contract": {
            "vendors": "Contextual vendor information that must be ignored during summarization",
            "order_history": "Historical order data that must be ignored during summarization",
            "distance": "Distance between source and destination locations within the message",
            "weather": "Overall weather condition across the shipping route",
            "event": "Potential seasonal event or holiday affecting logistics cost or operations"
        },
        "output_contract": {
            "allowed_output_shapes": [
                {
                    "distance": "String — numeric distance value in kilometers",
                    "weather": "String — one of [sunny, cloudy, rainy, snowy, windy, foggy, stormy, thunderstorm]",
                    "event": "String — single event/holiday name or 'No Event' if none exists"
                },
                {
                    "output": {
                        "distance": "String — numeric distance value in kilometers",
                        "weather": "String — one of [sunny, cloudy, rainy, snowy, windy, foggy, stormy, thunderstorm]",
                        "event": "String — single event/holiday name or 'No Event'"
                    }
                }
            ],
            "execution_note": "Responses MAY be wrapped inside a top-level 'output' object."
        },
        "assumptions": [
            "Input message contains contextual logistics information including distance, weather, or event data",
            "Weather must be normalized into one of the predefined categories",
            "Event should be reduced to a single relevant name or defaulted to 'No Event'",
            "Distance value should be returned as a string containing only the numeric km value"
        ],
        "forbidden_actions": [
            "Including vendor or order history data in the output",
            "Adding fields beyond distance, weather, and event (except permitted 'output' wrapper)",
            "Returning explanations, markdown, or additional text beyond the JSON schema",
            "Using weather categories outside the predefined allowed list"
        ]
    },
    {
        "agent_name": "TaskPlanner Process",
        "responsibilities": [
            "Extract structured shipment fields from Supervisor instructions",
            "Normalize shipment attributes into schema-compliant string values",
            "Preserve original user intent without modification",
            "Map shipment data into routing_memory-compatible structure",
            "Produce a single valid JSON object matching the required schema"
        ],
        "input_contract": {
            "shipment_description": "Structured instruction from Supervisor containing all mandatory shipment fields",
            "note_for_agent": "Supervisor-provided normalized shipment details",
            "state.messages": "Conversation context already validated by Supervisor"
        },
        "output_contract": {
            "output": {
                "item_name": "String",
                "weight": "Numeric string (kg per box)",
                "base_location": "Allowed warehouse base",
                "target_location": "Destination city",
                "item_type": "Fragile | Frozen | Food | Normal",
                "box_height": "Numeric string (cm)",
                "box_width": "Numeric string (cm)",
                "box_length": "Numeric string (cm)",
                "no_of_boxes": "Numeric string",
                "delivery_date": "YYYY-MM-DD string"
            }
        },
        "assumptions": [
            "Supervisor has already collected and validated mandatory fields",
            "Input contains authoritative user data that must not be altered",
            "Numeric fields must be represented strictly as numeric strings",
            "Locations are already normalized by Supervisor",
            "Agent should not infer values not explicitly provided"
        ],
        "forbidden_actions": [
            "Inferring or guessing missing shipment fields",
            "Changing or reinterpreting user-provided values",
            "Adding units or extra formatting to numeric fields",
            "Returning empty or placeholder values when valid input exists",
            "Producing explanations or text outside the JSON schema",
            "Generating planning logic, vendor selection, or routing decisions"
        ]
    },
    {
        "agent_name": "Forecast process",
        "responsibilities": [
            "Map weather conditions into numeric weather_cost using defined policy",
            "Map event descriptions into numeric event_cost using keyword rules",
            "Compute total_extra by invoking Calculate Extra Charges Tool",
            "Invoke delivery cost tool using vendor IDs and computed extra charges",
            "Invoke delivery time tool to obtain estimated delivery dates",
            "Invoke forecast confidence tool using calculated outputs",
            "Execute tool calls strictly in the required order",
            "Produce a machine-friendly forecast result JSON"
        ],
        "input_contract": {
            "vendor_id_1": "Integer vendor identifier",
            "vendor_id_2": "Integer or empty string",
            "weather": "One of allowed weather values",
            "event": "Event name or 'No Event'",
            "delivery_type": "full | partial",
            "context_memory.json": "Environmental and vendor routing context",
            "routing_memory.json": "Candidate routing combinations"
        },
        "output_contract": {
            "forecast_results": {
                "vendor_id_1": "Integer",
                "vendor_id_2": "Integer or empty string",
                "weather": "String",
                "event": "String",
                "weather_cost": "Integer [0-50]",
                "event_cost": "Integer [0-50]",
                "total_extra": "Integer",
                "estimated_cost": "Number",
                "estimated_date_1": "YYYY-MM-DD",
                "estimated_date_2": "YYYY-MM-DD or empty string",
                "confidence": "Float"
            },
            "error": "Optional short error message when tool failure occurs"
        },
        "assumptions": [
            "Weather values always belong to the allowed enumeration",
            "Event classification keywords determine cost levels",
            "Tools return deterministic outputs",
            "Vendor IDs are already validated upstream",
            "Routing combinations are precomputed before Forecast executes"
        ],
        "forbidden_actions": [
            "Skipping or reordering tool calls",
            "Inventing estimated cost, dates, or confidence values",
            "Producing analysis text outside the JSON response",
            "Using weather/event mappings outside defined policy",
            "Returning multiple JSON objects",
            "Executing tools more than once per routing combo"
        ]
    },
    {
        "agent_name": "Optimization Process",
        "responsibilities": [
            "Identify the best plan where rank_overall equals 1",
            "Generate a concise explanation (1–2 sentences) for every candidate plan",
            "Preserve all candidate ranking and scoring information semantically",
            "Produce a user-facing summary highlighting the best options",
            "Return a structured optimization output strictly matching schema"
        ],
        "input_contract": {
            "optimization_candidates": "Array of ranked routing plans",
            "forecast_results": "Forecasted delivery estimates and cost outputs",
            "context_memory.json": "Distance, weather, and event context"
        },
        "output_contract": {
            "output": {
                "agent": "Optimization",
                "best_plan_id": "String where rank_overall == 1",
                "candidates": "Array of OptimizationCandidate objects with explanations",
                "summary_for_user": "Natural-language summary describing best options"
            }
        },
        "assumptions": [
            "Candidates already contain ranking fields",
            "Utility and ranking scores are computed upstream",
            "Optimization does not calculate costs or forecasts itself",
            "Every candidate requires an explanation regardless of ranking"
        ],
        "forbidden_actions": [
            "Re-ranking candidates or recomputing utility scores",
            "Changing ranking logic or altering the semantic meaning of candidate metrics",
            "Returning partial candidate arrays",
            "Producing text outside the JSON structure",
            "Skipping explanation generation for any candidate"
        ]
    },
    {
        "agent_name": "Compliance Process",
        "responsibilities": [
            "Generate a concise compliance summary for the supervisor",
            "Provide a 3–6 sentence explanation of compliance outcome",
            "Summarize plan approval or rejection context for downstream routing",
            "Return a machine-readable JSON response strictly matching schema"
        ],
        "input_contract": {
            "optimization_output": "Ranked candidate plans with compliance context",
            "forecast_results": "Delivery estimates and risk indicators",
            "context_memory.json": "Weather, distance, and event information"
        },
        "output_contract": {
            "allowed_output_shapes": [
                {
                    "compliance_output": {
                        "summary_for_supervisor": "Short compliance explanation (3–6 sentences)"
                    }
                },
                {
                    "output": {
                        "summary_for_supervisor": "Short compliance explanation (3–6 sentences)"
                    }
                }
            ],
            "execution_note": "Compliance responses MAY be wrapped inside a top-level 'output' object."
        },
        "assumptions": [
            "Optimization has already ranked candidates",
            "Compliance logic or checks are performed prior to this summarization step",
            "Supervisor will use this summary to present or reconcile plans"
        ],
        "forbidden_actions": [
            "Generating vendor plans or modifying optimization rankings",
            "Producing text outside the JSON object",
            "Performing routing decisions meant for Supervisor"
        ]
    },
    {
        "agent_name": "Execute Tool Calling Process",
        "responsibilities": [
            "Fetch plan information using the provided plan_id",
            "Determine whether delivery is Full or Partial based on plan summary",
            "Save confirmed order to database and extract order_id",
            "Compose structured HTML confirmation email",
            "Call Send Mail Tool to complete fulfillment cycle",
            "Return final execution confirmation JSON"
        ],
        "input_contract": {
            "plan_id": "Non-empty string identifying selected plan",
            "useremailid": "Valid email address string"
        },
        "output_contract": {
            "status": "ok",
            "plan_id": "String",
            "order_id": "Generated order identifier",
            "useremail": "Email used for confirmation"
        },
        "assumptions": [
            "Plan information tool returns structured delivery details",
            "Order save tool returns a valid order_id",
            "Email tool accepts HTML content and completes delivery"
        ],
        "forbidden_actions": [
            "Stopping after generating email text without calling send_mail tool",
            "Skipping save_confirmed_order step",
            "Returning explanations or extra text outside JSON",
            "Modifying plan details instead of using fetched information"
        ]
    },
    {
        "agent_name": "Execute Process",
        "responsibilities": [
            "Extract PLAN_ID exactly as selected by the user",
            "Extract USER_EMAIL exactly as confirmed by the user",
            "Summarize the request by mapping extracted values into the required JSON schema",
            "Return only the structured JSON containing PLAN_ID and USER_EMAIL",
            "Ensure output conforms to allowed schema shapes without additional narrative text"
        ],
        "input_contract": {
            "PLAN_ID": "String representing the exact selected plan identifier",
            "USER_EMAIL": "Confirmed user email address string extracted from message"
        },
        "output_contract": {
            "allowed_output_shapes": [
                {
                    "PLAN_ID": "String — exact plan identifier selected by the user",
                    "USER_EMAIL": "String — confirmed user email address"
                },
                {
                    "output": {
                        "PLAN_ID": "String — exact plan identifier selected by the user",
                        "USER_EMAIL": "String — confirmed user email address"
                    }
                }
            ],
            "execution_note": "The structured result MAY be wrapped inside a top-level 'output' field."
        },
        "assumptions": [
            "Incoming messages contain both plan selection information and a valid email address",
            "PLAN_ID and USER_EMAIL appear explicitly in the conversation context",
            "The agent acts only as a summarizer and does not modify values"
        ],
        "forbidden_actions": [
            "Generating explanations or additional text outside the JSON schema",
            "Altering or inferring PLAN_ID or USER_EMAIL values",
            "Adding fields beyond PLAN_ID and USER_EMAIL (except permitted 'output' wrapper)",
            "Returning multiple unrelated objects or narrative content"
        ]
    },
    {
        "agent_name": "Analytics",
        "responsibilities": [
            "Answer analytical questions using database tools",
            "Select the correct analytics tool based on user intent",
            "Ask for clarification when location or query context is ambiguous",
            "Return concise summaries of retrieved analytical data"
        ],
        "input_contract": {
            "user_query": "Natural language analytical question from user",
            "conversation_context": "Prior messages used to infer missing details"
        },
        "output_contract": {
            "analytics_response": "Concise natural language summary of tool results or clarification question"
        },
        "assumptions": [
            "Database tools return structured and accurate data",
            "Supervisor provides properly routed analytical queries",
            "Conversation context may contain missing parameters"
        ],
        "forbidden_actions": [
            "Using analytics_vendors_find for general location listing",
            "Guessing missing parameters such as city or vendor",
            "Calling incorrect tools for the question type",
            "Returning raw database outputs without summarization"
        ]
    }
]

# ============================================================
# VIOLATION CATEGORIES
# ============================================================

VIOLATION_CATEGORIES = {
    "Routing Failure": (
        "Agent violated expected workflow trajectory or routing logic. "
        "Example: expected A→B→C but agent routed A→C→E or skipped required phase."
    ),
    "Intent Recognition Failure": (
        "Agent misunderstood user or upstream agent intent, leading to "
        "incorrect interpretation of task or requirements."
    ),
    "Tool/API Mapping Failure (Schema)": (
        "Agent failed to invoke tools/APIs correctly or produced invalid "
        "schema/parameters required for downstream execution."
    ),
    "Agent Decision Failure": (
        "Agent made an incorrect internal decision despite having correct "
        "inputs and context (e.g., skipped steps, wrong reasoning choice)."
    ),
    "Context Misuse Failure": (
        "Agent ignored, corrupted, or misused available context, memory, "
        "or upstream outputs while making decisions."
    )
}

# ============================================================
# GLOBAL CONFIG
# ============================================================

SME_INSTRUCTIONS = "If you encounter any Supervisor->HumanConversation->Supervisor->HumanConversation, ignore it."
RCA_CONTEXT_GUIDELINES = ""

# ============================================================
# HELPER FUNCTIONS
# ============================================================

def extract_agent_spec_fragment(agent_name, agent_specs):
    """Extract key agent specification fragments"""
    spec = next((s for s in agent_specs if s["agent_name"] == agent_name), None)
    
    if not spec:
        return "N/A"
    
    fragments = []
    fragments += spec.get("responsibilities", [])[:2]
    fragments += spec.get("forbidden_actions", [])[:1]
    
    return " | ".join(fragments) if fragments else "N/A"


def extract_problematic_output(run_id, run_lookup):
    """Extract the actual output that failed"""
    span = run_lookup.get(run_id, {})
    outputs = span.get("outputs", {})
    
    try:
        return json.dumps(outputs, indent=2)
    except:
        return str(outputs)


def build_goal_eval_prompt(agent_spec, span):
    """Build the goal accomplishment evaluation prompt"""
    return f"""
You are performing **AGENT GOAL ACCOMPLISHMENT EVALUATION**.

ROLE:
You are an AI evaluation system that determines whether an agent
successfully fulfilled its operational responsibilities during execution.

PRIMARY OBJECTIVE:
Evaluate semantic success based strictly on:
- agent RESPONSIBILITIES
- INPUT CONTRACT
- OUTPUT CONTRACT
- ASSUMPTIONS
- FORBIDDEN_ACTIONS
- observed INPUTS and OUTPUTS

CORE EVALUATION PRINCIPLES
- Judge semantic behavior, NOT stylistic quality.
- Output Contract discipline IS part of semantic behaviour.
- If agent produces content OUTSIDE defined OUTPUT CONTRACT, this is FAILURE.
- Do NOT assume hidden workflow logic.

CRITICAL EXECUTION CONTRACT RULES (STRICT)

The following are SEMANTIC FAILURES even if routing logic is correct:

1. Output contains reasoning text, analysis, or internal thoughts
   that are NOT part of the OUTPUT CONTRACT fields.

2. Output includes explanations before or after the structured response.

3. Agent leaks orchestration reasoning or hidden planning steps.

4. Output violates STRICT OUTPUT FORMAT instructions.

5. Downstream execution would fail because OUTPUTS do not strictly
   conform to the OUTPUT CONTRACT fields.

If ANY of above occur: verdict MUST be 0.0

AGENT CONTRACT
RESPONSIBILITIES:
{json.dumps(agent_spec.get("responsibilities", []), indent=2)}

INPUT CONTRACT:
{json.dumps(agent_spec.get("input_contract", {}), indent=2)}

OUTPUT CONTRACT:
{json.dumps(agent_spec.get("output_contract", {}), indent=2)}

ASSUMPTIONS:
{json.dumps(agent_spec.get("assumptions", []), indent=2)}

FORBIDDEN_ACTIONS:
{json.dumps(agent_spec.get("forbidden_actions", []), indent=2)}

ACTUAL EXECUTION
INPUTS:
{json.dumps(span["inputs"], indent=2)}

OUTPUTS:
{json.dumps(span["outputs"], indent=2)}

EVALUATION FRAMEWORK
STEP 1: Infer the agent's operational role (routing/transformation/validation/mixed)
STEP 2: Check whether OUTPUTS satisfy OUTPUT CONTRACT fields
STEP 3: Validate EXECUTION CONTRACT discipline:
  - Does output contain ONLY allowed fields?
  - Does output avoid internal reasoning text?
  - Would downstream parsing succeed?
STEP 4: Evaluate responsibility fulfillment
STEP 5: Check FORBIDDEN_ACTIONS
STEP 6: Assess accomplishment level:
  1.0 → Full accomplishment: Responsibilities fulfilled AND execution contract respected
  0.5 → Partial accomplishment: Some duties missed
  0.0 → Failure: Responsibilities not executed OR execution contract violated
STEP 7: Set goal_failed based on verdict

OUTPUT FORMAT
Return ONLY JSON:

{{
 "verdict": number,
 "goal_failed": boolean,
 "reason": "2-3 line operational reasoning referencing responsibilities"
}}
"""


def evaluate_span(span, agent_specs, llm):
    """Evaluate a single agent span"""
    agent_spec = next(
        (spec for spec in agent_specs if spec["agent_name"] == span["agent_name"]),
        None
    )
    
    if not agent_spec:
        return None
    
    try:
        prompt = build_goal_eval_prompt(agent_spec, span)
        evaluation = json.loads(llm.invoke(prompt).content)
        
        return {
            "agent_name": span["agent_name"],
            "run_id": span["run_id"],
            "verdict": evaluation.get("verdict", 0),
            "goal_failed": evaluation.get("goal_failed", True),
            "reason": evaluation.get("reason", "")
        }
    except Exception as e:
        print(f"Eval failed for {span['agent_name']}: {e}")
        return None


def build_rca_prompt(fail, violation_categories, rca_context_guidelines=""):
    """Build the RCA prompt"""
    return f"""
You are performing ROOT CAUSE ANALYSIS (RCA) on an agent failure.

PRIMARY OBJECTIVE:
Determine the TRUE behavioural cause of failure based only on:
- violation categories
- failed agent responsibilities
- observed failure summary

Violation Categories:
{json.dumps(violation_categories, indent=2)}

FAILED AGENT:
{fail["agent_name"]}

FAILURE SUMMARY:
{fail["reason"]}

Analysis Instructions:

Core Evaluation Rules:
- Identify the precise behavioural mistake made by the agent.
- Focus on semantic behaviour, not formatting.
- Root cause must be concise, precise, and grounded in observable behaviour.
- Do NOT speculate about internal system implementation.

Global RCA Guardrails:

- Do NOT treat naming variations as failures if semantic meaning is equivalent.
- Do NOT penalize intermediate orchestration phases.
- Do NOT assume fields are mandatory unless explicitly defined.
- Prefer "Logic Failure" when behaviour deviates from intended reasoning.
- Prefer "Intent Corruption" when user-provided values are altered.
- Use minimal, evidence-based explanations.

Few Shot Examples:

Example 1:
Input weight="12", Output weight=""
Result:
{{"failure_category":"Logic Failure","root_cause":"Agent ignored provided weight=12 and produced empty output, breaking transformation behaviour."}}

Example 2:
Agent invents no_of_boxes=5 when input says 3
Result:
{{"failure_category":"Intent Corruption","root_cause":"Input no_of_boxes=3 but agent generated 5, modifying user intent."}}

Output Requirements:

Return ONLY JSON:

{{
 "failure_category":"string",
 "root_cause":"2-4 lines maximum explanation referencing observable behavioural differences"
}}
"""


def flatten(obj):
    """Convert nested dict/list into normalized string for boundary checks"""
    try:
        return json.dumps(obj, ensure_ascii=False).lower()
    except Exception:
        return str(obj).lower()


def llm_detect_propagation(failed_output, downstream_span, llm):
    """Use LLM to detect if failure propagated downstream"""
    prompt = f"""
You are a STRICT FAILURE PROPAGATION DETECTOR.

FAILED AGENT OUTPUT:
{json.dumps(failed_output, indent=2)}

DOWNSTREAM SPAN INPUTS:
{json.dumps(downstream_span.get("inputs", {}), indent=2)}

DOWNSTREAM SPAN OUTPUTS:
{json.dumps(downstream_span.get("outputs", {}), indent=2)}

STRICT RULES:

- Look for SEMANTIC reuse, not exact string match.
- Downstream agents may paraphrase, summarize, or embed values inside text.
- ONLY mark propagation if the SAME WRONG VALUE appears again.
- Do NOT assume corrections.
- If unsure → return "No".

Return ONLY JSON:

{{
  "propagated": "Yes | No",
  "reason": "short explanation"
}}
"""
    
    try:
        resp = llm.invoke(prompt)
        parsed = json.loads(resp.content)
        return parsed
    except Exception:
        return {"propagated": "No", "reason": "LLM parse failure"}


def build_loop_prompt(root_level_spans, sme_instructions=""):
    """Build the loop detection prompt"""
    return f"""
You are performing WORKFLOW LOOP DETECTION on an orchestration trajectory.

Primary Objective:
Identify retry behaviour, repeated agent execution, and oscillation patterns
using ONLY the provided ROOT LEVEL TRAJECTORY.

SME Instructions (Optional):
{sme_instructions if sme_instructions else "None"}

ROOT LEVEL TRAJECTORY:
{json.dumps(root_level_spans, indent=2)}

Core Rules (STRICT):

- Use ONLY the provided trajectory.
- Do NOT invent spans or agents.
- Do NOT infer hidden steps.
- Supervisor is NEVER treated as the looping agent.
- Count loops only when patterns are explicitly visible.
- span_ids MUST come directly from trajectory entries.
- If no loop exists, return an empty loops list.

Loop Definitions (Operational):

TYPE 1 — Direct Loop:
Same agent appears consecutively three or more times.

TYPE 2 — Supervisor Retry Loop:
Supervisor repeatedly routes execution back to the same agent.
Pattern: Supervisor → X → Supervisor → X
Loop Agent = X (Supervisor is orchestration glue)

TYPE 3 — Oscillation Loop:
Alternating execution between two agents.
Pattern: A → B → A → B → A

Detection Rules:

1. Identify Direct Loops first.
2. Then detect Supervisor Retry Loops.
3. Then detect Oscillation Loops.
4. Do NOT double-count the same spans.
5. Ignore single re-invocations — loops require repetition patterns.

Output Requirements:

Return ONLY JSON:

{{
 "loops":[
  {{
   "agent_name":"string",
   "loop_count":number,
   "span_ids":["string"],
   "reason":"short structural explanation"
  }}
 ]
}}
"""


# ============================================================
# MAIN EVALUATION FUNCTION
# ============================================================

def evaluate_agent_goal_accomplishment_rca_loop(
    trace_id: str,
    query: str,
    output_excel_path: str = "final_eval_results.xlsx",
    llm=None,
    langsmith_client=None
):
    """
    Main evaluation function orchestrating:
    - Goal Accomplishment evaluation
    - RCA analysis
    - Loop detection
    - Propagation chain tracking
    - Excel logging
    """
    
    # ============================================================
    # STEP 1 — FETCH TRACE
    # ============================================================
    
    spans = list(langsmith_client.list_runs(trace_id=trace_id))
    spans = sorted(spans, key=lambda s: s.start_time or 0)
    
    execution_trace = []
    run_lookup = {}
    root_level_spans = []
    
    for s in spans:
        run_id = str(s.id)
        parent_id = str(s.parent_run_id) if s.parent_run_id else None
        run_type = getattr(s, "run_type", None)
        
        run_lookup[run_id] = {
            "name": s.name,
            "inputs": s.inputs or {},
            "outputs": s.outputs or {},
            "parent": parent_id,
            "run_type": run_type
        }
        
        if parent_id == trace_id:
            root_level_spans.append({
                "agent_name": s.name,
                "run_id": run_id,
                "run_type": run_type,
                "inputs": s.inputs or {},
                "outputs": s.outputs or {}
            })
        
        if run_type == "chain":
            execution_trace.append({
                "agent_name": s.name,
                "run_id": run_id,
                "inputs": s.inputs or {},
                "outputs": s.outputs or {}
            })
    
    print("\nDetected chain-type agents:")
    print([x["agent_name"] for x in execution_trace])
    
    # ============================================================
    # STEP 2 — PARALLEL GOAL EVALUATION
    # ============================================================
    
    results = []
    with ThreadPoolExecutor(max_workers=6) as executor:
        futures = [executor.submit(evaluate_span, span, AGENT_SPECS, llm) for span in execution_trace]
        for f in as_completed(futures):
            r = f.result()
            if r:
                results.append(r)
    
    print("\n================ GOAL EVAL RESULTS ================\n")
    pprint(results)
    
    # ============================================================
    # STEP 3 — STRICT RCA ANALYSIS
    # ============================================================
    
    failed_agents = [r for r in results if r["goal_failed"]]
    deep_rca = []
    
    for fail in failed_agents:
        try:
            rca_prompt = build_rca_prompt(fail, VIOLATION_CATEGORIES, RCA_CONTEXT_GUIDELINES)
            analysis = json.loads(llm.invoke(rca_prompt).content)
            
            deep_rca.append({
                "agent_name": fail["agent_name"],
                "span_id": fail["run_id"],
                "failure_category": analysis.get("failure_category", "Unknown"),
                "root_cause": analysis.get("root_cause", ""),
                "agent_spec_fragment": extract_agent_spec_fragment(fail["agent_name"], AGENT_SPECS),
                "actual_problematic_output": extract_problematic_output(fail["run_id"], run_lookup),
                "propagation_chain": "N/A"
            })
        except Exception as e:
            print(f"RCA failed for {fail['agent_name']}: {e}")
    
    # ============================================================
    # STEP 4 — PROPAGATION CHAIN DETECTION
    # ============================================================
    
    root_index_map = {s["run_id"]: i for i, s in enumerate(root_level_spans)}
    
    for rca in deep_rca:
        error_id = rca["span_id"]
        error_span = run_lookup.get(error_id, {})
        parent_id = error_span.get("parent")
        
        if not parent_id:
            rca["propagation_chain"] = "N/A"
            continue
        
        failed_output = error_span.get("outputs", {})
        
        if not failed_output:
            rca["propagation_chain"] = "N/A"
            continue
        
        parent_output = flatten(run_lookup.get(parent_id, {}).get("outputs", {}))
        failed_flat = flatten(failed_output)
        
        if failed_flat not in parent_output:
            rca["propagation_chain"] = "N/A"
            continue
        
        start_idx = root_index_map.get(parent_id)
        
        if start_idx is None:
            rca["propagation_chain"] = "N/A"
            continue
        
        propagation = []
        
        for next_span in root_level_spans[start_idx + 1:]:
            decision = llm_detect_propagation(failed_output, next_span, llm)
            
            if decision.get("propagated") == "Yes":
                propagation.append({
                    "span_name": next_span["agent_name"],
                    "span_id": next_span["run_id"],
                    "reason": decision.get("reason", "")
                })
        
        rca["propagation_chain"] = propagation if propagation else "N/A"
    
    print("\n================ DEEP RCA RESULTS ================\n")
    pprint(deep_rca)
    
    # ============================================================
    # STEP 5 — LOOP DETECTION
    # ============================================================
    
    try:
        loop_prompt = build_loop_prompt(root_level_spans, SME_INSTRUCTIONS)
        loop_result = json.loads(llm.invoke(loop_prompt).content)
    except Exception as e:
        print(f"Loop detection failed: {e}")
        loop_result = {"loops": []}
    
    # ============================================================
    # STEP 6 — RCA-AWARE LOOP ENRICHMENT
    # ============================================================
    
    rca_lookup = {r["span_id"]: r["root_cause"] for r in deep_rca}
    
    def get_children(parent_id):
        children = []
        for run_id, data in run_lookup.items():
            if data.get("parent") == parent_id:
                children.append(run_id)
        return children
    
    final_loops = []
    
    for loop in loop_result.get("loops", []):
        if "Supervisor" in loop["agent_name"]:
            continue
        
        collected_reasons = []
        
        for parent_span_id in loop["span_ids"]:
            child_ids = get_children(parent_span_id)
            for cid in child_ids:
                if cid in rca_lookup:
                    collected_reasons.append(rca_lookup[cid])
        
        if collected_reasons:
            seen = set()
            unique = []
            for r in collected_reasons:
                if r not in seen:
                    unique.append(r)
                    seen.add(r)
            
            enriched_reason = (
                f"{loop['agent_name']} entered retry loop because its execution children repeatedly failed. "
                f"Observed RCA causes: " + " | ".join(unique[:2])
            )
        else:
            enriched_reason = "Retry loop detected from trajectory pattern; no RCA child failures mapped."
        
        final_loops.append({
            "agent_name": loop["agent_name"],
            "loop_count": loop["loop_count"],
            "span_ids": loop["span_ids"],
            "reason": enriched_reason
        })
    
    print("\n================ LOOP DETECTION RESULT ================\n")
    pprint({"loops": final_loops})
    
    # ============================================================
    # STEP 7 — EXCEL LOGGING
    # ============================================================
    
    _dump_rca_to_excel(
        query=query,
        trace_id=trace_id,
        deep_rca=deep_rca,
        final_loops=final_loops,
        excel_path=output_excel_path
    )
    
    return {
        "goal_evals": results,
        "rca_analysis": deep_rca,
        "loop_detection": final_loops
    }


# ============================================================
# EXCEL LOGGER
# ============================================================

def _dump_rca_to_excel(
    query: str,
    trace_id: str,
    deep_rca: list,
    final_loops: list,
    excel_path: str = "final_eval_results.xlsx"
):
    """Log RCA and loop results to Excel"""
    
    SHEET_NAME = "RCA"
    
    if Path(excel_path).exists():
        wb = load_workbook(excel_path)
    else:
        wb = Workbook()
    
    if SHEET_NAME in wb.sheetnames:
        ws = wb[SHEET_NAME]
    else:
        ws = wb.create_sheet(SHEET_NAME)
        
        ws.append([
            "Query",
            "Trace_ID",
            "Failure Agent Name",
            "Failure Category",
            "Agent Spec Fragment",
            "Actual Problematic Output",
            "Propagation Chain",
            "Root Cause",
            "Span Id",
            "Looping Agent",
            "Loop Count",
            "Loop Reason",
            "Loop Span Ids"
        ])
    
    loops = final_loops
    max_rows = max(len(deep_rca), len(loops)) if (deep_rca or loops) else 0
    
    for i in range(max_rows):
        # RCA data
        if i < len(deep_rca):
            rca = deep_rca[i]
            failure_agent_name = rca.get("agent_name", "")
            failure_category = rca.get("failure_category", "")
            root_cause = rca.get("root_cause", "")
            span_id = rca.get("span_id", "")
            agent_spec_fragment = rca.get("agent_spec_fragment", "")
            actual_problematic_output = rca.get("actual_problematic_output", "")
            
            propagation_chain = rca.get("propagation_chain", "N/A")
            if isinstance(propagation_chain, list):
                propagation_chain = json.dumps(propagation_chain)
        else:
            failure_agent_name = ""
            failure_category = ""
            root_cause = ""
            span_id = ""
            agent_spec_fragment = ""
            actual_problematic_output = ""
            propagation_chain = ""
        
        # Loop data
        if i < len(loops):
            loop = loops[i]
            looping_agent = loop.get("agent_name", "")
            loop_count = loop.get("loop_count", "")
            loop_reason = loop.get("reason", "")
            loop_span_ids = ",".join(loop.get("span_ids", []))
        else:
            looping_agent = ""
            loop_count = ""
            loop_reason = ""
            loop_span_ids = ""
        
        # Append row
        ws.append([
            query,
            trace_id,
            failure_agent_name,
            failure_category,
            agent_spec_fragment,
            actual_problematic_output,
            propagation_chain,
            root_cause,
            span_id,
            looping_agent,
            loop_count,
            loop_reason,
            loop_span_ids
        ])
    
    wb.save(excel_path)
    print(f"✅ RCA sheet updated successfully in {excel_path}")
