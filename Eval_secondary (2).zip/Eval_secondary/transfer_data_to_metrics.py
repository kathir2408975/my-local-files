"""
Transfer evaluation data from final_eval_results.xlsx to Detailed_Log.xlsx and Metrics_template.xlsx

This script:
1. Copy all evaluation sheets from final_eval_results.xlsx to Detailed_Log.xlsx
2. Create Test_Data sheet in Metrics_template.xlsx with extracted scores/reasons
3. Copy Universal Critique Judge sheet to Secondary LLM in Metrics_template.xlsx
"""

from pathlib import Path
from openpyxl import load_workbook, Workbook


def copy_eval_sheets_to_detailed_log(source_path: str, dest_path: str):
    """
    Copy evaluation sheets from final_eval_results.xlsx to Detailed_Log.xlsx
    Maps sheet names and copies all data
    """
    if not Path(source_path).exists():
        print(f"[WARN] {source_path} not found")
        return False
    
    try:
        print(f"\n[STEP 1] Copying evaluation sheets to Detailed_Log.xlsx...")
        
        src_wb = load_workbook(source_path)
        
        # Load or create destination
        if Path(dest_path).exists():
            dst_wb = load_workbook(dest_path)
        else:
            dst_wb = Workbook()
            if "Sheet" in dst_wb.sheetnames:
                del dst_wb["Sheet"]
        
        # Copy all evaluation sheets (exclude Universal Critique Judge - will handle separately)
        for src_sheet_name in src_wb.sheetnames:
            # Skip the judge sheet
            if src_sheet_name == "Universal Critique Judge":
                continue
            
            src_sheet = src_wb[src_sheet_name]
            
            # Delete existing sheet if present
            if src_sheet_name in dst_wb.sheetnames:
                del dst_wb[src_sheet_name]
            
            # Create new sheet
            dst_sheet = dst_wb.create_sheet(src_sheet_name)
            
            # Copy all rows
            for row in src_sheet.iter_rows(values_only=True):
                dst_sheet.append(list(row))
            
            print(f"     ✓ {src_sheet_name}: {src_sheet.max_row} rows")
        
        dst_wb.save(dest_path)
        dst_wb.close()
        src_wb.close()
        
        print(f"  [OK] All evaluation sheets mapped to Detailed_Log.xlsx")
        return True
        
    except Exception as e:
        print(f"[ERROR] Failed to copy sheets: {e}")
        import traceback
        traceback.print_exc()
        return False


def create_test_data_sheet(source_path: str, dest_path: str):
    """
    Extract overall_score and overall_reason from each evaluation sheet in final_eval_results.xlsx
    Create Test_Data sheet in Metrics_template.xlsx with scores mapped to proper columns
    """
    if not Path(source_path).exists():
        print(f"[WARN] {source_path} not found")
        return False
    
    try:
        print(f"\n[STEP 2] Creating Test_Data sheet in Metrics_template.xlsx...")
        
        src_wb = load_workbook(source_path)
        
        # Load or create destination
        if Path(dest_path).exists():
            dst_wb = load_workbook(dest_path)
        else:
            dst_wb = Workbook()
            if "Sheet" in dst_wb.sheetnames:
                del dst_wb["Sheet"]
        
        # Get all evaluation sheet names (exclude judge sheet)
        eval_sheets = [s for s in src_wb.sheetnames if s != "Universal Critique Judge"]
        
        if not eval_sheets:
            print("[WARN] No evaluation sheets found")
            return False
        
        # Delete Test_Data if exists
        if "Test_Data" in dst_wb.sheetnames:
            del dst_wb["Test_Data"]
        
        test_sheet = dst_wb.create_sheet("Test_Data")
        
        # Create headers: Query_ID, Query, then {EvalName}, {EvalName}-reason for each eval
        headers = ["Query_ID", "Query"]
        for sheet_name in eval_sheets:
            headers.append(sheet_name)
            headers.append(f"{sheet_name}-reason")
        
        test_sheet.append(headers)
        print(f"     ✓ Headers created ({len(headers)} columns)")
        
        # Get number of data rows from first sheet
        first_sheet = src_wb[eval_sheets[0]]
        num_data_rows = first_sheet.max_row - 1
        
        # Extract data for each row
        for row_idx in range(2, first_sheet.max_row + 1):
            query_id = first_sheet.cell(row_idx, 1).value
            query = first_sheet.cell(row_idx, 2).value
            
            row_data = [query_id, query]
            
            # Extract score and reason from each evaluation sheet
            for sheet_name in eval_sheets:
                eval_sheet = src_wb[sheet_name]
                
                # Find columns with overall_score/score and overall_reason/reason
                score_value = None
                reason_value = None
                
                # Search for score column (try overall_score first, then score)
                for col_idx in range(1, eval_sheet.max_column + 1):
                    header = eval_sheet.cell(1, col_idx).value
                    if header:
                        header_lower = str(header).lower()
                        if "overall_score" in header_lower or header_lower == "overall_score":
                            score_value = eval_sheet.cell(row_idx, col_idx).value
                            break
                
                # If no overall_score, try score
                if score_value is None:
                    for col_idx in range(1, eval_sheet.max_column + 1):
                        header = eval_sheet.cell(1, col_idx).value
                        if header:
                            header_lower = str(header).lower()
                            if header_lower == "score":
                                score_value = eval_sheet.cell(row_idx, col_idx).value
                                break
                
                # Search for reason column (try overall_reason first, then reason)
                for col_idx in range(1, eval_sheet.max_column + 1):
                    header = eval_sheet.cell(1, col_idx).value
                    if header:
                        header_lower = str(header).lower()
                        if "overall_reason" in header_lower or header_lower == "overall_reason":
                            reason_value = eval_sheet.cell(row_idx, col_idx).value
                            break
                
                # If no overall_reason, try reason
                if reason_value is None:
                    for col_idx in range(1, eval_sheet.max_column + 1):
                        header = eval_sheet.cell(1, col_idx).value
                        if header:
                            header_lower = str(header).lower()
                            if header_lower == "reason":
                                reason_value = eval_sheet.cell(row_idx, col_idx).value
                                break
                
                row_data.append(score_value)
                row_data.append(reason_value)
            
            test_sheet.append(row_data)
        
        dst_wb.save(dest_path)
        dst_wb.close()
        src_wb.close()
        
        print(f"     ✓ Test_Data created with {num_data_rows} rows")
        print(f"  [OK] Test_Data sheet created in Metrics_template.xlsx")
        return True
        
    except Exception as e:
        print(f"[ERROR] Failed to create Test_Data: {e}")
        import traceback
        traceback.print_exc()
        return False


def copy_universal_critique_judge(source_path: str, dest_path: str):
    """
    Copy Universal Critique Judge sheet from final_eval_results.xlsx to 
    Secondary LLM sheet in Metrics_template.xlsx
    """
    if not Path(source_path).exists():
        print(f"[WARN] {source_path} not found")
        return False
    
    try:
        print(f"\n[STEP 3] Copying Universal Critique Judge to Metrics_template.xlsx...")
        
        src_wb = load_workbook(source_path)
        
        # Check if Universal Critique Judge exists
        if "Universal Critique Judge" not in src_wb.sheetnames:
            print(f"[WARN] 'Universal Critique Judge' sheet not found in {source_path}")
            src_wb.close()
            return False
        
        src_sheet = src_wb["Universal Critique Judge"]
        
        # Load destination
        if Path(dest_path).exists():
            dst_wb = load_workbook(dest_path)
        else:
            dst_wb = Workbook()
            if "Sheet" in dst_wb.sheetnames:
                del dst_wb["Sheet"]
        
        # Delete Secondary LLM if exists
        if "Secondary LLM" in dst_wb.sheetnames:
            del dst_wb["Secondary LLM"]
        
        # Create Secondary LLM sheet
        dst_sheet = dst_wb.create_sheet("Secondary LLM")
        
        # Copy all rows
        for row in src_sheet.iter_rows(values_only=True):
            dst_sheet.append(list(row))
        
        print(f"     ✓ Copied {src_sheet.max_row} rows")
        
        dst_wb.save(dest_path)
        dst_wb.close()
        src_wb.close()
        
        print(f"  [OK] Universal Critique Judge copied to Secondary LLM sheet")
        return True
        
    except Exception as e:
        print(f"[ERROR] Failed to copy Universal Critique Judge: {e}")
        import traceback
        traceback.print_exc()
        return False


def transfer_all_data(
    final_eval_path: str = "final_eval_results.xlsx",
    detailed_log_path: str = "Detailed_Log.xlsx",
    metrics_template_path: str = "Metrics_template.xlsx"
):
    """
    Main orchestrator: Transfer data from final_eval_results to both output files
    """
    print("\n" + "="*70)
    print("TRANSFERRING DATA FROM FINAL EVAL RESULTS")
    print("="*70)
    
    # Step 1: Copy evaluation sheets to Detailed_Log
    success1 = copy_eval_sheets_to_detailed_log(final_eval_path, detailed_log_path)
    
    # Step 2: Create Test_Data sheet in Metrics_template
    success2 = create_test_data_sheet(final_eval_path, metrics_template_path)
    
    # Step 3: Copy Universal Critique Judge to Metrics_template
    success3 = copy_universal_critique_judge(final_eval_path, metrics_template_path)
    
    print("\n" + "="*70)
    if success1 and success2 and success3:
        print("[OK] ALL DATA TRANSFERRED SUCCESSFULLY")
    else:
        print("[WARN] Some transfers may have failed - check above")
    print("="*70)


if __name__ == "__main__":
    transfer_all_data()
