"""
Knowledge Retention Evaluation Module
Evaluates whether the model retains and accurately recalls information across conversation turns.
Uses DeepEval's KnowledgeRetentionMetric with conversational test cases.
"""

import os
import json
from typing import Optional, Type
from datetime import datetime
from pathlib import Path
from langsmith import Client
from langchain_openai import AzureChatOpenAI
from deepeval.metrics import KnowledgeRetentionMetric
from deepeval.test_case import ConversationalTestCase, Turn
from deepeval.models.base_model import DeepEvalBaseLLM
from pydantic import BaseModel
from openpyxl import Workbook, load_workbook
from token_tracker import track_tokens_used, count_tokens

# ============================================================
# AZURE MODEL WRAPPER
# ============================================================

class AzureOpenAIModel(DeepEvalBaseLLM):
    def __init__(self, client):
        self.client = client

    def load_model(self):
        return self.client

    def generate(self, prompt: str, schema: Optional[Type[BaseModel]] = None):
        if schema is not None:
            structured_client = self.client.with_structured_output(schema)
            return structured_client.invoke(prompt)
        response = self.client.invoke(prompt)
        return response.content

    async def a_generate(self, prompt: str, schema: Optional[Type[BaseModel]] = None):
        if schema is not None:
            structured_client = self.client.with_structured_output(schema)
            return await structured_client.ainvoke(prompt)
        response = await self.client.ainvoke(prompt)
        return response.content

    def get_model_name(self) -> str:
        return "Azure GPT-5"


# ============================================================
# EXTRACT CUMULATIVE TURNS — ORIGINAL LOGIC UNCHANGED
# ============================================================

def extract_cumulative_turns_from_run(run_id: str) -> list:
    client = Client()
    child_runs = list(client.list_runs(parent_run_id=run_id))

    supervisor_run = None
    max_msgs = 0

    for run in child_runs:
        if run.name == "Supervisor":
            msgs = run.inputs.get("messages", [])
            if len(msgs) > max_msgs:
                max_msgs = len(msgs)
                supervisor_run = run

    if not supervisor_run:
        raise ValueError("No Supervisor child run found")

    messages = supervisor_run.inputs.get("messages", [])

    # -----------------------------
    # STEP 1: Filter messages
    # Only include:
    #   type="human", name="user"      → USER
    #   type="ai",    name="Supervisor" → ASSISTANT
    # -----------------------------
    filtered = []
    seen_ids = set()

    for msg in messages:
        msg_id   = msg.get("id")
        msg_type = msg.get("type")
        msg_name = msg.get("name", "")
        content  = msg.get("content", "")

        if msg_id and msg_id in seen_ids:
            continue
        if msg_id:
            seen_ids.add(msg_id)

        # Only include: type="human" name="user"  OR  type="ai" name="Supervisor"
        if msg_type == "human" and msg_name == "user":
            filtered.append({
                "role": "USER",
                "content": content.strip()
            })
        elif msg_type == "ai" and msg_name == "Supervisor":
            filtered.append({
                "role": "ASSISTANT",
                "content": content.strip()
            })

    # -----------------------------
    # STEP 2: Group USER + assistants
    # -----------------------------
    groups = []
    i = 0

    while i < len(filtered):
        if filtered[i]["role"] == "USER":
            group = [filtered[i]]
            i += 1

            while i < len(filtered) and filtered[i]["role"] == "ASSISTANT":
                group.append(filtered[i])
                i += 1

            groups.append(group)
        else:
            i += 1

    # -----------------------------
    # STEP 3: Build cumulative turns
    # -----------------------------
    cumulative_turns = []
    accumulated = []

    for group in groups:
        accumulated.extend(group)

        turn_text = "\n".join(
            f"{msg['role']}: {msg['content']}"
            for msg in accumulated
        )

        cumulative_turns.append(
            Turn(role="assistant", content=turn_text)
        )

    return cumulative_turns


# ============================================================
# HELPER: parse cumulative turn text into Turn objects
# ============================================================

def parse_turn_text_to_turns(turn_text: str) -> list:
    individual_turns = []
    current_role = None
    current_lines = []

    for line in turn_text.split("\n"):
        if line.startswith("USER:"):
            if current_role and current_lines:
                individual_turns.append(
                    Turn(role=current_role, content="\n".join(current_lines).strip())
                )
            current_role = "user"
            current_lines = [line[len("USER:"):].strip()]

        elif line.startswith("ASSISTANT:"):
            if current_role and current_lines:
                individual_turns.append(
                    Turn(role=current_role, content="\n".join(current_lines).strip())
                )
            current_role = "assistant"
            current_lines = [line[len("ASSISTANT:"):].strip()]

        else:
            if current_role:
                current_lines.append(line)

    if current_role and current_lines:
        individual_turns.append(
            Turn(role=current_role, content="\n".join(current_lines).strip())
        )

    return individual_turns


# ============================================================
# HELPER: extract actual prompt from KnowledgeRetentionMetric
# ============================================================

def get_knowledge_retention_prompt(turns: list) -> str:
    try:
        metric = KnowledgeRetentionMetric(
            model=AzureOpenAIModel(None),
            threshold=0.5,
            include_reason=True
        )
        prompt = metric._generate_attritions_prompt(turns)
        return prompt
    except Exception:
        try:
            metric = KnowledgeRetentionMetric(
                model=AzureOpenAIModel(None),
                threshold=0.5,
                include_reason=True
            )
            return metric.evaluation_params if hasattr(metric, "evaluation_params") else str(metric.__class__.__doc__)
        except Exception as e:
            return f"Could not extract prompt: {str(e)}"


# ============================================================
# HELPER: compute overall score and reasoning via LLM
# ============================================================

def compute_overall_score_and_reason(eval_results: list) -> dict:
    """
    Feeds all turn-wise scores and reasonings into the LLM
    and asks it to produce one overall score (0 to 1) and
    one overall reasoning summarising knowledge retention
    across the entire conversation.
    """

    # Build a readable summary of all turn results to feed into the prompt
    turn_summaries = []
    for r in eval_results:
        score = r["eval_output"]["score"]
        reasoning = r["eval_output"]["reasoning"]
        if score is not None:
            turn_summaries.append(
                f"Turn {r['turn_index']}: Score = {score:.4f}\nReasoning: {reasoning}"
            )

    turn_summary_text = "\n\n".join(turn_summaries)

    overall_prompt = f"""You are an expert evaluator assessing knowledge retention in a multi-turn AI conversation.

Below are the turn-wise knowledge retention evaluation results for a conversation.
Each turn has a score (0 to 1) and a reasoning explaining what facts were retained or forgotten.

{turn_summary_text}

Based on all the above turn-wise results:
1. Compute an OVERALL SCORE between 0 and 1 that represents the knowledge retention quality across the entire conversation.
   - 1.0 means perfect knowledge retention throughout
   - 0.0 means complete failure to retain knowledge throughout
2. Write an OVERALL REASONING that summarises the key patterns of retention and forgetting observed across all turns.

You MUST respond in the following JSON format only, with no extra text or markdown:
{{
  "overall_score": <float between 0 and 1>,
  "overall_reasoning": "<concise but thorough summary of knowledge retention across the conversation>"
}}"""

    try:
        # Create a temporary azure_model for the LLM call
        # Note: This will be called within run_knowledge_retention_eval which has access to llm_client
        from langchain_openai import AzureChatOpenAI
        # We'll need to get this from context - for now return a note
        response = None
        # This will be properly handled in run_knowledge_retention_eval
        
        # Clean and parse JSON response
        clean = response.strip() if response else ""
        if clean.startswith("```"):
            clean = clean.split("```")[1]
            if clean.startswith("json"):
                clean = clean[4:]
        clean = clean.strip()

        parsed = json.loads(clean) if clean else {}

        return {
            "overall_score": round(float(parsed.get("overall_score", 0)), 4),
            "overall_reasoning": parsed.get("overall_reasoning", "")
        }

    except Exception as e:
        # Fallback: compute average of valid scores
        valid_scores = [
            r["eval_output"]["score"]
            for r in eval_results
            if r["eval_output"]["score"] is not None
        ]
        avg_score = round(sum(valid_scores) / len(valid_scores), 4) if valid_scores else 0.0

        return {
            "overall_score": avg_score,
            "overall_reasoning": f"Overall score computed as average of turn-wise scores. LLM summarisation failed: {str(e)}"
        }


# ============================================================
# MAIN EVALUATION PIPELINE
# ============================================================

def run_knowledge_retention_eval(trace_id: str, scenario: str, llm_client: AzureChatOpenAI):
    """
    Run knowledge retention evaluation for a single trace.

    Args:
        trace_id:   LangSmith trace ID
        scenario:   Query/scenario text
        llm_client: Azure OpenAI client

    Returns:
        Evaluation result dictionary compatible with main.py
    """
    try:
        turns = extract_cumulative_turns_from_run(trace_id)

        azure_model = AzureOpenAIModel(llm_client)

        # ============================================================
        # EXTRACT ACTUAL EVAL PROMPT
        # ============================================================

        eval_prompt_str = "Could not extract prompt"

        for idx in range(len(turns)):
            individual_turns = parse_turn_text_to_turns(turns[idx].content)
            roles = {t.role for t in individual_turns}
            if "user" in roles and "assistant" in roles:
                eval_prompt_str = get_knowledge_retention_prompt(individual_turns)
                break

        # ============================================================
        # TURN-WISE EVALUATION
        # ============================================================

        all_eval_results = []

        for idx in range(len(turns)):

            individual_turns = parse_turn_text_to_turns(turns[idx].content)

            roles = {t.role for t in individual_turns}
            if "user" not in roles or "assistant" not in roles:
                all_eval_results.append({
                    "turn_index": idx + 1,
                    "eval_output": {
                        "score": None,
                        "reasoning": "Skipped — need at least one user and one assistant turn."
                    }
                })
                continue

            test_case = ConversationalTestCase(turns=individual_turns)

            metric = KnowledgeRetentionMetric(
                model=azure_model,
                threshold=0.5,
                include_reason=True
            )

            metric.measure(test_case)

            tokens = count_tokens(str(metric.reason) if metric.reason else "")
            track_tokens_used(tokens, eval_name="knowledge_retention")

            all_eval_results.append({
                "turn_index": idx + 1,
                "eval_output": {
                    "score": metric.score,
                    "reasoning": metric.reason
                }
            })

        # ============================================================
        # COMPUTE OVERALL SCORE AND REASONING
        # ============================================================

        overall_output = compute_overall_score_and_reason(all_eval_results)

        # Extract query from first user message
        query = ""
        if turns and turns[0].content:
            for line in turns[0].content.split("\n"):
                if line.startswith("USER:"):
                    query = line.replace("USER:", "").strip()
                    break

        # ============================================================
        # FINAL STRUCTURED OUTPUT
        # ============================================================

        return {
            "eval_name": "knowledge_retention_turnwise",
            "eval_type": "multi_turn_conversational_memory",
            "trace_id": trace_id,
            "scenario": scenario,
            "query": query,
            "eval_prompt": eval_prompt_str,
            "eval_inputs": {
                "input_context": [t.content for t in turns]
            },
            "eval_output": [
                {
                    "turn_index": r["turn_index"],
                    "reasoning": r["eval_output"]["reasoning"],
                    "score": r["eval_output"]["score"],
                }
                for r in all_eval_results
            ],
            "overall_output": {
                "overall_score": overall_output["overall_score"],
                "overall_reasoning": overall_output["overall_reasoning"]
            },
            "metadata": {
                "model": "gpt-5",
                "temperature": 0,
                "timestamp": datetime.utcnow().isoformat()
            },
            "status": "success",
        }

    except Exception as e:
        return {
            "eval_name": "knowledge_retention_turnwise",
            "trace_id": trace_id,
            "scenario": scenario,
            "status": "failed",
            "error": str(e),
            "eval_output": {},
            "overall_output": {
                "overall_score": 0.0,
                "overall_reasoning": f"Evaluation failed: {str(e)}",
            },
            "metadata": {
                "timestamp": datetime.utcnow().isoformat(),
            },
        }


# ============================================================
# EXCEL LOGGER
# ============================================================

SHEET_NAME = "Knowledge Retention Eval"

HEADERS = [
    "Query",
    "Turn_Index",
    "Turn_Score",
    "Turn_Reasoning",
    "Overall_Score",
    "Overall_Reasoning"
]


# ============================================================
# WORKBOOK HELPERS
# ============================================================

def get_or_create_workbook(path: str):
    if Path(path).exists():
        wb = load_workbook(path)
    else:
        wb = Workbook()
        wb.remove(wb.active)
    return wb


def get_or_create_sheet(wb, sheet_name: str, headers: list):
    if sheet_name in wb.sheetnames:
        sheet = wb[sheet_name]
    else:
        sheet = wb.create_sheet(sheet_name)
        sheet.append(headers)
    return sheet


# ============================================================
# DUMP FUNCTION
# ============================================================

def dump_knowledge_retention_eval_to_excel(
    *,
    trace_id: str = "",
    query: str = "",
    eval_result: dict = None,
    excel_path: str = "final_eval_results.xlsx",
):
    """Save knowledge retention evaluation results to Excel."""

    if eval_result is None:
        eval_result = {}

    wb = get_or_create_workbook(excel_path)
    sheet = get_or_create_sheet(wb, SHEET_NAME, HEADERS)

    if eval_result.get("status") == "failed":
        sheet.append([
            query,
            "",
            "",
            eval_result.get("error", "Unknown error"),
            "",
            ""
        ])
    else:
        overall_output = eval_result.get("overall_output", {})
        overall_score = overall_output.get("overall_score", "")
        overall_reason = overall_output.get("overall_reasoning", "")
        eval_output = eval_result.get("eval_output", [])

        # Append one row per turn
        for turn in eval_output:
            sheet.append([
                query,
                turn.get("turn_index", ""),
                turn.get("score", ""),
                turn.get("reasoning", ""),
                overall_score,
                overall_reason
            ])

    wb.save(excel_path)
