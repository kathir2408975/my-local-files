"""
Plan Accuracy Evaluation Module
Evaluates plan fragments against supervisor workflow rules and structural flow logic.
Uses a single context-aware LLM audit pass.
"""

import os
import json
from typing import List, Any, Dict
from datetime import datetime
from langsmith import Client
from langchain_openai import AzureChatOpenAI
from utils import get_or_create_workbook, get_or_create_sheet, get_timestamp

# ============================================================
# PLAN ACCURACY HEADERS — matches notebook logger HEADERS_PA
# FIX 1: removed Query, User_Query_Fragment, Fragment_Score columns
#         that are NOT in the notebook logger headers
# ============================================================
PLAN_ACCURACY_HEADERS = [
    "Planning Rules",
    "Plan",
    "Output Fragment",
    "Matched Rule Fragment",
    "Plan Output Rule Accuracy",
    "Rule Accuracy Reason",
    "Plan Output Flow Accuracy",
    "Flow Accuracy Reason",
    "Score",
    "Overall Reason",
]


# ============================================================
# TRACE EXTRACTION
# ============================================================
def fetch_spans(trace_id: str) -> List[Any]:
    """Fetch and sort spans from a trace."""
    client = Client(api_key=os.environ["LANGSMITH_API_KEY"])
    spans  = list(client.list_runs(trace_id=trace_id))
    if not spans:
        raise ValueError("No spans found for trace")
    return sorted(spans, key=lambda r: r.start_time or 0)


# ============================================================
# SPAN FINDERS
# ============================================================
def find_supervisor_span(spans: List[Any]) -> Any:
    """Find the Supervisor span."""
    for s in spans:
        if s.name == "Supervisor":
            return s
    raise ValueError("Supervisor span not found")


def find_planning_process_span(spans: List[Any]) -> Any:
    """Find the Planning Process span."""
    for s in spans:
        if s.name == "Planning Process":
            return s
    raise ValueError("Planning Process span not found")


# ============================================================
# DATA EXTRACTION
# ============================================================
def extract_user_input(span: Any) -> str:
    """Extract user input from supervisor span."""
    return span.inputs["messages"][0]["content"]


def extract_rules(span: Any) -> str:
    """Extract planning rules from planning process span."""
    return span.inputs["messages"][0][0]["kwargs"]["content"]


def extract_plan(span: Any) -> str:
    """Extract plan from planning process span outputs."""
    return span.outputs["generations"][0][0]["text"]


# ============================================================
# LLM — SINGLE-PASS CONTEXT-AWARE PLAN AUDIT
# ============================================================
def llm_audit_plan(
    plan: str,
    rules: str,
    user_input: str,
    llm: AzureChatOpenAI,
) -> List[Dict]:
    """
    Single-pass context-aware audit.
    Fragments the plan AND evaluates rule/flow accuracy in one LLM call.
    Returns a list of fragment result dicts.
    """
    prompt = f"""
You are a STRICT CONTEXT-AWARE PLAN STRUCTURE AUDITOR.

Your responsibility is to audit a GENERATED EXECUTION PLAN
against SUPERVISOR WORKFLOW RULES and STRUCTURAL FLOW LOGIC.

You are NOT evaluating writing quality, grammar, or style.
You are performing a STRUCTURAL WORKFLOW AUDIT.

You MUST behave deterministically and mechanically.

============================================================
PRIMARY OBJECTIVE
============================================================

You MUST perform ALL of the following:

1) SEMANTIC STEP FRAGMENTATION
2) RULE TEXT MATCHING
3) RULE ACCURACY VALIDATION
4) FLOW ACCURACY VALIDATION

These MUST be done in ONE PASS.

============================================================
TASK 1 — SEMANTIC STEP FRAGMENTATION (STRICT)
============================================================

You MUST extract MEANINGFUL EXECUTION STEPS from generated_plan.

A VALID fragment MUST:

✔ represent a COMPLETE execution action
✔ contain an AGENT or EXECUTION SUBJECT
✔ be independently auditable

DO NOT split sentences based on grammar alone.

VALID EXAMPLES:
- "Step 1: Invoke ContextBuilder with parameters..."
- "TaskPlanner generates routing combinations"

INVALID FRAGMENTS:
- "generates routing combinations"
- "and then sends email"
- clauses without agent/action

------------------------------------------------------------
FRAGMENTATION SIGNALS (HIGH PRIORITY)
------------------------------------------------------------

Prefer splitting using:

- "Step X:"
- "Task X:"
- Explicit agent transitions
- Workflow stage boundaries

============================================================
TASK 2 — CONTEXT PRESERVATION (CRITICAL)
============================================================

You MUST internally carry PREVIOUS steps as background context
when evaluating a fragment.

Example:

Step 1: ContextBuilder gathers data
Step 2: Forecast computes costs

When evaluating Step 2:

✔ consider Step 1 internally
❌ DO NOT include Step 1 text in Output Fragment

Output Fragment MUST contain ONLY the CURRENT STEP TEXT.

============================================================
TASK 3 — RULE MATCHING (STRICT TEXT MATCH)
============================================================

For EACH Output Fragment:

You MUST locate the EXACT matching rule text inside supervisor_rules.

Rules:

✔ Copy rule text VERBATIM
✔ Do NOT paraphrase
✔ Do NOT synthesize new rules
✔ Do NOT merge multiple rules

If NO matching rule exists:

Return:
"Matched Rule Fragment": "N/A"

------------------------------------------------------------
RULE MATCHING STRATEGY
------------------------------------------------------------

Match based on:

- Agent name
- Execution responsibility
- Action semantics

Example:

Fragment:
"Optimization ranks the plans"

Matching rule:
"6. **Optimization**: Ranks the plans based on utility..."

============================================================
TASK 4 — PLAN OUTPUT RULE ACCURACY
============================================================

pass:
✔ Agent exists in supervisor_rules
✔ Action allowed by rules
✔ No forbidden behaviour

fail:
✖ Agent not present in rules
✖ Action contradicts rule text
✖ Required workflow stage skipped

IMPORTANT:
Rule Accuracy MUST be judged ONLY using supervisor_rules.

============================================================
TASK 5 — PLAN OUTPUT FLOW ACCURACY
============================================================

pass:
✔ Logical ordering preserved
✔ Dependencies satisfied
✔ Workflow progression valid

fail:
✖ Execution before prerequisite
✖ Circular logic
✖ Impossible ordering

Flow Accuracy evaluates INTERNAL PLAN STRUCTURE ONLY.

============================================================
STRICT GLOBAL CONSTRAINTS
============================================================

- DO NOT rewrite fragments
- DO NOT invent rules
- DO NOT expose hidden context
- DO NOT evaluate language quality
- DO NOT combine fragments
- DO NOT reference user intent in scoring
- ALWAYS return JSON only

============================================================
INPUTS
============================================================

user_input:
{user_input}

supervisor_rules:
{rules}

generated_plan:
{plan}

============================================================
OUTPUT FORMAT (STRICT JSON)
============================================================

{{
  "fragments":[
    {{
      "Output Fragment":"string",
      "Matched Rule Fragment":"string | N/A",
      "Plan Output Rule Accuracy":"pass | fail",
      "Plan Output Flow Accuracy":"pass | fail",
      "Rule Accuracy Reason":"string",
      "Flow Accuracy Reason":"string"
    }}
  ]
}}

============================================================
FEW SHOT EXAMPLES
============================================================

Example 1 — Perfect Alignment

Supervisor Rule:
"3. **TaskPlanner**: Formulates shipment order..."

Fragment:
"Step 3: TaskPlanner formulates shipment order..."

Output:
{{
  "Output Fragment":"Step 3: TaskPlanner formulates shipment order...",
  "Matched Rule Fragment":"3. **TaskPlanner**: Formulates shipment order...",
  "Plan Output Rule Accuracy":"pass",
  "Plan Output Flow Accuracy":"pass",
  "Rule Accuracy Reason":"Fragment directly matches TaskPlanner rule.",
  "Flow Accuracy Reason":"Correctly follows prior verification stage."
}}

------------------------------------------------------------

Example 2 — Rule Violation

Supervisor Rule:
"Only Optimization ranks vendors."

Fragment:
"Forecast ranks vendors by score"

Output:
{{
  "Output Fragment":"Forecast ranks vendors by score",
  "Matched Rule Fragment":"N/A",
  "Plan Output Rule Accuracy":"fail",
  "Plan Output Flow Accuracy":"pass",
  "Rule Accuracy Reason":"Forecast is not authorized to rank vendors.",
  "Flow Accuracy Reason":"Ordering itself is logical."
}}

------------------------------------------------------------

Example 3 — Flow Violation

Fragment:
"Execute sends email before Compliance checks"

Output:
{{
  "Output Fragment":"Execute sends email before Compliance checks",
  "Matched Rule Fragment":"10. **Execute**: Saves the confirmed order to DB and sends an email.",
  "Plan Output Rule Accuracy":"pass",
  "Plan Output Flow Accuracy":"fail",
  "Rule Accuracy Reason":"Execute action allowed by rules.",
  "Flow Accuracy Reason":"Execution occurs before compliance which violates workflow ordering."
}}
""".strip()

    resp = llm.invoke(prompt)
    return json.loads(resp.content)["fragments"]


# ============================================================
# SCORING
# ============================================================
def compute_plan_accuracy_score(fragment_results: List[Dict]) -> float:
    """Compute overall plan accuracy score. 75% rule weight, 25% flow weight."""
    if not fragment_results:
        return 1.0

    total_score = 0.0
    for f in fragment_results:
        rule_score = 1.0 if f.get("Plan Output Rule Accuracy") == "pass" else 0.0
        flow_score = 1.0 if f.get("Plan Output Flow Accuracy") == "pass" else 0.0
        total_score += (rule_score * 0.75) + (flow_score * 0.25)

    return round(total_score / len(fragment_results), 2)


# ============================================================
# OVERALL REASON GENERATION
# ============================================================
def generate_overall_reason(fragment_results: List[Dict], llm: AzureChatOpenAI) -> str:
    """Generate overall summary of plan accuracy."""
    prompt = f"""
You are a PLAN ACCURACY SUMMARIZER.

Explain structural correctness patterns.

Use SIMPLE wording.
Describe ONLY:
- rule accuracy trends
- flow accuracy trends

Input:
{json.dumps(fragment_results, indent=2)}

Return STRICT JSON:
{{"overall_reason":"string"}}
"""
    resp = llm.invoke(prompt)
    return json.loads(resp.content).get("overall_reason", "")


# ============================================================
# MAIN EVALUATION PIPELINE
# ============================================================
def run_plan_accuracy_eval(
    trace_id: str,
    scenario: str,
    llm_client: AzureChatOpenAI,
) -> Dict:
    """
    Run plan accuracy evaluation for a single trace.

    Args:
        trace_id:   LangSmith trace ID
        scenario:   Query/scenario text
        llm_client: Azure OpenAI client

    Returns:
        Evaluation result dictionary compatible with main.py
    """
    try:
        spans     = fetch_spans(trace_id)
        sup       = find_supervisor_span(spans)
        plan_span = find_planning_process_span(spans)

        user_input = extract_user_input(sup)
        rules      = extract_rules(plan_span)
        plan       = extract_plan(plan_span)

        fragment_results = llm_audit_plan(plan, rules, user_input, llm_client)
        score            = compute_plan_accuracy_score(fragment_results)
        overall_reason   = generate_overall_reason(fragment_results, llm_client)

        return {
            "eval_name":  "plan_accuracy",
            "eval_type":  "llm",
            "trace_id":   trace_id,
            "scenario":   scenario,
            "status":     "success",
            "error":      None,
            "eval_prompt": "See llm_audit_plan prompt in source.",
            "eval_inputs": {
                "user_input": user_input,
                "rules":      rules,
                "plan":       plan,
            },
            "eval_output": {
                "score":          score,
                "fragments":      fragment_results,
                "overall_reason": overall_reason,
            },
            "metadata": {
                "model":       "gpt-5",
                "temperature": 1,
                "timestamp":   datetime.utcnow().isoformat(),
            },
        }

    except Exception as e:
        return {
            "eval_name":  "plan_accuracy",
            "eval_type":  "llm",
            "trace_id":   trace_id,
            "scenario":   scenario,
            "status":     "failed",
            "error":      str(e),
            "eval_output": {},
            "metadata": {
                "timestamp": datetime.utcnow().isoformat(),
            },
        }


# ============================================================
# EXCEL STORAGE — aligned with notebook logger
# ============================================================
def dump_plan_accuracy_eval_to_excel(
    *,
    trace_id: str,
    query: str,
    eval_result: dict,
    excel_path: str = "final_eval_results.xlsx",
):
    """Save plan accuracy evaluation results to Excel file."""
    wb    = get_or_create_workbook(excel_path)
    # FIX 2: sheet name "Plan Accuracy" matches notebook logger SHEET_NAME_PA
    sheet = get_or_create_sheet(wb, "Plan Accuracy", PLAN_ACCURACY_HEADERS)

    eval_inputs    = eval_result.get("eval_inputs",  {})
    eval_output    = eval_result.get("eval_output",  {})
    fragments      = eval_output.get("fragments",    [])
    overall_score  = eval_output.get("score",        "")
    overall_reason = eval_output.get("overall_reason", "")
    rules          = eval_inputs.get("rules", "")
    plan           = eval_inputs.get("plan",  "")

    if eval_result.get("status") == "failed":
        # FIX 3: was writing query + Nones for 13 columns (old headers)
        # now writes exactly 10 columns matching PLAN_ACCURACY_HEADERS
        sheet.append([
            rules,
            plan,
            "", "", "", "", "", "",   # 6 fragment columns
            overall_score,
            eval_result.get("error", "Unknown error"),
        ])
        wb.save(excel_path)
        return

    if not fragments:
        # FIX 4: notebook logger writes 10 values for no-fragment case
        # old code wrote 13 values (with query, User_Query_Fragment, Fragment_Score)
        sheet.append([
            rules,
            plan,
            "", "", "", "", "", "",   # 6 fragment columns empty
            overall_score,
            overall_reason,
        ])
    else:
        for f in fragments:
            # One row per fragment — exactly 10 columns matching HEADERS_PA
            sheet.append([
                rules,
                plan,
                f.get("Output Fragment",           ""),
                f.get("Matched Rule Fragment",     ""),
                f.get("Plan Output Rule Accuracy", ""),
                f.get("Rule Accuracy Reason",      ""),
                f.get("Plan Output Flow Accuracy", ""),
                f.get("Flow Accuracy Reason",      ""),
                overall_score,
                overall_reason,
            ])

    wb.save(excel_path)