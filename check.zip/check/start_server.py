"""
start_server.py
===============
One-click launcher for the GenAI Eval HTML Report Server.

Usage
-----
    python start_server.py                  # serves on http://127.0.0.1:5000
    python start_server.py --port 8080      # custom port
    python start_server.py --save-only      # just write report.html, no server

What it does
------------
1. Checks that required packages are installed (installs if missing).
2. Reads Metrics_template.xlsx to generate report.html.
3. Starts a Flask server at http://127.0.0.1:5000 (or chosen port).
4. Click the printed URL to open the report in your browser.

Files used (must be in the same directory as this script)
----------------------------------------------------------
  Metrics_template.xlsx   – source of all chart/table data
  Detailed_Log.xlsx       – per-eval detail rows (drill-down modals)
  report_gen.py           – report generator + Flask app
"""

import subprocess
import sys
import os
import argparse
from pathlib import Path

REQUIRED_PACKAGES = [
    "flask",
    "pandas",
    "openpyxl",
    "plotly",
    "loguru",
]

def ensure_packages():
    import importlib
    missing = []
    pkg_map = {
        "flask": "flask",
        "pandas": "pandas",
        "openpyxl": "openpyxl",
        "plotly": "plotly",
        "loguru": "loguru",
    }
    for pkg, import_name in pkg_map.items():
        try:
            importlib.import_module(import_name)
        except ImportError:
            missing.append(pkg)
    if missing:
        print(f"[INFO] Installing missing packages: {', '.join(missing)}")
        subprocess.check_call([sys.executable, "-m", "pip", "install"] + missing)

def main():
    parser = argparse.ArgumentParser(description="Start the GenAI Eval Report Server")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=5000)
    parser.add_argument("--save-only", action="store_true",
                        help="Generate report.html and exit without starting the server")
    args = parser.parse_args()

    # Change to the directory that contains this script so relative paths work
    script_dir = Path(__file__).resolve().parent
    os.chdir(script_dir)

    ensure_packages()

    if args.save_only:
        subprocess.run([sys.executable, "report_gen.py", "--save-only"], check=True)
        return

    url = f"http://{args.host}:{args.port}/"
    print()
    print("=" * 55)
    print("  GenAI Eval Report Server")
    print(f"  >>> Open in browser: {url}")
    print("  Press Ctrl+C to stop the server")
    print("=" * 55)
    print()

    subprocess.run([
        sys.executable, "report_gen.py",
        "--host", args.host,
        "--port", str(args.port),
    ])

if __name__ == "__main__":
    main()