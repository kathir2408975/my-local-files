"""
Summary Accuracy Evaluation Module
Evaluates whether the final summary output is supported by execution context.
"""

import os
import json
from datetime import datetime
from typing import List, Dict, Any
from langsmith import Client
from langchain_openai import AzureChatOpenAI
from utils import get_or_create_workbook, get_or_create_sheet, get_timestamp

# ============================================================
# SUMMARY ACCURACY HEADERS — matches notebook logger OVERALL_SUMMARY_HEADERS
# FIX 1: removed "Verification Reason" column — not in notebook logger headers
# ============================================================
SUMMARY_ACCURACY_HEADERS = [
    "Query",
    "Summary Output",
    "Score",
    "Reason",
    "Output Fragment",
    "Supporting Context Evidence",
    "Evidence Match Status",
]


# ============================================================
# TRACE EXTRACTION
# ============================================================
def fetch_spans(trace_id: str) -> List[Any]:
    """Fetch and sort spans from a trace."""
    client = Client(api_key=os.environ["LANGSMITH_API_KEY"])
    spans  = list(client.list_runs(trace_id=trace_id))
    if not spans:
        raise ValueError("No spans found for trace.")
    return sorted(spans, key=lambda r: r.start_time or 0)


# ============================================================
# SPAN FINDERS
# ============================================================
def find_execute_span(spans: List[Any]) -> Any:
    """Find the Execute span. Returns None if not found (non-fatal)."""
    for s in spans:
        if s.name == "Execute":
            return s
    return None


def find_execute_plan_summary_span(spans: List[Any]) -> Any:
    """Find the Execute Plan Summary LLM span."""
    for s in spans:
        if s.name == "Execute Plan Summary LLM":
            return s
    raise ValueError("Execute Plan Summary LLM span not found")


# ============================================================
# SUMMARY EXTRACTION
# ============================================================
def extract_execute_plan_summary(span: Any) -> str:
    """Extract final summary text from span outputs."""
    try:
        return span.outputs["generations"][0][0]["text"]
    except Exception as e:
        raise ValueError(f"Could not extract summary text: {e}")


# ============================================================
# CONTEXT EXTRACTION
# ============================================================
def extract_plan_payload_from_summary_input(summary_span: Any) -> Dict[str, Any]:
    """
    Extract the human JSON payload used to generate the summary.
    Expected structure: inputs.messages[0][1].kwargs.content
    """
    try:
        messages    = summary_span.inputs.get("messages", [])
        human_msg   = messages[0][1]
        raw_content = human_msg["kwargs"]["content"]
        return json.loads(raw_content)
    except Exception as e:
        print(f"Warning: Failed to extract plan payload from summary input: {e}")
        return {}


def extract_execute_contexts(execute_span: Any, summary_span: Any) -> Dict[str, Any]:
    """
    Extract context from execute and summary spans.
    execute_span may be None if the Execute span was not found.
    """
    execute_context = execute_span.inputs if execute_span else {}
    plan_payload    = extract_plan_payload_from_summary_input(summary_span)

    return {
        "execute_input": execute_context,
        "plan_payload":  plan_payload,
    }


# ============================================================
# STEP 1: CLAIM SEGMENTATION (LLM)
# ============================================================
def llm_split_summary_into_claims(summary: str, llm_client: AzureChatOpenAI) -> List[str]:
    """Extract atomic factual claims from summary."""
    system_prompt = f"""
Role:
You are a CLAIM SEGMENTATION ENGINE.

Your task is to extract ATOMIC FACTUAL OUTPUT FRAGMENTS from a summary.

Inputs:
summary:
{summary}

Instructions:
Definition:
An Output Fragment is a sentence or clause that asserts something factual
that could be verified against execution context.

Important Rules (STRICT):
- Do NOT infer information.
- Do NOT rewrite or paraphrase.
- Preserve the ORIGINAL wording exactly.
- Exclude questions, suggestions, and meta statements.
- Exclude sentences that are purely evaluative, emotional, or conversational.
- DO NOT verify correctness.
- DO NOT use external knowledge.

------------------------------------------------------------
CRITICAL SEGMENTATION RULES (NEW — HIGH PRIORITY)
------------------------------------------------------------

You MUST preserve semantic dependency.

DO NOT split fragments when:

1) Parenthetical qualifiers exist:
   Example:
   "Estimated cost is $100 (normalized cost matches this amount)"
   MUST remain ONE fragment.

2) Referential phrases exist:
   "this amount", "that value", "these results", "which indicates"
   MUST remain attached to the main clause.

3) Dependent explanatory clauses exist:
   - normalized
   - adjusted
   - derived
   - calculated
   - mapped
   - based on

4) If removing part of the sentence causes ambiguity,
   the fragment MUST remain whole.

Split ONLY when:
- Two independent factual assertions exist with no dependency.

------------------------------------------------------------
Decision Boundary Rules:
------------------------------------------------------------

A fragment MUST be trace-verifiable.

Do NOT isolate:
- Parentheses (...)
- trailing qualifiers
- explanatory commas
- subordinate clauses beginning with "which", "where", "that"

------------------------------------------------------------
Output Format:
Return STRICT JSON only:

{{
  "claims": ["string"]
}}

Few Shot Examples:

Example 1:
Input Summary:
"The plan ID is PLAN_1. It is a FULL delivery."
Output:
{{
  "claims": [
    "The plan ID is PLAN_1",
    "It is a FULL delivery"
  ]
}}

Example 2 - Parenthesis MUST NOT split:
Input:
"Estimated cost for the move is $1,264,076 (normalized cost matches this amount)"
Output:
{{
  "claims": [
    "Estimated cost for the move is $1,264,076 (normalized cost matches this amount)"
  ]
}}

Example 3:
Input Summary:
"Weather conditions are sunny with a risk of 0.1, which should not impact shipment."
Output:
{{
  "claims": [
    "Weather conditions are sunny with a risk of 0.1"
  ]
}}
""".strip()

    resp = llm_client.invoke([{"role": "system", "content": system_prompt}])

    try:
        parsed = json.loads(resp.content)
        return [c.strip() for c in parsed.get("claims", []) if c.strip()]
    except Exception:
        return [summary.strip()]


# ============================================================
# STEP 2: CLAIM <-> CONTEXT VERIFICATION (LLM)
# ============================================================
def llm_match_claim_to_context(
    claim: str,
    context: Dict[str, Any],
    llm_client: AzureChatOpenAI,
) -> Dict[str, Any]:
    """Verify whether a claim is supported by context."""
    system_prompt = """
You are a FACTUAL CONSISTENCY VERIFIER.

Your task is to determine whether the given SUMMARY OUTPUT FRAGMENT is SUPPORTED by the provided CONTEXT.

DEFINITIONS:
- A SUMMARY OUTPUT FRAGMENT is a factual statement extracted from the system output.
- The CONTEXT is the ONLY source of truth.

IMPORTANT RULES:
1. Use ONLY CONTEXT.
2. A fragment is SUPPORTED ONLY IF explicit evidence exists.
3. Supporting evidence MUST be copied verbatim or near-verbatim.
4. If no explicit evidence exists -> "No Match".
5. Do NOT infer or reason beyond text.

Context Search Procedure (MANDATORY):
You MUST actively search the CONTEXT to locate supporting evidence.
The CONTEXT may contain nested structured data (JSON-like objects).
You MUST inspect fields, keys, and values inside the structure.

Step-by-step search strategy:
1. Identify the subject of the fragment (plan, vendor, route, date, cost, etc.).
2. Scan the CONTEXT for fields whose key names or values relate to that subject.
3. Verify whether an explicit value matches the fragment exactly.
4. You MUST always extract RELEVANT CONTEXT SIGNALS when they exist.

RELEVANT CONTEXT SIGNALS include:
- matching entities
- matching attributes
- matching numeric values
- related fields that partially align with the fragment

IMPORTANT:
Supporting Context Evidence is NOT limited to full matches.
Even when the final status is "No Match", you MUST still include
any relevant context snippets that relate to the fragment.

5. Evidence Match Status logic:

Match:
- explicit statement exists confirming the fragment.

No Match:
- context contains related facts but lacks explicit confirmation,
  OR introduces conflicting semantics.

Evidence presence does NOT imply Match.

6. Do NOT assume relationships between fields unless explicitly stated.

Evidence Selection Rules:
- Prefer exact key-value matches over descriptive text.
- Supporting statements must come directly from CONTEXT content.
- Do NOT summarize or paraphrase the evidence.

Explicit Grounding Rules:

- A JSON field is valid support ONLY if:
  key semantically matches fragment subject AND
  value matches fragment attribute.

- Date relationships MUST be explicit.
  "delivery by X" does NOT imply "requested on X".

- NUMERIC MATCHING RULE (UPDATED - STRICT)

You MAY treat values as equal when differences are caused ONLY by
formatting or precision normalization.

Allowed equivalence cases:

1) Formatting normalization:
   "$1,264,076" == 1264076

2) Float vs integer:
   1264076 == 1264076.0

3) Precision truncation caused by presentation:
   98888.01 == 98888
   ONLY when:
   - the integer portion is identical
   - difference is <= 1.0
   - fragment wording suggests rounding or normalization

STRICTLY FORBIDDEN:
- Rounding to nearest thousand/hundred.
- Percentage or arithmetic reasoning.
- Any comparison where integer portion differs.

Output Format:
{
  "Supporting Context Evidence": "string",
  "Evidence Match Status": "Match | No Match",
  "Verification Reason": "string"
}

Few Shot Examples:

Example 1 - Direct Match
Input Fragment:
"The plan ID is PLAN_1"
Context:
PLAN_ID = PLAN_1
Output:
{
  "Supporting Context Evidence": "PLAN_ID = PLAN_1",
  "Evidence Match Status": "Match",
  "Verification Reason": "Context explicitly states PLAN_1."
}

Example 2 - No Match
Fragment:
"You requested the shipment on 2026-10-01"
Context:
delivery_date = 2026-10-01
Output:
{
  "Supporting Context Evidence": "",
  "Evidence Match Status": "No Match",
  "Verification Reason": "Delivery date is not equivalent to request date."
}

Example 3 - Structured JSON Match
Fragment:
"it is a FULL delivery"
Context:
{'delivery_type': 'full'}
Output:
{
  "Supporting Context Evidence": "'delivery_type': 'full'",
  "Evidence Match Status": "Match",
  "Verification Reason": "Explicit structured field confirms delivery type."
}
""".strip()

    user_prompt = json.dumps(
        {"Output Fragment": claim, "context": context},
        indent=2,
    )

    resp = llm_client.invoke([
        {"role": "system", "content": system_prompt},
        {"role": "user",   "content": user_prompt},
    ])

    try:
        parsed = json.loads(resp.content)
    except Exception:
        parsed = {
            "Supporting Context Evidence": "",
            "Evidence Match Status":       "No Match",
            "Verification Reason":         "Unparseable LLM output",
        }

    return {
        "Output Fragment":             claim,
        "Supporting Context Evidence": parsed.get("Supporting Context Evidence", ""),
        "Evidence Match Status":       parsed.get("Evidence Match Status", "No Match"),
        "Verification Reason":         parsed.get("Verification Reason", ""),
    }


# ============================================================
# PYTHON SCORING
# ============================================================
def compute_output_vs_context_score(evals: List[Dict]) -> Dict[str, Any]:
    """Compute score from claim evaluations."""
    total   = len(evals)
    matched = sum(1 for e in evals if e.get("Evidence Match Status") == "Match")

    return {
        "output_vs_context_accuracy_score": round(matched / total, 2) if total else 1.0,
        "matched_claims": matched,
        "total_claims":   total,
        "reason": (
            f"{matched} out of {total} claims supported by context."
            if total else "No claims evaluated."
        ),
    }


# ============================================================
# MAIN EVALUATION PIPELINE
# ============================================================
def run_summary_accuracy_eval(
    trace_id: str,
    scenario: str,
    llm_client: AzureChatOpenAI,
) -> Dict[str, Any]:
    """
    Run summary accuracy evaluation for a single trace.

    Args:
        trace_id:   LangSmith trace ID
        scenario:   Query/scenario text
        llm_client: Azure OpenAI client

    Returns:
        Evaluation result dictionary compatible with main.py
    """
    try:
        spans        = fetch_spans(trace_id)
        execute_span = find_execute_span(spans)
        summary_span = find_execute_plan_summary_span(spans)

        summary = extract_execute_plan_summary(summary_span)
        context = extract_execute_contexts(execute_span, summary_span)

        claims      = llm_split_summary_into_claims(summary, llm_client)
        evaluations = [
            llm_match_claim_to_context(claim, context, llm_client)
            for claim in claims
        ]

        score_result = compute_output_vs_context_score(evaluations)

        return {
            "eval_name":  "output_vs_context_accuracy",
            "eval_type":  "llm",
            "trace_id":   trace_id,
            "scenario":   scenario,
            "status":     "success",
            "error":      None,
            "eval_prompt": "See llm_split_summary_into_claims and llm_match_claim_to_context prompts.",
            "eval_inputs": {
                "summary": summary,
                "claims":  claims,
            },
            "eval_output": {
                **score_result,
                "overall_reason":    score_result.get("reason", ""),
                "actual_output":     summary,
                "claim_evaluations": evaluations,
            },
            "metadata": {
                "model":       "gpt-5",
                "temperature": 1,
                "timestamp":   datetime.utcnow().isoformat(),
            },
        }

    except Exception as e:
        return {
            "eval_name":  "output_vs_context_accuracy",
            "eval_type":  "llm",
            "trace_id":   trace_id,
            "scenario":   scenario,
            "status":     "failed",
            "error":      str(e),
            "eval_output": {},
            "metadata": {
                "timestamp": datetime.utcnow().isoformat(),
            },
        }


# ============================================================
# EXCEL STORAGE — aligned with notebook logger
# ============================================================
def dump_summary_accuracy_eval_to_excel(
    *,
    trace_id: str,
    query: str,
    eval_result: dict,
    excel_path: str = "final_eval_results.xlsx",
):
    """Save summary accuracy evaluation results to Excel file."""
    wb    = get_or_create_workbook(excel_path)
    # Sheet name "Output vs Context Accuracy" matches notebook logger SHEET_NAME_OCA
    sheet = get_or_create_sheet(wb, "Output vs Context Accuracy", SUMMARY_ACCURACY_HEADERS)

    eval_inputs    = eval_result.get("eval_inputs",  {})
    eval_output    = eval_result.get("eval_output",  {})
    summary_output = eval_inputs.get("summary",      "")
    overall_score  = eval_output.get("output_vs_context_accuracy_score", "")
    overall_reason = eval_output.get("reason",       "")
    claim_evals    = eval_output.get("claim_evaluations", [])

    if eval_result.get("status") == "failed":
        # FIX 2: was writing 8 values for 7-column header — now exactly 7
        sheet.append([
            query,
            summary_output,
            "",     # Score
            eval_result.get("error", "Unknown error"),  # Reason
            None,   # Output Fragment
            None,   # Supporting Context Evidence
            None,   # Evidence Match Status
        ])
        wb.save(excel_path)
        return

    if not claim_evals:
        sheet.append([
            query,
            summary_output,
            overall_score,
            overall_reason,
            None,   # Output Fragment
            None,   # Supporting Context Evidence
            None,   # Evidence Match Status
        ])
    else:
        for ce in claim_evals:
            # FIX 1: was writing 8 columns including "Verification Reason"
            # notebook logger has only 7 columns — no "Verification Reason"
            sheet.append([
                query,
                summary_output,
                overall_score,
                overall_reason,
                ce.get("Output Fragment",             ""),
                ce.get("Supporting Context Evidence", ""),
                ce.get("Evidence Match Status",       ""),
                # "Verification Reason" intentionally excluded — not in logger headers
            ])

    wb.save(excel_path)